//
//  AppDelegate.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/4/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//
import UIKit


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        //window?.rootViewController = TodayViewController()
        
        return true
    }
    
    
    
    
    
    
    
    
    
    
    
}



