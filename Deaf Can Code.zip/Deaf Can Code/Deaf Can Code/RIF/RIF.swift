//
//  RIF.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/13/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import Foundation
import UIKit

let CopyrightYears = "2018 - 2020"
let Version = "1.0.8"

// Sign
var warningSignColor = #colorLiteral(red: 0.7397634387, green: 0.5784541368, blue: 0.2038931847, alpha: 1)
var errorSignColor = #colorLiteral(red: 0.9985695481, green: 0.2683239579, blue: 0.2265070677, alpha: 1)

// Code Syntax color

//\() or = or { }
var PlainSyntax = #colorLiteral(red: 0.9051660299, green: 0.9097653031, blue: 0.9226967096, alpha: 1)
var CommentSyntax = #colorLiteral(red: 0.3179799914, green: 0.7639405727, blue: 0.3094570637, alpha: 1)
var DoucmenationMarkUpSyntax = #colorLiteral(red: 0.1358761489, green: 0.6761265397, blue: 0.4070919752, alpha: 1)
var DocumentationKeyboardSyntax = #colorLiteral(red: 0.2151998878, green: 0.8315266967, blue: 0.5218499303, alpha: 1)
var MarksSyntax = #colorLiteral(red: 0.2151998878, green: 0.8315266967, blue: 0.5218499303, alpha: 1)
var StringSyntax = #colorLiteral(red: 0.8935745358, green: 0.2290027142, blue: 0.2312045395, alpha: 1)
var CharacterSyntax = #colorLiteral(red: 0.5317746997, green: 0.5114977956, blue: 0.7462607622, alpha: 1)
var NumberSyntax = #colorLiteral(red: 0.1571231186, green: 0.6325528026, blue: 0.6234240532, alpha: 1)
var KeyboardSyntax = #colorLiteral(red: 0.8845621943, green: 0.1773953438, blue: 0.629383266, alpha: 1)
var PreprocessorStatementsSyntax = #colorLiteral(red: 0.8203322291, green: 0.5520974398, blue: 0.360435009, alpha: 1)
var AttributesSyntax = #colorLiteral(red: 0.4086615443, green: 0.5282447934, blue: 0.5613048673, alpha: 1)
// name value
var TypeDeclarationSyntax = #colorLiteral(red: 0.4166886508, green: 0.8743804097, blue: 0.9990791678, alpha: 1)
// symbol
var OtherDecluarationSyntax = #colorLiteral(red: 0.3036721945, green: 0.6847692132, blue: 0.78442204, alpha: 1)
// linked to name value
var projectSyntax = #colorLiteral(red: 0.1571231186, green: 0.6325528026, blue: 0.6234240532, alpha: 1)

var ProjectClassName = #colorLiteral(red: 0.0940316543, green: 0.7126082778, blue: 0.6939868331, alpha: 1)
var PreprocessorStatementsmacriosSyntax = #colorLiteral(red: 0.8203322291, green: 0.5520974398, blue: 0.360435009, alpha: 1)
var headingSyntax = #colorLiteral(red: 0.7321503758, green: 0.1729213297, blue: 0.6375609636, alpha: 1)
// 1.2.
var counterSyntax = #colorLiteral(red: 0.4232426286, green: 0.4269305468, blue: 0.4618210793, alpha: 1)


// Color for Code background interfaces
var titleText = #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
var titleBackground = #colorLiteral(red: 0.0941023156, green: 0.09412650019, blue: 0.09410078079, alpha: 1)
var CodeBackground = #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
var answertextColor = #colorLiteral(red: 0.9961728454, green: 0.9902502894, blue: 1, alpha: 1)
var answerBackground = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
var dynamicBackground = #colorLiteral(red: 0.02708261088, green: 0.4768417478, blue: 0.9985074401, alpha: 1)

// MARK: iOS interfaces

// MARK: default
// background
var defaultLightBackground = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
var defaultDarkbackground = #colorLiteral(red: 0.0941023156, green: 0.09412650019, blue: 0.09410078079, alpha: 1)

var cardBackground = #colorLiteral(red: 0.1251045167, green: 0.1290263534, blue: 0.1551302373, alpha: 1)
// text
var textTdefaultitle = #colorLiteral(red: 0.9961728454, green: 0.9902502894, blue: 1, alpha: 1)

// MARK: code conecpt

// SF Mono for iOS 13 only
var BoldsfMonoDescriptor = UIFont.boldSystemFont(ofSize: 5).fontDescriptor.withDesign(.monospaced)

 var sfMonoDescriptor = UIFont.systemFont(ofSize: 15).fontDescriptor.withDesign(.monospaced)
var sfMonoFont = UIFont(descriptor: sfMonoDescriptor!, size: 15)
var sfMonoBoldFont = UIFont(descriptor: BoldsfMonoDescriptor!, size: 15)

// MARK: console

// SF Font defaults
var setFont = sfMonoFont
var BoldFont = sfMonoBoldFont


