//
//  PaulViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/17/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class PaulViewController: UIViewController {
    
    var name = ["Paul Hudson", "", ""]
               var aaronsection = ["", "Paul Hudson is a known Hacking With Swift founder. He brings excellent tutorials about how to learn a Swift Langauge and Create an iOS Apps as known 1 of 100 Days in the Hacking With Swift Website. I am an honor to hear from Paul Hudson since He tweeted about Deaf Can Code on Twitter. I have put this credit because I did learn some of his tutorials. I am expected to meet him someday! ", ""]
               var Image = ["Paul Profile", "", ""]
               


           @IBOutlet weak var PaulTableView: UITableView!
           
               override func viewDidLoad() {
                   super.viewDidLoad()

                  
                   self.navigationItem.title = "Meet The Developer"
                   
               }


           }

           extension PaulViewController: UITableViewDataSource, UITableViewDelegate {
               
               func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                   
                   
                   if indexPath.row == 2 {
                       return 55
                   } else if indexPath.row == 1 {
               
                   
                       return UITableView.automaticDimension
                   } else {
                       
                       return 210
                   }
                   
                
               }
               
               func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                   return name.count
               }
               
               func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                   
                   var profileCell: ProfilePualTableViewCell!
                   var followCell: FollowPaulTableViewCell!
                   
                   if indexPath.row == 2 {
                       
                       followCell = PaulTableView.dequeueReusableCell(withIdentifier: "FollowCells") as? FollowPaulTableViewCell
                       
                    followCell?.FollowButton.addTarget(self,action: #selector(clicked),for: .touchUpInside)
                       followCell?.FollowButton.tag = indexPath.row
                       
                     
                       
                                 
                                  return followCell!
                       
                   } else if indexPath.row == 1 {
                       
                       let sectionCell = PaulTableView.dequeueReusableCell(withIdentifier: "SectionCells")
                       sectionCell?.textLabel?.text = aaronsection[indexPath.row]
                      
                       sectionCell?.textLabel!.textColor = #colorLiteral(red: 0.4588235294, green: 0.462745098, blue: 0.4901960784, alpha: 1)
                       sectionCell?.textLabel!.numberOfLines = 0
                       sectionCell?.textLabel!.lineBreakMode = .byWordWrapping
                       sectionCell?.textLabel!.textAlignment = .center
                       
                       sectionCell?.isUserInteractionEnabled = false
                       
                      return sectionCell!
                       
                   } else {
                       
                       profileCell = PaulTableView.dequeueReusableCell(withIdentifier: "ProfileCells") as? ProfilePualTableViewCell
                       
                      profileCell?.namelbl.text = name[indexPath.row]
                      profileCell?.imgPaul.image = UIImage(named: Image[indexPath.row])
                       
                       profileCell?.imgPaul.layer.borderColor = UIColor.white.cgColor
                       
                       profileCell?.imgPaul.layer.shadowColor = UIColor.lightGray.cgColor

                       
                       profileCell?.isUserInteractionEnabled = false
                                 
                                 return profileCell!
                      
                   }
               }
               
               @objc func clicked (_ btn: UIButton) {
                   
                   UIApplication.shared.open(URL(string:"https://twitter.com/MTAC8")!, options: [:], completionHandler: nil)
                   
               }
               
               
               
      }

