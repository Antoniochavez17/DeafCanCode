//
//  SeanViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/17/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class SeanViewController: UIViewController {

    var name = ["Sean Allen", "", ""]
                  var aaronsection = ["", "Sean Allen is a YouTuber that he uploaded a lot of videos about the example of Swift and Apps. He was an iOS Engineer. I love to watch these videos from his YouTube channel called Sean Allen. The reason I upload this credit because It was amazing to learn a lot of his tutorial videos!", ""]
                  var Image = ["Sean Allen", "", ""]
                  


              @IBOutlet weak var SeanTableView: UITableView!
              
                  override func viewDidLoad() {
                      super.viewDidLoad()

                     
                      self.navigationItem.title = "Meet The Developer"
                      
                  }


              }

              extension SeanViewController: UITableViewDataSource, UITableViewDelegate {
                  
                  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                      
                      if indexPath.row == 2 {
                          return 55
                      } else if indexPath.row == 1 {
                  
                      
                          return UITableView.automaticDimension
                      } else {
                          
                          return 210
                      }
                      
                  }
                  
                  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                      return name.count
                  }
                  
                  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                      
                      var profileCell: SeanProfileTableViewCell!
                      var followCell: FollowSeanTableViewCell!
                      
                      if indexPath.row == 2 {
                          
                          followCell = SeanTableView.dequeueReusableCell(withIdentifier: "FollowCells") as? FollowSeanTableViewCell
                          
                       followCell?.followButton.addTarget(self,action: #selector(clicked),for: .touchUpInside)
                          followCell?.followButton.tag = indexPath.row
                          
                        
                          
                                    
                                     return followCell!
                          
                      } else if indexPath.row == 1 {
                          
                          let sectionCell = SeanTableView.dequeueReusableCell(withIdentifier: "SectionCells")
                          sectionCell?.textLabel?.text = aaronsection[indexPath.row]
                         
                          sectionCell?.textLabel!.textColor = #colorLiteral(red: 0.4588235294, green: 0.462745098, blue: 0.4901960784, alpha: 1)
                          sectionCell?.textLabel!.numberOfLines = 0
                          sectionCell?.textLabel!.lineBreakMode = .byWordWrapping
                          sectionCell?.textLabel!.textAlignment = .center
                          
                          sectionCell?.isUserInteractionEnabled = false
                          
                         return sectionCell!
                          
                      } else {
                          
                          profileCell = SeanTableView.dequeueReusableCell(withIdentifier: "ProfileCells") as? SeanProfileTableViewCell
                          
                         profileCell?.nameLbl.text = name[indexPath.row]
                         profileCell?.SeanProfile.image = UIImage(named: Image[indexPath.row])
                          
                          profileCell?.SeanProfile.layer.borderColor = UIColor.white.cgColor
                          
                          profileCell?.SeanProfile.layer.shadowColor = UIColor.lightGray.cgColor

                          
                          profileCell?.isUserInteractionEnabled = false
                                    
                                    return profileCell!
                         
                      }
                  }
                  
                  @objc func clicked (_ btn: UIButton) {
                      
                      UIApplication.shared.open(URL(string:"https://twitter.com/seanallen_dev")!, options: [:], completionHandler: nil)
                      
                  }
                  
                  
                  
         }

