//
//  AntonioFollowTableViewCell.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/16/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class AntonioFollowTableViewCell: UITableViewCell {

    @IBOutlet weak var AntonioFollowButton: UIButton!
    @IBOutlet weak var FollowImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
