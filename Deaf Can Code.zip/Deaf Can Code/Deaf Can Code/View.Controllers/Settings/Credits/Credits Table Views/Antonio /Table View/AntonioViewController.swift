//
//  AntonioViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/16/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class AntonioViewController: UIViewController {
    
    var name = ["Antonio Adrian Chavez", "", ""]
    var Antoniosection = ["", "Hello, My name is Antonio Adrian Chavez. I am a Deaf iOS Developer. I attended Kansas School for the Deaf (KSD) in Olathe, Kansas and at 11-years old I was transferred to public school in Great Bend, Kansas. I have been an artist for almost 5 years. My mother enrolled me in Art Instruction School in 2016, and many famous artists come from that school. I wanted to join the iOS Developers program. So I started learning Swift from Hacking With Swift, since 2018.  But I did research in Swift this summer myself. I want to support these kinds of communities so that their goals can be successful in the future. What do I do in my free time?  My free time is drawing my artwork on the Procreate with Apple Pencil on the iPad, and I create AR objects on the Xcode Project.  Sometimes I watch Hacking With Hacking and Sean Allen on YouTube. Thank you for supporting Deaf Can Code!", ""]
    var antonioFollow = ["", "", "https://twitter.com/antonio07341176"]
    var AntonioImage = ["Antonio Profile", "", ""]
    

    @IBOutlet weak var AntonioTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
        self.navigationItem.title = "Meet The Developer"
        
    }


}

extension AntonioViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        

        if indexPath.row == 2 {
            return 55
        } else if indexPath.row == 1 {
    
        
            return UITableView.automaticDimension
        } else {
            
            return 210
        }
    
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return name.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var profileCell: AntonioProfileTableViewCell!
        var followCell: AntonioFollowTableViewCell!
        
        if indexPath.row == 2 {
            
            followCell = AntonioTableView.dequeueReusableCell(withIdentifier: "FollowCells") as? AntonioFollowTableViewCell
            
         followCell?.AntonioFollowButton.addTarget(self,action: #selector(clicked),for: .touchUpInside)
            followCell?.AntonioFollowButton.tag = indexPath.row
            
          
            
                      
                       return followCell!
            
        } else if indexPath.row == 1 {
            
            let sectionCell = AntonioTableView.dequeueReusableCell(withIdentifier: "SectionCells")
            sectionCell?.textLabel?.text = Antoniosection[indexPath.row]
           
            sectionCell?.textLabel!.textColor = #colorLiteral(red: 0.4588235294, green: 0.462745098, blue: 0.4901960784, alpha: 1)
            sectionCell?.textLabel!.numberOfLines = 0
            sectionCell?.textLabel!.lineBreakMode = .byWordWrapping
            sectionCell?.textLabel!.textAlignment = .center
            
            sectionCell?.isUserInteractionEnabled = false
            
           return sectionCell!
            
        } else {
            
            profileCell = AntonioTableView.dequeueReusableCell(withIdentifier: "ProfileCells") as? AntonioProfileTableViewCell
            
            profileCell?.Antoniolbl.text = "Antonio Adrian Chavez"
            profileCell?.AntonioProfile.image = UIImage(named: "Antonio Profile")
            
            profileCell?.AntonioProfile.layer.borderColor = UIColor.white.cgColor
            
            profileCell?.AntonioProfile.layer.shadowColor = UIColor.lightGray.cgColor

            
            profileCell?.isUserInteractionEnabled = false
                      
                      return profileCell!
           
        }
    }
    
    @objc func clicked (_ btn: UIButton) {
        
        UIApplication.shared.open(URL(string:antonioFollow[btn.tag])!, options: [:], completionHandler: nil)
        
    }
    
    
    
}
