//
//  AppleViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/17/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class AppleViewController: UIViewController {

    
    var name = ["Apple", "", ""]
                     var aaronsection = ["", "This Deaf Can Code does have Swift, the Swift logo, Swift Playgrounds, Xcode, SF Mono Fonts, iOS, WatchOS, TVOS, and MacOS, and many things were trademarks of Apple Inc registered in the U.S. and other countries.", ""]
                     var Image = ["Apple Profile", "", ""]
                     


                 @IBOutlet weak var AppleTableView: UITableView!
                 
                     override func viewDidLoad() {
                         super.viewDidLoad()

                        
                         self.navigationItem.title = "Meet The Developer"
                         
                     }


                 }

                 extension AppleViewController: UITableViewDataSource, UITableViewDelegate {
                     
                     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                         
                        
                         if indexPath.row == 2 {
                             return 55
                         } else if indexPath.row == 1 {
                     
                              return UITableView.automaticDimension
                         } else {
                             
                             return 210
                         }
           
                     }
                     
                     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                         return name.count
                     }
                     
                     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                         
                         var profileCell: AppleProfileTableViewCell!
                         var followCell: FollowAppleTableViewCell!
                         
                         if indexPath.row == 2 {
                             
                             followCell = AppleTableView.dequeueReusableCell(withIdentifier: "FollowCells") as? FollowAppleTableViewCell
                             
                          followCell?.FollowButton.addTarget(self,action: #selector(clicked),for: .touchUpInside)
                             followCell?.FollowButton.tag = indexPath.row
                             
                           
                             
                                       
                                        return followCell!
                             
                         } else if indexPath.row == 1 {
                             
                             let sectionCell = AppleTableView.dequeueReusableCell(withIdentifier: "SectionCells")
                             sectionCell?.textLabel?.text = aaronsection[indexPath.row]
                            
                             sectionCell?.textLabel!.textColor = #colorLiteral(red: 0.4588235294, green: 0.462745098, blue: 0.4901960784, alpha: 1)
                             sectionCell?.textLabel!.numberOfLines = 0
                             sectionCell?.textLabel!.lineBreakMode = .byWordWrapping
                             sectionCell?.textLabel!.textAlignment = .center
                             
                             sectionCell?.isUserInteractionEnabled = false
                             
                            return sectionCell!
                             
                         } else {
                             
                             profileCell = AppleTableView.dequeueReusableCell(withIdentifier: "ProfileCells") as? AppleProfileTableViewCell
                             
                            profileCell?.nameLbl.text = name[indexPath.row]
                            profileCell?.AppleProfile.image = UIImage(named: Image[indexPath.row])
                             
                             profileCell?.AppleProfile.layer.borderColor = UIColor.white.cgColor
                             
                             profileCell?.AppleProfile.layer.shadowColor = UIColor.lightGray.cgColor

                             
                             profileCell?.isUserInteractionEnabled = false
                                       
                                       return profileCell!
                            
                         }
                     }
                     
                     @objc func clicked (_ btn: UIButton) {
                         
                         UIApplication.shared.open(URL(string: "https://twitter.com/Apple")!, options: [:], completionHandler: nil)
                         
                     }
                     
                     
                     
            }
