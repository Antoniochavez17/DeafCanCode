//
//  YumaViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/17/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class YumaViewController: UIViewController {

    var name = ["Yuma Soerianto", "", ""]
                     var aaronsection = ["", "Yuma Soerianto is a known Anyone Can Code founders. He's a 3th youngest WWDC Scholarship winner. Soerianto started learning the Swift programming when he's 8 Years old and created his first app when he's 9 Years old. He loves to teach about ARKit Projects on the YouTube Channels is called Anyone Can Code. Soerianto has appeared his photo to the screen at WWDC17 for honoring the first youngest developer. I love to learn ARKit things from Soerianto because ARKit does look like Logo. I will start teaching about ARKit, but some tutorials will have credit to Soerianto. ", ""]
                     var Image = ["Yuma", "", ""]
                     


                 @IBOutlet weak var YumaTableView: UITableView!
                 
                     override func viewDidLoad() {
                         super.viewDidLoad()

                        
                         self.navigationItem.title = "Meet The Developer"
                         
                     }


                 }

                 extension YumaViewController: UITableViewDataSource, UITableViewDelegate {
                     
                     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                         
             
                         if indexPath.row == 2 {
                             return 55
                         } else if indexPath.row == 1 {
                     
                         
                             return UITableView.automaticDimension
                         } else {
                             
                             return 210
                         }
                         
                     }
                     
                     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                         return name.count
                     }
                     
                     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                         
                         var profileCell: YumaProfileTableViewCell!
                         var followCell: FollowYumaTableViewCell!
                         
                         if indexPath.row == 2 {
                             
                             followCell = YumaTableView.dequeueReusableCell(withIdentifier: "FollowCells") as? FollowYumaTableViewCell
                             
                          followCell?.followButton.addTarget(self,action: #selector(clicked),for: .touchUpInside)
                             followCell?.followButton.tag = indexPath.row
                             
                           
                             
                                       
                                        return followCell!
                             
                         } else if indexPath.row == 1 {
                             
                             let sectionCell = YumaTableView.dequeueReusableCell(withIdentifier: "SectionCells")
                             sectionCell?.textLabel?.text = aaronsection[indexPath.row]
                            
                             sectionCell?.textLabel!.textColor = #colorLiteral(red: 0.4588235294, green: 0.462745098, blue: 0.4901960784, alpha: 1)
                             sectionCell?.textLabel!.numberOfLines = 0
                             sectionCell?.textLabel!.lineBreakMode = .byWordWrapping
                             sectionCell?.textLabel!.textAlignment = .center
                             
                             sectionCell?.isUserInteractionEnabled = false
                             
                            return sectionCell!
                             
                         } else {
                             
                             profileCell = YumaTableView.dequeueReusableCell(withIdentifier: "ProfileCells") as? YumaProfileTableViewCell
                             
                            profileCell?.nameLbl.text = name[indexPath.row]
                            profileCell?.yumaProfile.image = UIImage(named: Image[indexPath.row])
                             
                             profileCell?.yumaProfile.layer.borderColor = UIColor.white.cgColor
                             
                             profileCell?.yumaProfile.layer.shadowColor = UIColor.lightGray.cgColor

                             
                             profileCell?.isUserInteractionEnabled = false
                                       
                                       return profileCell!
                            
                         }
                     }
                     
                     @objc func clicked (_ btn: UIButton) {
                         
                         UIApplication.shared.open(URL(string: "https://twitter.com/yumaSoerianto")!, options: [:], completionHandler: nil)
                         
                     }
                     
                     
                     
            }
