//
//  AaronViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/16/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class AaronViewController: UIViewController {

      var name = ["Aaron Kreipe", "", ""]
         var aaronsection = ["", "Arron Kreipe is an iOS Developer. He enjoying develops some of his apps. He helps and example to me about these bugs in the console which I was troubleshooting with those bugs. Thanks to him for bringing this excellent help!", ""]
         var AaronFollow = ["", "", "https://twitter.com/AaronKreipe"]
         var Image = ["𝔄𝔞𝔯𝔬𝔫's profile", "", ""]
         


     @IBOutlet weak var AaronTableView: UITableView!
     
         override func viewDidLoad() {
             super.viewDidLoad()

            
             self.navigationItem.title = "Meet The Developer"
             
         }


     }

     extension AaronViewController: UITableViewDataSource, UITableViewDelegate {
         
         func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
             
      
             if indexPath.row == 2 {
                 return 55
             } else if indexPath.row == 1 {
         
             
                 return UITableView.automaticDimension
             } else {
                 
                 return 210
             }
             

         }
         
         func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
             return name.count
         }
         
         func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
             
             var profileCell: AaronTableViewCell!
             var followCell: FollowTableViewCell!
             
             if indexPath.row == 2 {
                 
                 followCell = AaronTableView.dequeueReusableCell(withIdentifier: "FollowCells") as? FollowTableViewCell
                 
              followCell?.FollowButton.addTarget(self,action: #selector(clicked),for: .touchUpInside)
                 followCell?.followbutton.tag = indexPath.row
                 
               
                 
                           
                            return followCell!
                 
             } else if indexPath.row == 1 {
                 
                 let sectionCell = AaronTableView.dequeueReusableCell(withIdentifier: "SectionCells")
                 sectionCell?.textLabel?.text = aaronsection[indexPath.row]
                
                 sectionCell?.textLabel!.textColor = #colorLiteral(red: 0.4588235294, green: 0.462745098, blue: 0.4901960784, alpha: 1)
                 sectionCell?.textLabel!.numberOfLines = 0
                 sectionCell?.textLabel!.lineBreakMode = .byWordWrapping
                 sectionCell?.textLabel!.textAlignment = .center
                 
                 sectionCell?.isUserInteractionEnabled = false
                 
                return sectionCell!
                 
             } else {
                 
                 profileCell = AaronTableView.dequeueReusableCell(withIdentifier: "ProfileCells") as? AaronTableViewCell
                 
                profileCell?.namelbl.text = name[indexPath.row]
                profileCell?.profilename.image = UIImage(named: Image[indexPath.row])
                 
                 profileCell?.profilename.layer.borderColor = UIColor.white.cgColor
                 
                 profileCell?.profilename.layer.shadowColor = UIColor.lightGray.cgColor

                 
                 profileCell?.isUserInteractionEnabled = false
                           
                           return profileCell!
                
             }
         }
         
         @objc func clicked (_ btn: UIButton) {
             
             UIApplication.shared.open(URL(string:"https://twitter.com/AaronKreipe")!, options: [:], completionHandler: nil)
             
         }
         
         
         
}
