//
//  CreditViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/15/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class CreditViewController: UIViewController {
    
    // Photo profile
    var Photoimage = ["Antonio Profile", "𝔄𝔞𝔯𝔬𝔫's profile", "MTAC Profile", "Paul Profile", "Sean Allen", "Yuma", "Apple Profile"]
    
    // Name
    var name = ["Antonio Adrian Chavez", "Aaron Rreipe", "Derek Foresman", "Paul Hudson", "Sean Allen", "Yuma Soerianto", "Apple Inc" ]
    // Footer
    var footer = ["Founder of Deaf Can Code", "Swift, Obj-C Developer", "Objective C Developer", "Founder of Hacking With Swift", "iOS Enginner", "Founder of Anyone Can Code", "Copyright Ownership"]
    
    // Credits Storyboard ID
      var StoryboardID = [String]()

    @IBOutlet weak var CreditTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

         self.navigationItem.title = "Credits"
        
        StoryboardID = ["Antonios", "Aarons", "Dereks", "Pauls", "Seans", "Yumas", "Apples"]
             

               let headerView = UIView()
               let footerView = UIView()
                    
               headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
               footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
                    
        let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 2.8)
                    
               headerView.frame = sizeView
               footerView.frame = sizeView
               CreditTableView.tableHeaderView = headerView
               CreditTableView.tableFooterView = footerView
               
        
    }
    
  

}

extension CreditViewController: UITableViewDelegate, UITableViewDataSource {

func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
    return name.count
            
}

func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    
    return 105
    
}
    
    
func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           
    let creditCell = CreditTableView.dequeueReusableCell(withIdentifier: "CreditsCells") as? CreditTableViewCell
    
    creditCell?.ProfileImage.image = UIImage(named: Photoimage[indexPath.row])
    creditCell?.ProfileName.text = "\(name[indexPath.row])"
    creditCell?.ProfileFooter.text = "\(footer[indexPath.row])"
    
    creditCell?.selectionStyle = UITableViewCell.SelectionStyle.none
    
    return creditCell!
    }
    
 func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         
            
 let vcName = StoryboardID[indexPath.row]
            
 let Swift = storyboard?.instantiateViewController(withIdentifier: vcName)
        
         
 self.navigationController?.pushViewController(Swift!, animated: true)
            
 }

        
       
            

}
