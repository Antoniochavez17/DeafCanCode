//
//  LearnMoreTableViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/4/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class LearnMoreTableViewController: UIViewController
{

    struct Object {
        var seactionName: String!
        var seactionObjection: [String]!
    }
   
    var objectArray = [Object]()
   
    @IBOutlet weak var WhatNewTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        objectArray = [
            Object(seactionName: "Important Notes", seactionObjection: ["If you have a problem with somethings on the Deaf Can Code, Please don't write a review in the App Store just using a filling a report in the Feedback. I will fix what you have reported."]),
            
            Object(seactionName: "Version \(Version)", seactionObjection: ["Add iPadOS Devices supports", "Deaf Can Code News has removed"]),
            
            Object(seactionName: "Version 1.0.7", seactionObjection: ["The syntax in the Dictionary has fixed and Xcode 11 supported.", "Add \"Coming soon\" under the section cell", "Icon Apperarance has added in Setting > Apperarance > Icon Apperarance"]),
            
            Object(seactionName: "Version 1.0.6", seactionObjection: ["Deaf Can Code has very smooth behavior on the iOS 13.", "New items are avaiable sale on Deaf Can Code Merch", "Deaf Can Code Feedback has added the resources of the project on GitHub to help more improvements and fixed if you got a report that you have seen any of the problems.", "All of the tutorial videos will bring a redesign and change improvement tutorials in the new version.",  "The syntax in the Swift Tutorials, and Dictionary has Xcode 11 supported.","Table View has replaced in Setting.", "Table View has replaced in Deaf Can Code.", "Table View has replaced in Swift Tutorials.", "WKWebView has replaced in Swift Tutorials.", "WorkSpace Project has removed.", "WWDC Countdown and widgets has removed.", "UIImage has replaced to SF Mono in Swift Tutorials based on UITableView.", "DCC Merch has Redesigned interfaces.", "DCC News has fixed to allow you tap anywhere in the cards.", "Dictionary has redesigned interfaces.", "Credits interfaces has fixed, improvement, and UITableView has replaced from View Controller.", "Table View has replaced in Setting and improvement.", "Disclosure indicator has redesigned.", "\"Coming Soon\" has replaced to disclosure indicator in which light disclosure indicator means avaiables otherwise, dark disclosure indicator means not avaiables."]),
            
            Object(seactionName: "Version 1.0.5", seactionObjection: ["Dark and Light appearance has fixed"]),
            
            Object(seactionName: "Version 1.0.4", seactionObjection: ["Some table view appeared black text in light mode has fixed.", "Swift in the dictionary has added.","DCC News table view has improvement and fixed.", "Printing tutorials has fixed.", "Table View has replaced in Policy.", "Mail body message in Feedback has fixed.", "Color in the header table view has fixed."]),
            
            Object(seactionName: "Version 1.0.3", seactionObjection: ["Crash in credit has fixed.", "WWDC Coundown Widgets has fixed.", "Table view has replaced in Merch.", "Table view has replaced in Learn More."]),
            
            Object(seactionName: "Version 1.0.2", seactionObjection: ["Full iOS devices supported.", "Swift quiz alert appears incorrect spelling has fixed.", "Some devices appears black status bars has fixed.", "Whole view controller has replaced to table view."]),
            
            Object(seactionName: "Version 1.0.1", seactionObjection: ["Account has removed."]),
            
            Object(seactionName: "Version 1.0", seactionObjection: ["6.7' and 5.8' devices supported."])]
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
}

extension LearnMoreTableViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = WhatNewTableView.dequeueReusableCell(withIdentifier: "Cells")
        cell?.textLabel?.text = objectArray[indexPath.section].seactionObjection[indexPath.row]
        cell?.textLabel!.textColor = .white
        cell?.textLabel!.numberOfLines = 0
        cell?.textLabel!.lineBreakMode = .byWordWrapping
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
        return objectArray[section].seactionObjection.count
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
       
        return objectArray.count
        
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return objectArray[section].seactionName
        
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int){
        
        view.tintColor = #colorLiteral(red: 0.1564497352, green: 0.1637369096, blue: 0.2134993672, alpha: 1)
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.textColor = UIColor.white
        
    }
  
}
