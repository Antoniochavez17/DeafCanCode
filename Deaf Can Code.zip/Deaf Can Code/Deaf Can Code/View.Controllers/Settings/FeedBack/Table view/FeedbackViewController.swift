//
//  FeedbackViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/17/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import StoreKit
import MessageUI

class FeedbackViewController: UIViewController {
    
    var icons = ["Icon-11", "Icon-10", "Icon-9", "Untitled 6-5", "Icon-6", ""]
    
    var FeedbackTitle = ["", "DCC News", "Deaf Can Code", "Setting"]
    
    var Message = [
        
        "",
        
        """
        Please text in the description of what you have found issues on the Deaf Can Code.

        Description:

        Please verify your devices to let the developer know what are you on the devices.
        Type Devices:

        Software Version:

        
        """,
        
        """
        Please text in the description of what you have found issues on the Deaf Can Code.
            Description:


        or You can asking the developer if you want request something a new on Deaf Can Code?
        Feature request:

        Please verify your devices to let the developer know what are you on the devices.
            Type Devices:

        Software Version:

                      

        """,
        
        """
        Please text in the description of what you have found issues on the Deaf Can Code.
        Description:

        or you can remind the developer if you know the code to add the dictionary for helping beginner to search about the code information.
        Dictionary request:

        or You can asking the developer if you want request something a new on Deaf Can Code?
        Feature request:

        Please verify your devices to let the developer know what are you on the devices.
        Type Devices:

        Software Version:

                  

        """
    
    ]

    @IBOutlet weak var TableView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.navigationController?.navigationBar.prefersLargeTitles = true
        
          self.navigationItem.title = "Feedback"
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension FeedbackViewController: UITableViewDataSource, UITableViewDelegate {
    
    
   
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 8
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
            
        
        var titleCell: FeedbackTitleTableViewCell!
        var buttonCell: FeedBackButtonsTableViewCell!
        var LearnMoreCells: LearnMoreTableViewCell!
        
         if indexPath.row == 7 {
            
            buttonCell = TableView.dequeueReusableCell(withIdentifier: "ButtonCells") as? FeedBackButtonsTableViewCell
                                                                 
                                                                 buttonCell?.TitleCells?.text = "Resource Deaf Can Code"
                                                                 buttonCell?.IconCells.image = UIImage(named: "Github Icon" )
                                                               
            buttonCell?.ButtonCells.addTarget(self,action: #selector(GitHubLink),for: .touchUpInside)
            buttonCell?.ButtonCells.tag = indexPath.row
                                                                 return buttonCell!
            
        } else if indexPath.row == 6 {
              
            buttonCell = TableView.dequeueReusableCell(withIdentifier: "ButtonCells") as? FeedBackButtonsTableViewCell
                                                      
                                                      buttonCell?.TitleCells?.text = "Rate Deaf Can Code"
                                                      buttonCell?.IconCells.image = UIImage(named: "Icon-6" )
                                                    buttonCell?.ButtonCells.addTarget(self,action: #selector(RateUs),for: .touchUpInside)
                                                               buttonCell?.ButtonCells.tag = indexPath.row
                                                      return buttonCell!
            
        } else if indexPath.row == 5 {
            
            LearnMoreCells = TableView.dequeueReusableCell(withIdentifier: "LearnMore") as? LearnMoreTableViewCell
                                           
                                           LearnMoreCells?.TitleCells?.text = "Learn More"
                                           LearnMoreCells?.IconCells.image = UIImage(named: "Untitled 6-5" )
                                         
                                
            
                                 LearnMoreCells.actionDelegate = self
            LearnMoreCells.index = indexPath.row
                                             return LearnMoreCells!
           
            
        } else if indexPath.row == 4  {
            
           titleCell = TableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FeedbackTitleTableViewCell
            
            titleCell?.textLabel?.font = UIFont.systemFont(ofSize: 20, weight: UIFont.Weight.bold)
                
            titleCell?.textLabel?.text = "About this Version \(Version)"
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .left
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
              
            titleCell.isUserInteractionEnabled = false
            
              return titleCell!
            
        } else if indexPath.row == 3 {
            
            buttonCell = TableView.dequeueReusableCell(withIdentifier: "ButtonCells") as? FeedBackButtonsTableViewCell
                       
                       buttonCell?.TitleCells?.text = "Setting"
                       buttonCell?.IconCells.image = UIImage(named: "Icon-9" )
                     
            buttonCell?.ButtonCells.addTarget(self,action: #selector(showMailComposer),for: .touchUpInside)
            buttonCell?.ButtonCells.tag = indexPath.row
            
                       return buttonCell!
            
        } else if indexPath.row == 2 {
            
            buttonCell = TableView.dequeueReusableCell(withIdentifier: "ButtonCells") as? FeedBackButtonsTableViewCell
                       
                       buttonCell?.TitleCells?.text = "Deaf Can Code"
                       buttonCell?.IconCells.image = UIImage(named: "Icon-10" )
                     
            buttonCell?.ButtonCells.addTarget(self,action: #selector(showMailComposer),for: .touchUpInside)
            buttonCell?.ButtonCells.tag = indexPath.row
            
                       return buttonCell!
            
        } else if indexPath.row == 1 {
            
           buttonCell = TableView.dequeueReusableCell(withIdentifier: "ButtonCells") as? FeedBackButtonsTableViewCell
            
            buttonCell?.TitleCells?.text = "DCC News"
            buttonCell?.IconCells.image = UIImage(named: "Icon-11" )
          
            buttonCell?.ButtonCells.addTarget(self,action: #selector(showMailComposer),for: .touchUpInside)
            buttonCell?.ButtonCells.tag = indexPath.row
            
            return buttonCell!
            
        } else {
        
            titleCell = TableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FeedbackTitleTableViewCell
                   
            titleCell?.textLabel?.text = "If you see any errors, mistakes, or odd behavior in Deaf Can Code? Please share your findings with us to make Deaf Can Code better."
                     
                     titleCell?.textLabel?.numberOfLines = 0
                     titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                     titleCell?.textLabel?.textAlignment = .left
                     titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                     titleCell.isUserInteractionEnabled = false
                     return titleCell!
            
        }
        
        
        
        
    }
    
    
    
    
    
    @objc func GitHubLink (_ btn: UIButton) {
      
           UIApplication.shared.open(URL(string:"https://github.com/Antoniochavez17/DeafCanCode")!, options: [:], completionHandler: nil)
       
     }
    @objc func RateUs (_ btn: UIButton) {
        
        if #available(iOS 10.3, *) {
            SKStoreReviewController.requestReview()
        }
        
    }
    
    
    @objc func showMailComposer (_ btn: UIButton) {
        
        guard MFMailComposeViewController.canSendMail() else {
            //Show alert informing the user
            return
        }
        
        let composer = MFMailComposeViewController()
        composer.mailComposeDelegate = self
        composer.setToRecipients(["deafcancode2018@gmail.com"])
        composer.setSubject(FeedbackTitle[btn.tag])
        composer.setMessageBody(Message[btn.tag], isHTML: false)
        
        present(composer, animated: true)
        
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                     
                     if indexPath.row == 7 {
                         return 60
                     } else if indexPath.row == 6 {
                       return 60
                     } else if indexPath.row == 5 {
                       return 60
                     } else if indexPath.row == 4 {
                       return 40
                     }  else if indexPath.row == 3 {
                       return 60
                     }  else if indexPath.row == 2 {
                       return 60
                     } else if indexPath.row == 1 {
                       return 60
                     } else {
                       return UITableView.automaticDimension
                     }
                     
                 }
    
}


 extension FeedbackViewController: MFMailComposeViewControllerDelegate {
       
       
       func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
           
           if let _ = error {
               //Show error alert
               controller.dismiss(animated: true)
               
               return
           }
           
           switch result {
           case .cancelled:
       
               let cancelalertController = UIAlertController(title: "Mail Has been Cancelled", message: "You've Cancelled This Mail.", preferredStyle: .alert)
               
               controller.present(cancelalertController, animated: true) {
                  sleep(2)
                  cancelalertController.dismiss(animated: true)
               }
            
           
               print("Cancelled")
               
           case .failed:

               let failalertController = UIAlertController(title: "Sending Unsuccessful", message: "please try again!", preferredStyle: .alert)
               
               controller.present(failalertController, animated: true) {
                  sleep(2)
                  failalertController.dismiss(animated: true)
               }
                       
               print("Failed to send")
               
           case .saved:
               
               let savealertController = UIAlertController(title: "mail saved successful", message: "mail saved successfully.", preferredStyle: .alert)
                                   
               
               controller.present(savealertController, animated: true) {
                  sleep(2)
                  savealertController.dismiss(animated: true)
               }
           

               print("Saved")
               
           case .sent:
   
               let sentalertController = UIAlertController(title: "Sending Successful", message: "Thank you for your feedback, we will respond as quickly as possible.", preferredStyle: .alert)
                    
               controller.present(sentalertController, animated: true) {
                  sleep(2)
                  sentalertController.dismiss(animated: true)
               }
               
               
               print("Email Sent")
               
           @unknown default:
               fatalError()
           }
           
           controller.dismiss(animated: true)
           
      }
   }

extension FeedbackViewController: CellActionDelegate {
    
    @objc func didButtonTapped(index: Int) {
        let storybord = UIStoryboard(name: "Main", bundle: nil)
        
        guard let controller = storybord.instantiateViewController(withIdentifier: "LearnMore") as? LearnMoreTableViewController else {
            fatalError("Could not find another view controller")
        }
       
        // controller.modalPresentationStyle = .fullScreen
        self.present(controller, animated: true, completion: nil)
        
    }
}
