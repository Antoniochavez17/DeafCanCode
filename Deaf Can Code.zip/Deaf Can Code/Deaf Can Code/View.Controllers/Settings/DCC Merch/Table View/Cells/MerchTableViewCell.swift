//
//  MerchTableViewCell.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/3/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class MerchTableViewCell: UITableViewCell {

    // Image
    @IBOutlet weak var Merch_Image: UIImageView!
    
    // Title
    @IBOutlet weak var Merch_Title: UILabel!
    
    // Price
    @IBOutlet weak var Merch_Price: UILabel!
    
    // Purchase
  //  @IBOutlet weak var Purchase_Merch: UIButton!
    

    
    @IBOutlet weak var PurchaseMerch: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
