//
//  DCCMerchViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/3/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class DCCMerchViewController: UIViewController {

    @IBOutlet weak var MerchTableView: UITableView!
    
    // MARK: Merch Images
    let imageMerch = ["Untitled 5-1", "Untitled 5-2", "Untitled 5-3", "Untitled 5-4", "Untitled 5-5", "Untitled 5-6", "Untitled 5-7", "Untitled 5-8", "Untitled 5-9", "Untitled 5-9", "Untitled 5-11", "Untitled 5-10", "Untitled 5-12", "Untitled 5-13", "Untitled 5-15", "Untitled 5-16", "Untitled 5-17", "Backpack-5", "Backpack-1", "Untitled 5-18", "Untitled 51", "Untitled 5-19", "Untitled 5-20"]
    
    // MARK: Merch Titles
    let titleMerch = ["Premium Hoodie", "Classic Hoodie", "Premium Tee", "Classic Tee", "Woman Comfort Tree", "Woman Classic Tee", "Kid Premium Tee", "Kid Premium Hoodie", "Die Cut Sticker", "Sticker", "24' x 36' Poster", " 18' x 24' Poster", "Fleece Blanket", "Wall Tapestry", "Tote Bag", "Mug", "Indoor Pillow", "Casual Backpack", "Backpack (Made in USA)", "Vintage DCC soft cases", "Travel Mug", "Spiral Notebook", "Hardcover Journal"]
    
    // MARK: Merch Prices
    let priceMerch = ["44.99", "38.99", "23.99", "21.99", "22.99", "21.99", "18.99", "33.99", "7.99", "5.99", "23.99", "20.99", "23.99", "20.99", "20.99", "23.99", "20.99", "54.75", "62.18", "21.00", "25.25", "12.62", "20.51"]
    
    // MARK: Merch Links
    var buyLink = [
        "https://teespring.com/DeafCanCodeMarch?pid=227&cid=2664",
        "https://teespring.com/DeafCanCodeMarch?pid=175&cid=4789",
        "https://teespring.com/DeafCanCodeMarch?pid=46&cid=2742",
        "https://teespring.com/DeafCanCodeMarch?pid=2&cid=2397",
        "https://teespring.com/DeafCanCodeMarch?pid=370&cid=6531",
        "https://teespring.com/DeafCanCodeMarch?pid=87&cid=2325",
        "https://teespring.com/DeafCanCodeMarch?pid=371&cid=6548",
        "https://teespring.com/DeafCanCodeMarch?pid=175&cid=4789",
        "https://teespring.com/DeafCanCodeMarch?pid=794&cid=103544",
        "https://teespring.com/DeafCanCodeMarch?pid=663&cid=102920",
        "https://teespring.com/DeafCanCodeMarch?pid=624&cid=102380",
        "https://teespring.com/DeafCanCodeMarch?pid=623&cid=102381",
        "https://teespring.com/DeafCanCodeMarch?pid=721&cid=103163",
        "https://teespring.com/DeafCanCodeMarch?pid=584&cid=102309",
        "https://teespring.com/DeafCanCodeMarch?pid=526&cid=101936",
        "https://teespring.com/DeafCanCodeMarch?pid=658&cid=102950",
        "https://teespring.com/DeafCanCodeMarch?pid=585&cid=102398",
        "https://www.ebay.com/itm/223676283962",
        "https://www.ebay.com/itm/223676283937",
    "https://www.redbubble.com/people/antoniochavez17/works/44515327-untitled?asc=u&p=iphone-case&rel=carousel",
    "https://www.redbubble.com/people/antoniochavez17/works/44515327-untitled?asc=u&p=travel-mug&rel=carousel",
    
    "https://www.redbubble.com/people/antoniochavez17/works/44515327-untitled?asc=u&p=spiral-notebook&rel=carousel",
    
    "https://www.redbubble.com/people/antoniochavez17/works/44515327-untitled?asc=u&p=hardcover-journal&rel=carousel"
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let headerView = UIView()
          let footerView = UIView()
               
          headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
          footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
               
        let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 3.8)
               
          headerView.frame = sizeView
          footerView.frame = sizeView
          MerchTableView.tableHeaderView = headerView
          MerchTableView.tableFooterView = footerView
    }

}

extension DCCMerchViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return titleMerch.count
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 128
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let merchCell = MerchTableView.dequeueReusableCell(withIdentifier: "MerchCells", for: indexPath) as? MerchTableViewCell
        
        // Image
        merchCell?.Merch_Image.image = UIImage(named: imageMerch[indexPath.row])
        
        // Title
        merchCell?.Merch_Title.text = titleMerch[indexPath.row]
        
        // Price
        merchCell?.Merch_Price.text = "Price: $\( priceMerch[indexPath.row])"
        
        // Purchase
        merchCell?.PurchaseMerch.addTarget(self,action: #selector(clicked),for: .touchUpInside)
        merchCell?.PurchaseMerch.tag = indexPath.row
        
        return merchCell!
  }
    
  @objc func clicked (_ btn: UIButton) {
   
        UIApplication.shared.open(URL(string:buyLink[btn.tag])!, options: [:], completionHandler: nil)
    
  }
    
}


