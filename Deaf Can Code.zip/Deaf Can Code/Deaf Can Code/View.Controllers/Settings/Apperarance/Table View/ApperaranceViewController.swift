//
//  ApperaranceViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/17/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class ApperaranceViewController: UIViewController {
    
    @IBOutlet weak var ApperaranceTableView: UITableView!
    
    var ApperaranceTitle = ["Icon Apperarance", "Code Apperarance", "Font Apperarance", "Interface Apperarance"]
    
    var footerTitle = ["Change the custom DCC Icon on your Home Screen to your liking.", "Change the custom color for the syntax code appearance. (Coming Soon!)", "Change the custom font for the only code appearance. (Coming Soon!)", "Change the custom color in the Deaf Can Code interfaces. (Coming Soon!)"]
    
    
    var avaiableIcon = ["Untitled 6", "Untitled 7", "Untitled 7", "Untitled 7"]
    
    var icons = ["IconTheme", "Untitled 31-1", "Untitled 31", "Untitled 31-2"]
    
    var StoryboardID = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
    // Do any additional setup after loading the view.
        
        self.navigationItem.title = "Apperarance"
        
        let headerView = UIView()
           
                  
             headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
            
                  
             let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 4)
                  
             headerView.frame = sizeView
      
           
              ApperaranceTableView.tableHeaderView = headerView
        
        StoryboardID = ["IconTheme", "", "", ""]
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension ApperaranceViewController: UITableViewDataSource, UITableViewDelegate {
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ApperaranceTitle.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cells: ApperaranceTableViewCell!
        
        cells = ApperaranceTableView.dequeueReusableCell(withIdentifier: "ApperaranceCells") as? ApperaranceTableViewCell
        
        cells?.ApperaranceIcon?.image = UIImage(named: icons[indexPath.row])
        
        cells?.ApperaranceTitle?.text = ApperaranceTitle[indexPath.row]
        
        cells?.ForwardIcon?.image = UIImage(named: avaiableIcon[indexPath.row])
        
        cells?.ApperaranceFooter.text = footerTitle[indexPath.row]
        
        return cells!
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
          return 100
       
         }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

           if indexPath.row == 0 {
        let vcName = StoryboardID[indexPath.row]

        let Swift = storyboard?.instantiateViewController(withIdentifier: vcName)


        self.navigationController?.pushViewController(Swift!, animated: true)

          }
        }
       
    
    
}
