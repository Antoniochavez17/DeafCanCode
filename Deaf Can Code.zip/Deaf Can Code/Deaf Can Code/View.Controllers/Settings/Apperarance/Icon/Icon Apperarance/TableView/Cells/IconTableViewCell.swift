//
//  IconTableViewCell.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/10/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class IconTableViewCell: UITableViewCell {

    @IBOutlet weak var IconImg: UIImageView!
    @IBOutlet weak var IconName: UILabel!
    @IBOutlet weak var CreditName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
