//
//  IconThemeViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/10/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class IconThemeViewController: UIViewController {
    
    @IBOutlet weak var IconTheme: UITableView!
    
    // Display the Icons
    let imageIcon = [
    "DCCDefault",
    "DCCSixColor",
    "DCC1976Raindow",
    "DCCVintagelight" ,
    "DCCVintageDark",
    "DCCBlueNeon",
    "DCCGreenNeon",
    "DCCLightBlueNeon",
    "DCCPinkNeon",
    "DCCPurpleNeon",
    "DCCWhiteNeon",
    "DCCYellowNeon",
    "DCCCode",
    "DCCWinterSeason"
    ]
    
    // Titles
    let nameIcon = [
    "DCC Default",
    "Six Color",
    "Old Apple 1976",
    "Vintage DCC (Light)",
    "Vintage DCC (Dark)",
    "Blue Neons",
    "Green Neons",
    "Light Blue Neons",
    "Pink Neons",
    "Purple Neons",
    "White Neons",
    "Yellow Neons",
    "Code",
    "Winter Season"
    ]
    
    
    // Credits
    let credits = [
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176",
        "Credit by @antonio07341176"
    ]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let headerView = UIView()
        let footerView = UIView()
                          
        headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
        footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
                          
        let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 3.5)
        
        headerView.frame = sizeView
        footerView.frame = sizeView
        IconTheme.tableHeaderView = headerView
        IconTheme.tableFooterView = footerView
        
        self.navigationItem.title = "Icon Apperarance"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension IconThemeViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameIcon.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
         let IconCells = IconTheme.dequeueReusableCell(withIdentifier: "IconTheme", for: indexPath) as? IconTableViewCell
        
        IconCells?.IconName.text = "   \(nameIcon[indexPath.row])"
        IconCells?.IconImg.image = UIImage(named: imageIcon[indexPath.row])
        IconCells?.IconImg.layer.masksToBounds = true
        IconCells?.IconImg.layer.borderWidth = 0.5
        IconCells?.IconImg.layer.borderColor = UIColor.white.cgColor
        IconCells?.IconImg.layer.cornerRadius = (IconCells?.IconImg.bounds.width)! / 5
        IconCells?.CreditName.text = "   \(credits[indexPath.row])"
        
        return IconCells!
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        if indexPath.row == 13 {
            
            UIApplication.shared.setAlternateIconName("DCCWinterSeason")
            
        } else if indexPath.row == 12 {
            
            UIApplication.shared.setAlternateIconName("DCCCode")
            
        } else if indexPath.row == 12 {
            
            UIApplication.shared.setAlternateIconName("DCCYellowNeon")
            
        } else if indexPath.row == 10 {
            
            UIApplication.shared.setAlternateIconName("DCCWhiteNeon")
            
        } else if indexPath.row == 9 {
            
            UIApplication.shared.setAlternateIconName("DCCPurpleNeon")
            
        } else if indexPath.row == 8 {
            
            UIApplication.shared.setAlternateIconName("DCCPinkNeon")
            
        } else if indexPath.row == 7 {
            
            UIApplication.shared.setAlternateIconName("DCCLightBlueNeon")
            
        } else if indexPath.row == 6 {
            
            UIApplication.shared.setAlternateIconName("DCCGreenNeon")
            
        } else if indexPath.row == 5 {
            
            UIApplication.shared.setAlternateIconName("DCCBlueNeon")
            
        } else if indexPath.row == 4 {
            
            UIApplication.shared.setAlternateIconName("DCCVintageDark")
            
        } else if indexPath.row == 3 {
            
            UIApplication.shared.setAlternateIconName("DCCVintagelight")
            
        } else if indexPath.row == 2 {
            
            UIApplication.shared.setAlternateIconName("DCC1976Raindow")
            
        } else if indexPath.row == 1 {
            
            UIApplication.shared.setAlternateIconName("DCCSixColor")
            
        } else {
            
            UIApplication.shared.setAlternateIconName(nil)
        }
        
        
    }
    
}
