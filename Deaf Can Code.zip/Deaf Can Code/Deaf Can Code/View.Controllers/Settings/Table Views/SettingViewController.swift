//
//  SettingViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/6/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class SettingViewController: UIViewController {
    
// MARK: Setting Table View
    
    // Setting Icon
    var settingiconName = ["Untitled 6-4", "Untitled 6-5", "Untitled 6-6", "Untitled 6-7", "IconTheme", ""]
         
    //Setting Sections
    var settingtitle = ["Deaf Can Code Merch", "Feedback", "Deaf Can Code Policy", "Credits", "Apperarance", ""]
    
    // Setting Storyboard ID
    var StoryboardID = [String]()
     
    // Setting Footers
    var footerTitle = ["Check out our awesome products in our store!", "Report and problems or bugs here.", "View Deaf Can Code's user agreements.", "A special thanks to those who helped Deaf Can Code." , "Change the custom Deaf Can Code with the apperarance.", ""]

    @IBOutlet weak var TableView: UITableView!
    
    override func viewDidLoad() {
      super.viewDidLoad()
        
        
        
       // Remove border
        self.TableView.separatorStyle = UITableViewCell.SeparatorStyle.none
    
        // MARK: Status Bars
        if #available(iOS 13.0, *) {
            
           let navBarAppearance = UINavigationBarAppearance()
           let navigationBar = self.navigationController?.navigationBar
           navBarAppearance.configureWithOpaqueBackground()
           navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
           navBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
           navBarAppearance.backgroundColor = #colorLiteral(red: 0.1603881121, green: 0.1677560508, blue: 0.2133775949, alpha: 1)
           navigationBar!.standardAppearance = navBarAppearance
           navigationBar!.scrollEdgeAppearance = navBarAppearance
                        
        } else {
                        
           navigationController?.navigationBar.barStyle = .black
                    
        }
        
        StoryboardID = ["Merch", "FeedBack", "Policy", "Credits", "Apperarance"]
      

        let headerView = UIView()
        let footerView = UIView()
             
        headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
        footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
             
        let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 4)
             
        headerView.frame = sizeView
        footerView.frame = sizeView
      
         TableView.tableHeaderView = headerView
     
        
        }
   

    }



extension SettingViewController: UITableViewDelegate, UITableViewDataSource, UISplitViewControllerDelegate {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return settingtitle.count
                
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == 5 {
          return 61
        } else if indexPath.row == 4 {
          return 100
        }  else if indexPath.row == 3 {
          return 100
        }  else if indexPath.row == 2 {
          return 100
        } else if indexPath.row == 1 {
          return 100
        } else {
          return 100
        }
        
    }
        
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
               
        var cells: SettingTableViewCell!
        var versionCells: VersionTableViewCell!
                
        if indexPath.row == 5 {
                    
           versionCells = TableView.dequeueReusableCell(withIdentifier: "VersionCells", for: indexPath) as? VersionTableViewCell
                          
           versionCells?.VersionTitle?.text = """
           Copyright © \(CopyrightYears) Deaf Can Code
           Version: \(Version)
           """
           versionCells?.textLabel?.textAlignment = .center
                          
           versionCells.isUserInteractionEnabled = false
            
           return versionCells!
            
        } else {
          
           cells = TableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? SettingTableViewCell
                               
                               
           cells?.Setting_Title.text = settingtitle[indexPath.row]
                               
           cells?.Footer_Title.text = footerTitle[indexPath.row]

           cells?.Setting_Image.image = UIImage(named: settingiconName[indexPath.row])
                            
                               
           return cells!
        }
    }
            
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                
                   
        let vcName = StoryboardID[indexPath.row]
                   
        let Swift = storyboard?.instantiateViewController(withIdentifier: vcName)
                  
                
        self.navigationController?.pushViewController(Swift!, animated: true)
                   
        }

    }
