//
//  SettingTableViewCell.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/6/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class SettingTableViewCell: UITableViewCell {

    @IBOutlet weak var Setting_Image: UIImageView!
    @IBOutlet weak var Setting_Title: UILabel!
    
    @IBOutlet weak var ForwardIcon: UIImageView!
    
    @IBOutlet weak var ViewBackground: UIView!
    
    @IBOutlet weak var Footer_Title: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
