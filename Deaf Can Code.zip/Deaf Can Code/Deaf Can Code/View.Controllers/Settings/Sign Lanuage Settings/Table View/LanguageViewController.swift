//
//  LanguageViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/17/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class LanguageViewController: UIViewController {

    var LanguageTitle = ["Why does Langauge settings induct in the Deaf Can Code Settings? The Deaf Can Code allows the source of the many sign languages for the deaf communities to learning the code with the sign language in the code tutorials only. The new language feature will come soon in the future.", "", "", ""]
    
    @IBOutlet var LanguageTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        LanguageTableView.rowHeight = UITableView.automaticDimension
        
        self.navigationItem.title = "Langauge Settings"
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension LanguageViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let titleCell: LanguageTitleTableViewCell!
              let SwitchCell: LanguageTableViewCell!
              
              
               if indexPath.row == 3 {
                  
                  SwitchCell = LanguageTableView.dequeueReusableCell(withIdentifier: "SwitchCells") as? LanguageTableViewCell
                  
                  SwitchCell?.TitleCells?.text = "SSL"
                  SwitchCell?.FooterCells?.text = "Spanish Sign Language (Coming Soon!)"
                  
                  return SwitchCell!
                  
              } else if indexPath.row == 2 {
                  
                  SwitchCell = LanguageTableView.dequeueReusableCell(withIdentifier: "SwitchCells") as? LanguageTableViewCell
                  
                  SwitchCell?.TitleCells?.text = "ASL"
                  SwitchCell?.FooterCells?.text = "American Sign Language (Coming Soon!)"
                  
                  return SwitchCell!
                  
              }else if indexPath.row == 1 {
                  
                  SwitchCell = LanguageTableView.dequeueReusableCell(withIdentifier: "SwitchCells") as? LanguageTableViewCell
                  
                  SwitchCell?.TitleCells?.text = "SEE"
                  SwitchCell?.FooterCells?.text = "Sign Exact English"
                  
                  return SwitchCell!
                  
              }else {
                  titleCell = LanguageTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LanguageTitleTableViewCell
                             
                      titleCell?.textLabel?.text = "Why does Langauge settings induct in the Deaf Can Code Settings? The Deaf Can Code allows the source of the many sign languages for the deaf communities to learning the code with the sign language in the code tutorials only. The new language feature will come soon in the future."
                               
                               titleCell?.textLabel?.numberOfLines = 0
                               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                               titleCell?.textLabel?.textAlignment = .left
                               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                               
                               return titleCell!
              }
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return LanguageTitle.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == 3 {
           return 97
       } else if indexPath.row == 2 {
           return 97
       } else if indexPath.row == 1 {
           return 97
       } else {
           return UITableView.automaticDimension
       }
    
  
    }
    
    
}
