//
//  PolicyViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/5/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class PolicyViewController: UIViewController {

    struct Object {
      var seactionName: String!
      var seactionObjection: [String]!
    }
       
    var objectArray = [Object]()
       
    @IBOutlet weak var PolicyTableView: UITableView!
        
        
    override func viewDidLoad() {
      super.viewDidLoad()

      objectArray = [
        
        Object(seactionName: "No Hacking Tutorials", seactionObjection: ["Deaf Can Code doesn't teach how to hacking. Deaf Can Code always to teaching how ot build the application based on the Swift."]),
        
        Object(seactionName: "Copyright", seactionObjection: ["Those videos have official copyright reserved by Antonio A. Chavez. Deaf Can Code application has some credit to someone. You can looks more credits in the Settings > Credits"]),
        
        Object(seactionName: "Privacy", seactionObjection: ["Deaf Can Code doesn't have an account in the privacy policy because the Deaf Can Code is completely free! Deaf Can Code will delete your email after the issues have patched, which Deaf Can Code had received your reported in the Feedback."]),
        
        Object(seactionName: "Respect Each Others", seactionObjection: ["Hating, offense, racist, indecent, expletive is unappreciated on the Deaf Can Code. Deaf Can Code always have to respect someone but don't like to see their behavior thought contacts, comments around online. Deaf Can Code Founder is brought friendly respect to all communities."])]
        }
       
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            
        }
        
        
       
    }

    extension PolicyViewController: UITableViewDataSource, UITableViewDelegate {
        
    
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = PolicyTableView.dequeueReusableCell(withIdentifier: "Cells")
            cell?.textLabel?.text = objectArray[indexPath.section].seactionObjection[indexPath.row]
            
            cell?.textLabel!.textColor = .white
            cell?.textLabel!.numberOfLines = 0
            cell?.textLabel!.lineBreakMode = .byWordWrapping
            cell?.selectionStyle = UITableViewCell.SelectionStyle.none
            return cell!
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return objectArray[section].seactionObjection.count
           }
        
        func numberOfSections(in tableView: UITableView) -> Int {
            return objectArray.count
        }
        
        func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            
            return objectArray[section].seactionName
        }
        
        func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int){
                 view.tintColor = #colorLiteral(red: 0.1564497352, green: 0.1637369096, blue: 0.2134993672, alpha: 1)
                 let header = view as! UITableViewHeaderFooterView
                 header.textLabel?.textColor = UIColor.white
             }
    
        

}
