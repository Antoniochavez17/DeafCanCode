//
//  option_SwiftTableViewCell.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 11/29/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class option_SwiftTableViewCell: UITableViewCell {
    
    @IBOutlet weak var OptionIcon: UIImageView!
    @IBOutlet weak var OptionTitle: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
