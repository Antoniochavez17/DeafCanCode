//
//  Options_SwiftViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 11/29/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class Options_SwiftViewController: UIViewController {
    
    
    let optionalTitle = ["", "Study", "Quiz"]
    let optionImage = ["", "Untitled 6-13", "Untitled 6-6"]
    var identities = [String]()
        

    @IBOutlet weak var optionTableView: UITableView!
    
    
     override func viewWillAppear(_ animated: Bool) {
          super.viewWillAppear(animated)
      
      
         let app = UINavigationBarAppearance()
                app.configureWithTransparentBackground()
               
              app.shadowImage = UIImage()
              self.navigationController?.navigationBar.standardAppearance = app
                self.navigationController?.navigationBar.scrollEdgeAppearance = app
                self.navigationController?.navigationBar.compactAppearance = app
                 
          
      }

      override func viewWillDisappear(_ animated: Bool) {
          super.viewWillDisappear(animated)
          
              
    
     let app = UINavigationBarAppearance()
           
           let navigationBar = self.navigationController?.navigationBar
            
      app.backgroundColor = .clear
                app.configureWithOpaqueBackground()
                
                
            
            app.configureWithOpaqueBackground()
                app.titleTextAttributes = [.foregroundColor: UIColor.white]
                app.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
                app.backgroundColor = #colorLiteral(red: 0.1603881121, green: 0.1677560508, blue: 0.2133775949, alpha: 1)
       self.navigationController?.navigationBar.scrollEdgeAppearance = app
                
              
                navigationBar!.standardAppearance = app
                navigationBar!.scrollEdgeAppearance = app
      
      }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // automatic height cells which you don't need add height for each cells
              optionTableView.rowHeight = UITableView.automaticDimension
              
        
         identities = ["", "SwiftTutorials", "Quiz"]
      
    let headerView = UIView()
    let footerView = UIView()
        
        headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
        footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
        
        let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 3.5)
        
        headerView.frame = sizeView
        footerView.frame = sizeView
        optionTableView.tableHeaderView = headerView
        optionTableView.tableFooterView = footerView
    }

}

extension Options_SwiftViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 2 {
            return 60
        } else if indexPath.row == 1 {
            return 60
        } else {
            return UITableView.automaticDimension
        }
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        var title: OptionTitleTableViewCell!
        var optioncells: option_SwiftTableViewCell!
                           
        
        if indexPath.row == 2 {
            optioncells = optionTableView.dequeueReusableCell(withIdentifier: "OptionsCells", for: indexPath) as? option_SwiftTableViewCell
                 
            
                 optioncells?.OptionTitle.text =  optionalTitle[indexPath.row]
               
                 optioncells?.OptionIcon.image = UIImage(named: optionImage[indexPath.row])
             
                 
                 return optioncells!
        } else if indexPath.row == 1 {
            optioncells = optionTableView.dequeueReusableCell(withIdentifier: "OptionsCells", for: indexPath) as? option_SwiftTableViewCell
                 
            
                 optioncells?.OptionTitle.text =  optionalTitle[indexPath.row]
               
                 optioncells?.OptionIcon.image = UIImage(named: optionImage[indexPath.row])
             
                 
                 return optioncells!
        } else {
             title = optionTableView.dequeueReusableCell(withIdentifier: "OptionsTitleCells", for: indexPath) as? OptionTitleTableViewCell
   
            // MARK: Nsattributedstring
                            
          let imageAttachment = NSTextAttachment()
            imageAttachment.image = UIImage(systemName: "square.and.pencil")?.withTintColor(dynamicBackground)

                      let fullString = NSMutableAttributedString(string: "Welcome to Swift Tutorials! If you have a macOS model, then download an Xcode on the App Store. Open Xcode, tap Get started with a playground on the Xcode. If you have iPadOS devices, then download the Swift Playgrounds, tap the ")
            
                      fullString.append(NSAttributedString(attachment: imageAttachment))
                      
                      fullString.append(NSAttributedString(string: ", then let's start to learn a Swift Language on the playground! Oh, If you doesn't have any of the macOS and iPadOS devices? No worries! It has an answer under the code conecpt."))

            
            
            title?.textLabel?.attributedText = fullString
            title.isUserInteractionEnabled = false
            title?.textLabel?.numberOfLines = 0
            title?.textLabel?.lineBreakMode = .byWordWrapping
            title?.textLabel?.textAlignment = .justified
            title?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
            
            return title!
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
   
        
        let vcName = identities[indexPath.row]
        
        let Swift = storyboard?.instantiateViewController(withIdentifier: vcName)
        self.navigationController?.pushViewController(Swift!, animated: true)
        
    }
}
