//
//  SwitchViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class SwitchViewController: UIViewController {

    @IBOutlet weak var SwitchTableView: UITableView!
    @IBOutlet weak var SwitchVideos: WKWebView!
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        SwitchTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Switchs"
        
        Label(IDCode: "eAmszaSCOLU")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        SwitchVideos.load(URLRequest(url: url!))

    }

}

extension SwitchViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: SwitchTitleTableViewCell!
        var code: SwitchCodeTableViewCell!
        var answer: SwitchAnswerTableViewCell!
        
        if indexPath.row == 19 {
            answer = SwitchTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SwitchAnswerTableViewCell
                                                                 answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                                                 answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                                                 answer?.textLabel?.text = """
                                                                 300.27 is moderate level.
                                                                 """
                                                                 answer?.textLabel?.numberOfLines = 0
                                                                 answer?.textLabel?.lineBreakMode = .byWordWrapping
                                                                 answer?.textLabel?.textAlignment = .center
                                                                 answer?.textLabel?.textColor = UIColor.white
                                                                 return answer!
        } else if indexPath.row == 18 {
            
               code = SwitchTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SwitchCodeTableViewCell
              
               code?.textLabel?.font = setFont
            
              // MARK: Nsattributedstring
                                                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "radioactive_Level ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "300.27\n", attributes: [.foregroundColor: NumberSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
            
               attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "switch ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "Radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "5", attributes: [.foregroundColor: NumberSyntax]))
                
            attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            attr.append(NSAttributedString(string: "100 ", attributes: [.foregroundColor: NumberSyntax]))
            attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                              
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                      attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                                       
                                                              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                             attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                             
                                                             attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                                               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                          
                                                               attr.append(NSAttributedString(string: "Radioactive_Level", attributes: [.foregroundColor: projectSyntax]))

                                                                      attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                                             attr.append(NSAttributedString(string: " is tolerable level.\"", attributes: [.foregroundColor: StringSyntax]))
                                                                                
                                                              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                               
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                       attr.append(NSAttributedString(string: "100", attributes: [.foregroundColor: NumberSyntax]))
                          
                      attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                      attr.append(NSAttributedString(string: "500 ", attributes: [.foregroundColor: NumberSyntax]))
                      attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                                        
                      attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                                                 
                                                                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                       attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                                       
                                                                       attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                                                         attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                    
                                                                         attr.append(NSAttributedString(string: "Radioactive_Level", attributes: [.foregroundColor: projectSyntax]))

                                                                                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                                                       attr.append(NSAttributedString(string: " is moderate level.\"", attributes: [.foregroundColor: StringSyntax]))
                                                                                          
                                                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                               
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      attr.append(NSAttributedString(string: "default ", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                      attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                                        
                      attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                                                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                                                 
                                                                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                       attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                                       
                                                                       attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                                                         attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                    
                                                                         attr.append(NSAttributedString(string: "Radioactive_Level", attributes: [.foregroundColor: projectSyntax]))

                                                                                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                                                       attr.append(NSAttributedString(string: " is high risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                                                                                          
                                                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                   
              
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
                                      attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))

            code?.textLabel?.attributedText = attr
            
            
            
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                    code?.textLabel?.numberOfLines = 0
                    code?.textLabel?.lineBreakMode = .byWordWrapping
                    code?.textLabel?.textAlignment = .left
                                          
                                            
                    return code!
        } else if indexPath.row == 17 {
             titleCell = SwitchTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SwitchTitleTableViewCell
            titleCell?.textLabel?.text = "The final tutorials, I can show you how does switch between if, else, else if look familar. Which do you prefer this switch or if, else, else if?"
                                                      
                                                      titleCell?.textLabel?.numberOfLines = 0
                                                      titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                                      titleCell?.textLabel?.textAlignment = .center
                                                      titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                                      
                                                      return titleCell!
        } else if indexPath.row == 16 {
            answer = SwitchTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SwitchAnswerTableViewCell
                                                      answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                                      answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                                      answer?.textLabel?.text = """
                                                      The request failed with the error: 508 is not a known error code
                                                      """
                                                      answer?.textLabel?.numberOfLines = 0
                                                      answer?.textLabel?.lineBreakMode = .byWordWrapping
                                                      answer?.textLabel?.textAlignment = .center
                                                      answer?.textLabel?.textColor = UIColor.white
                                                      return answer!
        } else if indexPath.row == 15 {
            
               code = SwitchTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SwitchCodeTableViewCell
              
               code?.textLabel?.font = setFont
            
              // MARK: Nsattributedstring
                                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                        
                                        attr.append(NSAttributedString(string: "statusCode", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                        attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                        attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))
                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                            attr.append(NSAttributedString(string: "508 \n", attributes: [.foregroundColor: projectSyntax]))

                            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                            
                               attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                            attr.append(NSAttributedString(string: "\"The request failed with the error: \"\n", attributes: [.foregroundColor: StringSyntax]))
                            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                            attr.append(NSAttributedString(string: "switch ", attributes: [.foregroundColor: KeyboardSyntax]))
                            attr.append(NSAttributedString(string: "statusCode ", attributes: [.foregroundColor: projectSyntax]))
                            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                            attr.append(NSAttributedString(string: " case ", attributes: [.foregroundColor: KeyboardSyntax]))
                            attr.append(NSAttributedString(string: "100", attributes: [.foregroundColor: NumberSyntax]))
                            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                            attr.append(NSAttributedString(string: "103", attributes: [.foregroundColor: NumberSyntax]))
                               attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                            attr.append(NSAttributedString(string: "105", attributes: [.foregroundColor: NumberSyntax]))
                               attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                               attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                              
                            attr.append(NSAttributedString(string: "+=  ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                               attr.append(NSAttributedString(string: "\"Infomational, 1xx\" \n", attributes: [.foregroundColor: StringSyntax]))
                            
                            
                            
                            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                             attr.append(NSAttributedString(string: "case let ", attributes: [.foregroundColor: KeyboardSyntax]))
                             attr.append(NSAttributedString(string: "unknownCode ", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "where ", attributes: [.foregroundColor: KeyboardSyntax]))
             attr.append(NSAttributedString(string: "(unknownCode ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            attr.append(NSAttributedString(string: "100 ", attributes: [.foregroundColor: NumberSyntax]))
            attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "|| ", attributes: [.foregroundColor: OtherDecluarationSyntax]))

            attr.append(NSAttributedString(string: "unknownCode ", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "> ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
              attr.append(NSAttributedString(string: "500", attributes: [.foregroundColor: NumberSyntax]))

            attr.append(NSAttributedString(string: ": \n", attributes: [.foregroundColor: PlainSyntax]))
                                 attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                            attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                                         
                                       attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                          attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                                    
                                                                    attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                                                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                 
                                                                      attr.append(NSAttributedString(string: "unknownCode", attributes: [.foregroundColor: PlainSyntax]))

                                                                             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                                                    attr.append(NSAttributedString(string: " is not a known error code.\"\n", attributes: [.foregroundColor: StringSyntax]))

                            attr.append(NSAttributedString(string: "8.\n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "default", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                                            
                                          attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                             attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                                       
                                                            attr.append(NSAttributedString(string: "unexpected error encountred.\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
                            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                         
                                  
                                       
                                         code?.textLabel?.attributedText = attr

                    
                    code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                    code?.textLabel?.numberOfLines = 0
                    code?.textLabel?.lineBreakMode = .byWordWrapping
                    code?.textLabel?.textAlignment = .left
                                          
                                            
                    return code!
        } else if indexPath.row == 14 {
             titleCell = SwitchTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SwitchTitleTableViewCell
            titleCell?.textLabel?.text = "The where keyboard allows you to point the value in which you want to upload the second value to match to statusCode's value to execute the errorStrings. In which means unknownCode has set the 0 between 100 and 500 and above, then it'll execute. Otherwise, It'll execute default's value if the statusCode hasn't match any of the cases."
                                              
                                              titleCell?.textLabel?.numberOfLines = 0
                                              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                              titleCell?.textLabel?.textAlignment = .center
                                              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                              
                                              return titleCell!
        } else if indexPath.row == 13 {
            answer = SwitchTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SwitchAnswerTableViewCell
                                           answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                           answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                           answer?.textLabel?.text = """
                                           The request failed with the error: 508 is not a known error code
                                           """
                                           answer?.textLabel?.numberOfLines = 0
                                           answer?.textLabel?.lineBreakMode = .byWordWrapping
                                           answer?.textLabel?.textAlignment = .center
                                           answer?.textLabel?.textColor = UIColor.white
                                           return answer!
        } else if indexPath.row == 12 {
            
               code = SwitchTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SwitchCodeTableViewCell
              
              code?.textLabel?.font = setFont
              
                    // MARK: Nsattributedstring
                                              let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                              attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                              
                                              attr.append(NSAttributedString(string: "statusCode", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                              attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                              attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "505 \n", attributes: [.foregroundColor: projectSyntax]))

                                  attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                                  attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                  
                                     attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "\"The request failed with the error: \"\n", attributes: [.foregroundColor: StringSyntax]))
                                  attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                  attr.append(NSAttributedString(string: "switch ", attributes: [.foregroundColor: KeyboardSyntax]))
                                  attr.append(NSAttributedString(string: "statusCode ", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                  attr.append(NSAttributedString(string: " case ", attributes: [.foregroundColor: KeyboardSyntax]))
                                  attr.append(NSAttributedString(string: "100", attributes: [.foregroundColor: NumberSyntax]))
                                  attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "103", attributes: [.foregroundColor: NumberSyntax]))
                                     attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "105", attributes: [.foregroundColor: NumberSyntax]))
                                     attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                                     attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                     attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                                    
                                  attr.append(NSAttributedString(string: "+=  ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                     attr.append(NSAttributedString(string: "\"Infomational, 1xx\" \n", attributes: [.foregroundColor: StringSyntax]))
                                  
                                  
                                  
                                  attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                                   attr.append(NSAttributedString(string: "default", attributes: [.foregroundColor: KeyboardSyntax]))
                                   attr.append(NSAttributedString(string: ": \n", attributes: [.foregroundColor: PlainSyntax]))
                                       attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                  attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                                               
                                             attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                                attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                                          
                                                                          attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                                                            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                       
                                                                            attr.append(NSAttributedString(string: "unknownCode", attributes: [.foregroundColor: PlainSyntax]))

                                                                                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                                                          attr.append(NSAttributedString(string: " is not a known error code.\"\n", attributes: [.foregroundColor: StringSyntax]))

                                  attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                  attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                               
                                        
                                             
                                               code?.textLabel?.attributedText = attr

            
                    code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                    code?.textLabel?.numberOfLines = 0
                    code?.textLabel?.lineBreakMode = .byWordWrapping
                    code?.textLabel?.textAlignment = .left
                                          
                                            
                    return code!
        } else if indexPath.row == 11 {
             titleCell = SwitchTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SwitchTitleTableViewCell
            titleCell?.textLabel?.text = "If you don't need value bundling in the Switch's statements, then you can replace this value bundling to default at the end."
                                       
                                       titleCell?.textLabel?.numberOfLines = 0
                                       titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                       titleCell?.textLabel?.textAlignment = .center
                                       titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                       
                                       return titleCell!
        } else if indexPath.row == 10 {
            answer = SwitchTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SwitchAnswerTableViewCell
                                 answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                 answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                 answer?.textLabel?.text = """
                                   The request failed with the error: 508 is not a known error code
                                 """
                                 answer?.textLabel?.numberOfLines = 0
                                 answer?.textLabel?.lineBreakMode = .byWordWrapping
                                 answer?.textLabel?.textAlignment = .center
                                 answer?.textLabel?.textColor = UIColor.white
                                 return answer!
        } else if indexPath.row == 9 {
            
    
            code = SwitchTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SwitchCodeTableViewCell
                      
            code?.textLabel?.font = setFont
                      // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "statusCode", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "505 \n", attributes: [.foregroundColor: projectSyntax]))

                    attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                    attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                    
                       attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"The request failed with the error: \"\n", attributes: [.foregroundColor: StringSyntax]))
                    attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                    attr.append(NSAttributedString(string: "switch ", attributes: [.foregroundColor: KeyboardSyntax]))
                    attr.append(NSAttributedString(string: "statusCode ", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                    attr.append(NSAttributedString(string: " case ", attributes: [.foregroundColor: KeyboardSyntax]))
                    attr.append(NSAttributedString(string: "100", attributes: [.foregroundColor: NumberSyntax]))
                    attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "103", attributes: [.foregroundColor: NumberSyntax]))
                       attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "105", attributes: [.foregroundColor: NumberSyntax]))
                       attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                       attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                      
                    attr.append(NSAttributedString(string: "+=  ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                       attr.append(NSAttributedString(string: "\"Infomational, 1xx\" \n", attributes: [.foregroundColor: StringSyntax]))
                    
                    
                    
                    attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                     attr.append(NSAttributedString(string: "case let ", attributes: [.foregroundColor: KeyboardSyntax]))
                     attr.append(NSAttributedString(string: "unknownCode: \n", attributes: [.foregroundColor: PlainSyntax]))
                         attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                    attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                                 
                               attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                  attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                            
                                                            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                                              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                         
                                                              attr.append(NSAttributedString(string: "unknownCode", attributes: [.foregroundColor: PlainSyntax]))

                                                                     attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                                            attr.append(NSAttributedString(string: " is not a known error code.\"\n", attributes: [.foregroundColor: StringSyntax]))

                    attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                    attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                 
                          
                               
                                 code?.textLabel?.attributedText = attr


                    
                    
                    
                            
                        
                    code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                    code?.textLabel?.numberOfLines = 0
                    code?.textLabel?.lineBreakMode = .byWordWrapping
                    code?.textLabel?.textAlignment = .left
                                          
                                            
                    return code!
        } else if indexPath.row == 8 {
             titleCell = SwitchTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SwitchTitleTableViewCell
            titleCell?.textLabel?.text = "If you don't need the default in the switch's statement, then use variables or constants if you want to prevent the values in the case's value. It's called case bundling."
                                
                                titleCell?.textLabel?.numberOfLines = 0
                                titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                titleCell?.textLabel?.textAlignment = .center
                                titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                
                                return titleCell!
        } else if indexPath.row == 7 {
            answer = SwitchTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SwitchAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       The request failed: There is a something wrong.
                       Please review the request to review and try again.
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 6 {
            
               code = SwitchTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SwitchCodeTableViewCell
              
              code?.textLabel?.font = setFont
            
              // MARK: Nsattributedstring
                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                        
                        attr.append(NSAttributedString(string: "statusCode", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                        attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                        attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "404 \n", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
               attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"The request failed with the error: \"\n", attributes: [.foregroundColor: StringSyntax]))
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "switch ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "statusCode ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: " case ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "400", attributes: [.foregroundColor: NumberSyntax]))
            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "403", attributes: [.foregroundColor: NumberSyntax]))
               attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "405", attributes: [.foregroundColor: NumberSyntax]))
               attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
               attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
               attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
              
            attr.append(NSAttributedString(string: "+=  ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
               attr.append(NSAttributedString(string: "\"There is something wrong.\" \n", attributes: [.foregroundColor: StringSyntax]))
            
            
                   attr.append(NSAttributedString(string: "6. \n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                   attr.append(NSAttributedString(string: "fallthrough \n", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "8. \n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "default", attributes: [.foregroundColor: KeyboardSyntax]))
             attr.append(NSAttributedString(string: ": \n", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                         
                       attr.append(NSAttributedString(string: "+=  ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                          attr.append(NSAttributedString(string: "\"Please review the request to review and try again.\" \n", attributes: [.foregroundColor: StringSyntax]))
                       
            attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                         
                  
                       
                         code?.textLabel?.attributedText = attr


            
            
            
                    
                    code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                    code?.textLabel?.numberOfLines = 0
                    code?.textLabel?.lineBreakMode = .byWordWrapping
                    code?.textLabel?.textAlignment = .left
                                          
                                            
                    return code!
            
        } else if indexPath.row == 5 {
            titleCell = SwitchTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SwitchTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "Do you have notice fallthrough keyboard in-between case and default? The fallthrough keyboard allows you to combine the case's value between default's values. Otherwise, If you try to remove the fallthrough keyboard, then it's will not combine that default value."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 4 {
            answer = SwitchTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SwitchAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Not Found
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 3 {
            code = SwitchTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SwitchCodeTableViewCell
                                                  
           code?.textLabel?.font = setFont
                 
                            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "statusCode ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))
                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "404\n ", attributes: [.foregroundColor: NumberSyntax]))
            
                attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                          attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                          attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                   attr.append(NSAttributedString(string: "switch ", attributes: [.foregroundColor: KeyboardSyntax]))
            
              attr.append(NSAttributedString(string: "statusCode ", attributes: [.foregroundColor: projectSyntax]))
            
              attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
                attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
                attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "401", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
            
 attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Bad request\" \n", attributes: [.foregroundColor: StringSyntax]))

            
             attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "5.\n", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "402", attributes: [.foregroundColor: NumberSyntax]))
                      
                attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "403", attributes: [.foregroundColor: NumberSyntax]))
                      attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                      
            
             attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                      attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "\"Forbidden\"\n", attributes: [.foregroundColor: StringSyntax]))
            
             attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                           
                           attr.append(NSAttributedString(string: "404", attributes: [.foregroundColor: NumberSyntax]))
                           
                     attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "405", attributes: [.foregroundColor: NumberSyntax]))
            attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "406", attributes: [.foregroundColor: NumberSyntax]))
                           attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                           
            
             attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "\"Not Found\"\n", attributes: [.foregroundColor: StringSyntax]))
            
             attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "default ", attributes: [.foregroundColor: KeyboardSyntax]))
                                  
                  
                                  attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                                  
             attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "\"None Of Above\"\n", attributes: [.foregroundColor: StringSyntax]))
             attr.append(NSAttributedString(string: "12. ", attributes: [.foregroundColor: counterSyntax]))
           
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                       code?.textLabel?.attributedText = attr
            
            
            
            
                          
                          code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                          code?.textLabel?.numberOfLines = 0
                          code?.textLabel?.lineBreakMode = .byWordWrapping
                          code?.textLabel?.textAlignment = .left
                                                
                                                  
                          return code!
        } else if indexPath.row == 2 {
            titleCell = SwitchTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SwitchTitleTableViewCell
            
            titleCell?.textLabel?.text = "The three methods which switch allows you to use in the case. The first method, You can use one value in the case. The second method, You can use thrice periods is for only the number which it's uses start between end numbers is limited, then it will execute case's value. The third method, You can use a comma to divide the numbers when consider has matched one of those numbers, then it will execute case's value. Otherwise, default if they don't match those cases."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 1 {
            
            code = SwitchTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SwitchCodeTableViewCell
          
           code?.textLabel?.font = setFont
            
           
            
            // MARK: Nsattributedstring
                                                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                                           
                                                       attr.append(NSAttributedString(string: "switch ", attributes: [.foregroundColor: KeyboardSyntax]))
                                            
                                            attr.append(NSAttributedString(string: " consider ", attributes: [.backgroundColor: dynamicBackground]))
                                            
                                            attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
                                   
                                    attr.append(NSAttributedString(string: "2.    ", attributes: [.foregroundColor: counterSyntax]))
                                            
            attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                      
                                             attr.append(NSAttributedString(string: " value1 ", attributes: [.backgroundColor: dynamicBackground]))
            
                                    attr.append(NSAttributedString(string: " :\n", attributes: [.foregroundColor: PlainSyntax]))
            
                                                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                   
                      
                    attr.append(NSAttributedString(string: " respond to value1 ", attributes: [.backgroundColor: dynamicBackground]))
                                        
                    attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
                    
                        attr.append(NSAttributedString(string: "4.    ", attributes: [.foregroundColor: counterSyntax]))
                                 
            attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                               
                                                                      attr.append(NSAttributedString(string: " value2 ", attributes: [.backgroundColor: dynamicBackground]))
                                     
                                                             attr.append(NSAttributedString(string: " :\n", attributes: [.foregroundColor: PlainSyntax]))
                                     
                                                                                attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                                            
                                               
                                             attr.append(NSAttributedString(string: " respond to value2 ", attributes: [.backgroundColor: dynamicBackground]))
                                                                 
            
                                                                                               attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
            

            attr.append(NSAttributedString(string: "6.    ", attributes: [.foregroundColor: counterSyntax]))
                                             
                   attr.append(NSAttributedString(string: "default ", attributes: [.foregroundColor: KeyboardSyntax]))
            
                                                                attr.append(NSAttributedString(string: ":\n", attributes: [.foregroundColor: PlainSyntax]))
                                                         
                                                                                                    attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                                                                
                                                                   
                                                                 attr.append(NSAttributedString(string: " respond to default ", attributes: [.backgroundColor: dynamicBackground]))
                                                                                     
                                
                                                                                                                   attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
            
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: " }", attributes: [.foregroundColor: PlainSyntax]))
                               
                    
                                                        code?.textLabel?.attributedText = attr
                               
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
            
        } else  {
            titleCell = SwitchTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SwitchTitleTableViewCell
            
            titleCell?.textLabel?.text = "The Switch is a powerful feature in the Swift. The Switch's consider seems familiar to the if's conditions. All of the cases will respond to that consider, but each case's values always respond to values which consider has matched that one of the case to execute the case's value otherwise execute default's values if consider does't matched."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        }
    }
    
    
}
