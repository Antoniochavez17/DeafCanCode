//
//  FunctionsViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class FunctionsViewController: UIViewController {

    @IBOutlet weak var FunctionTableView: UITableView!
    @IBOutlet weak var FunctionVideos: WKWebView!
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        FunctionTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Functions"
        
        Label(IDCode: "YC4qY9MTjiY")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        FunctionVideos.load(URLRequest(url: url!))

    }
}


extension FunctionsViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 26
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: FunctionsTitleTableViewCell!
        var code: FunctionsCodeTableViewCell!
        var answer: FunctionsAnswerTableViewCell!
        
        if indexPath.row == 25 {
            answer = FunctionTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? FunctionsAnswerTableViewCell
                                             answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                             answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                             answer?.textLabel?.text = """
                                             7.5
                                             """
                                             answer?.textLabel?.numberOfLines = 0
                                             answer?.textLabel?.lineBreakMode = .byWordWrapping
                                             answer?.textLabel?.textAlignment = .center
                                             answer?.textLabel?.textColor = UIColor.white
                                             return answer!
        } else if indexPath.row == 24 {
            code = FunctionTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? FunctionsCodeTableViewCell
                                                              
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                 attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "square", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                                 attr.append(NSAttributedString(string: "(width: ", attributes: [.foregroundColor: PlainSyntax]))

                         attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                                 
                        attr.append(NSAttributedString(string: ", height: ", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "-> ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                              
                       attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
    
                 

                      attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "width ", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: OtherDecluarationSyntax]))

            attr.append(NSAttributedString(string: "height\n", attributes: [.foregroundColor: projectSyntax]))

            
                     attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                      
                       code?.textLabel?.attributedText = attr
                        
                       attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                        attr.append(NSAttributedString(string: "divide", attributes: [.foregroundColor: TypeDeclarationSyntax]))
             attr.append(NSAttributedString(string: "() ", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "-> ", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "Double ", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "{\n ", attributes: [.foregroundColor: PlainSyntax]))
                    
               attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "return ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                      attr.append(NSAttributedString(string: "divide ", attributes: [.foregroundColor: projectSyntax]))
                                      attr.append(NSAttributedString(string: "()\n ", attributes: [.foregroundColor: PlainSyntax]))
          
               attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            
                  attr.append(NSAttributedString(string: "}\n ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "return ", attributes: [.foregroundColor: KeyboardSyntax]))
                                            attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: projectSyntax]))
                            attr.append(NSAttributedString(string: "\\ ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "2\n ", attributes: [.foregroundColor: NumberSyntax]))
            
               attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
               attr.append(NSAttributedString(string: "}\n ", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                       
                       attr.append(NSAttributedString(string: "square ", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(width: ", attributes: [.foregroundColor: PlainSyntax]))
                          attr.append(NSAttributedString(string: "3.0 ", attributes: [.foregroundColor: NumberSyntax]))
                            
                       attr.append(NSAttributedString(string: ", height: ", attributes: [.foregroundColor: PlainSyntax]))
                                attr.append(NSAttributedString(string: "5.0", attributes: [.foregroundColor: NumberSyntax]))
                                 
                       attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                 
                                  code?.textLabel?.attributedText = attr
                       
                                        
                                   
            
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 23 {
            titleCell = FunctionTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FunctionsTitleTableViewCell
                       
            titleCell?.textLabel?.text = "If you want to create a new second function's implementations in function's implementation. It's called scope. When you set return keyboard to divide() in the square(), which means that divide() will add end number in the square's implementations, based the end argument same to divide()."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 22 {
            answer = FunctionTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? FunctionsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            39
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 21 {
            code = FunctionTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? FunctionsCodeTableViewCell
                                                              
            code?.textLabel?.font = setFont
                                      
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "retangle", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                      attr.append(NSAttributedString(string: "(width: ", attributes: [.foregroundColor: PlainSyntax]))

              attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                      
             attr.append(NSAttributedString(string: ", height: ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "-> ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                   
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
             
            attr.append(NSAttributedString(string: "return ", attributes: [.foregroundColor: KeyboardSyntax]))
             attr.append(NSAttributedString(string: "width ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            attr.append(NSAttributedString(string: "height ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "* ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            attr.append(NSAttributedString(string: "2\n", attributes: [.foregroundColor: NumberSyntax]))
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "retangle ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "(width: ", attributes: [.foregroundColor: PlainSyntax]))
               attr.append(NSAttributedString(string: "9 ", attributes: [.foregroundColor: NumberSyntax]))
                 
            attr.append(NSAttributedString(string: ", height: ", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "15", attributes: [.foregroundColor: NumberSyntax]))
                      
            attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                      
                      
                       code?.textLabel?.attributedText = attr
            
            
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 20 {
            titleCell = FunctionTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FunctionsTitleTableViewCell
                       
            titleCell?.textLabel?.text = "You have noticed -> is means return, that means all arguments will return to the Int.  You have set the return keyboard in the implementation, which the end number will be return to the function's last arguments, then you don't have to calling. It's called returning values."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 19 {
            answer = FunctionTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? FunctionsAnswerTableViewCell
                                  answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                  answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                  answer?.textLabel?.text = """
                                  The request failed: Bad request
                                  """
                                  answer?.textLabel?.numberOfLines = 0
                                  answer?.textLabel?.lineBreakMode = .byWordWrapping
                                  answer?.textLabel?.textAlignment = .center
                                  answer?.textLabel?.textColor = UIColor.white
                                  return answer!
        } else if indexPath.row == 18{
            code = FunctionTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? FunctionsCodeTableViewCell
                                                              
          code?.textLabel?.font = setFont
                                        
                       
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "error ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"The request failed: \"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            
             attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "appendErrorCode", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            
            attr.append(NSAttributedString(string: "( ", attributes: [.foregroundColor: PlainSyntax]))
            
            
            attr.append(NSAttributedString(string: "_ ", attributes: [.foregroundColor: StringSyntax]))
            
              attr.append(NSAttributedString(string: "code: ", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))
            
              attr.append(NSAttributedString(string: ", toErrorString errorString: ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "inout ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: " if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "code ", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))
             
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                       
            attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
             attr.append(NSAttributedString(string: "\"Bad request\"\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                    
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                                    
            attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                                                               
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                                 
                      attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: projectSyntax]))
                      
                       attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                      
                       attr.append(NSAttributedString(string: "\"None of above\"\n", attributes: [.foregroundColor: projectSyntax]))
                      
                                  attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                                   
                                           attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                             
                     attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                                                             
                                                           
            attr.append(NSAttributedString(string: "9\n", attributes: [.foregroundColor: counterSyntax]))
                             
                    attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
                                      
                              attr.append(NSAttributedString(string: "appendErrorCode", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                      
                       
             attr.append(NSAttributedString(string: "400", attributes: [.foregroundColor: NumberSyntax]))
             attr.append(NSAttributedString(string: ", toErrorString: &", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "error", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
                                                
            attr.append(NSAttributedString(string: "error ", attributes: [.foregroundColor: projectSyntax]))
                                                
             code?.textLabel?.attributedText = attr

            
             
            
            
                                      
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 17 {
            titleCell = FunctionTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FunctionsTitleTableViewCell
                                  
                       titleCell?.textLabel?.text = "I show you two things about the functions. If you don't want to use the external parameter in the function, then using underscore to rid of the argument, but those functions can calling without external parameters. It's called subsequent parameter. The errorString had behind of inout keyboard in the arguments to allow you to combine implementation to variable's value, which was outside of the function. You have to add ampersand to calling the arguments which behind inout keyboard. It's called inout parameters."
                                    
                                    titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 16 {
            answer = FunctionTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? FunctionsAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       Leesha is friendly person!
                       Aliex is not freindly person!
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 15 {
            code = FunctionTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? FunctionsCodeTableViewCell
                                                              
          code?.textLabel?.font = setFont
                                        
                      
            
            // MARK: Nsattributedstring
                                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                       attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                                       
                                       attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: OtherDecluarationSyntax]))

            
                                       attr.append(NSAttributedString(string: "(to name:", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                       
                     attr.append(NSAttributedString(string: ", friendly = ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                      
            attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                    
                attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
                attr.append(NSAttributedString(string: " if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
              attr.append(NSAttributedString(string: "friendly ", attributes: [.foregroundColor: projectSyntax]))
              attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
              attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))
            
              attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
            
            attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                      
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                         
              attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))

                     attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "is friendly person!\"", attributes: [.foregroundColor: StringSyntax]))
                               
             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                               
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                               
            attr.append(NSAttributedString(string: "else  ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                               
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                       
            
            attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                      
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                         
              attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))

                     attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "is not friendly person!\"", attributes: [.foregroundColor: StringSyntax]))
                               
             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                               
            attr.append(NSAttributedString(string: "  }\n", attributes: [.foregroundColor: PlainSyntax]))
                               
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                               
            attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))
                               
            attr.append(NSAttributedString(string: "8. \n", attributes: [.foregroundColor: counterSyntax]))
                             
            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                               
            attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "\"Leesha\"", attributes: [.foregroundColor: StringSyntax]))
            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
                                       
            attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: projectSyntax]))
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       
                  
                        attr.append(NSAttributedString(string: "\"Aliex\"", attributes: [.foregroundColor: StringSyntax]))
                       attr.append(NSAttributedString(string: ", friendly:", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "false", attributes: [.foregroundColor: KeyboardSyntax]))
  attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))


            
      code?.textLabel?.attributedText = attr

            
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 14 {
            titleCell = FunctionTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FunctionsTitleTableViewCell
                       
            titleCell?.textLabel?.text = "The new arguments called friendly based on the booleans. If you don't agree with these booleans, it will effect the if's statement will be returned to the else's statements when friendly was false. It's called default parameters."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 13 {
            answer = FunctionTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? FunctionsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            I choose Aric will be our winner.
            I choose Drew will be our winner.
            I choose Chris will be our winner.
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 12 {
            code = FunctionTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? FunctionsCodeTableViewCell
                                                              
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                
                                                attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                     
                                                attr.append(NSAttributedString(string: "(to name:", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: "...)", attributes: [.foregroundColor: PlainSyntax]))
                                      
                                       attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                                      attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                 attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: PlainSyntax]))
            
                 attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
                    attr.append(NSAttributedString(string: "names", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                       
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                
                                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                      attr.append(NSAttributedString(string: "\"I will choose ", attributes: [.foregroundColor: StringSyntax]))
                                      
                                      attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                   
                                        attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))

                                               attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                                      attr.append(NSAttributedString(string: "will be our winner!\"", attributes: [.foregroundColor: StringSyntax]))
                                                         
                                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                      
                         
                                      
                                      attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                      
                                      attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))

                                      
                                      attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

             attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                                      
                                      attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: projectSyntax]))

                                      attr.append(NSAttributedString(string: "(to: ", attributes: [.foregroundColor: PlainSyntax]))
                                attr.append(NSAttributedString(string: "\"Aric\"", attributes: [.foregroundColor: StringSyntax]))
            
               attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                
            attr.append(NSAttributedString(string: "\"Drew\"", attributes: [.foregroundColor: StringSyntax]))
                      
                         attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                          
            attr.append(NSAttributedString(string: "\"Christ\"", attributes: [.foregroundColor: StringSyntax]))
                      
                
                                          
                                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                
                 code?.textLabel?.attributedText = attr
                                      
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 11 {
            titleCell = FunctionTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FunctionsTitleTableViewCell
                       
            titleCell?.textLabel?.text = "If you want those functions to become loops? The thrice periods allow to use for arguments to more text when you did make a calling. It's called the variadic parameter. The loop's range can calling the function's name to appear more text.  You could create those more text in the parameters by use comma. That's called variadic parameters."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 10 {
            answer = FunctionTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? FunctionsAnswerTableViewCell
                      answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                      answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                      answer?.textLabel?.text = """
                      Hello, Aliex
                      """
                      answer?.textLabel?.numberOfLines = 0
                      answer?.textLabel?.lineBreakMode = .byWordWrapping
                      answer?.textLabel?.textAlignment = .center
                      answer?.textLabel?.textColor = UIColor.white
                      return answer!
        } else if indexPath.row == 9 {
            code = FunctionTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? FunctionsCodeTableViewCell
                                                              
            code?.textLabel?.font = setFont
                                        
            // MARK: Nsattributedstring
                                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                       attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                                       
                                       attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: OtherDecluarationSyntax]))

            
                                       attr.append(NSAttributedString(string: "( to name:", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                             
                              attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                                                         attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                       
                              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                             attr.append(NSAttributedString(string: "\"Hello,", attributes: [.foregroundColor: StringSyntax]))
                             
                             attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          
                               attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))

                                      attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                             attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                
                              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                             
                
                             
                             attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                             
                             attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))

                             
                             attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                             
                             attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: projectSyntax]))

                             attr.append(NSAttributedString(string: "(name: ", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"Aliex\"", attributes: [.foregroundColor: StringSyntax]))
                       
                       attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                       
                                       code?.textLabel?.attributedText = attr
                                      
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 8 {
            titleCell = FunctionTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FunctionsTitleTableViewCell
                                  
                       titleCell?.textLabel?.text = "You can create double arguments in the function. The first arguments is calling the parameters, which it's called local parameter, and second arguments is calling the implementation, which it's called external parameter."
                                    
                                    titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 7 {
            answer = FunctionTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? FunctionsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Hello, Aliex
            Hello, Leesha
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 6 {
            code = FunctionTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? FunctionsCodeTableViewCell
                                                              
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                            attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                            
                            attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                            attr.append(NSAttributedString(string: "(name:", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                  
                   attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                  attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                                              attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                            
                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                  attr.append(NSAttributedString(string: "\"Hello,", attributes: [.foregroundColor: StringSyntax]))
                  
                  attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                               
                    attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))

                           attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                  attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                     
                   attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                  
     
                  
                  attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                  
                  attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))

                  
                  attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                  
                  attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: projectSyntax]))

                  attr.append(NSAttributedString(string: "(name: ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"Aliex\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
                  
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                           
                           attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: projectSyntax]))

                           attr.append(NSAttributedString(string: "(name: ", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "\"leesha\"", attributes: [.foregroundColor: StringSyntax]))
                     
                     attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                     
                               code?.textLabel?.attributedText = attr
                                      
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 5 {
            titleCell = FunctionTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FunctionsTitleTableViewCell
                       
            titleCell?.textLabel?.text = "You can use the parameter to calling the argument. You have to create a string interpolation that will allow those arguments include in the implementation. You can custom the string in the parameters when you are calling."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 4 {
            answer = FunctionTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? FunctionsAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       Hello, Aliex
                       Hello, Leesha
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 3 {
            code = FunctionTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? FunctionsCodeTableViewCell
                                                              
             code?.textLabel?.font = setFont
                                        
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                      attr.append(NSAttributedString(string: "() ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"Hello, Aliex\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"Hello, Leesha\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

            
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

            
            attr.append(NSAttributedString(string: "Greeting", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: "() ", attributes: [.foregroundColor: PlainSyntax]))
            
                         code?.textLabel?.attributedText = attr
            
                                     
                                      
            
            
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 2 {
            titleCell = FunctionTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FunctionsTitleTableViewCell
                                             
                                  titleCell?.textLabel?.text = "You could not need to use a parameter to calling due to the argument does't have existed. When it's calling the function's name, and it will be executing all implementation in one time."
                                               
                                               titleCell?.textLabel?.numberOfLines = 0
                                               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                               titleCell?.textLabel?.textAlignment = .center
                                               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                               
                                               return titleCell!
        } else if indexPath.row == 1 {
            code = FunctionTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? FunctionsCodeTableViewCell
                                                              
            code?.textLabel?.font = setFont
                                      
            // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                    
                                attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
                    
                     attr.append(NSAttributedString(string: " ( ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: " argument ", attributes: [.backgroundColor: dynamicBackground]))
            
              attr.append(NSAttributedString(string: " ) {\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "2.    ", attributes: [.foregroundColor: counterSyntax]))
                     
                      attr.append(NSAttributedString(string: " implementation ", attributes: [.backgroundColor: dynamicBackground]))
             attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
                                attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
                                attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                     
             attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
                    
                     attr.append(NSAttributedString(string: "( ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: " parameter ", attributes: [.backgroundColor: dynamicBackground]))
            
              attr.append(NSAttributedString(string: " ) ", attributes: [.foregroundColor: PlainSyntax]))
            
                                                    
                     code?.textLabel?.attributedText = attr
            
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else {
            titleCell = FunctionTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? FunctionsTitleTableViewCell
                                  
                       titleCell?.textLabel?.text = "The function's name is similar to a variable's name-value. The function's statement is called implementation. The parameter will calling the argument, which you did create something and put the argument's name in the value with the string interpolations in the implementation. The end function seems familiar to the printing."
                                    
                                    titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        }
    }
    
    
    
}
