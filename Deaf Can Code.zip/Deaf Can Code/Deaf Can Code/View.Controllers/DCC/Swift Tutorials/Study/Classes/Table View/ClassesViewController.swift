//
//  ClassesViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class ClassesViewController: UIViewController {

    @IBOutlet weak var ClassTableView: UITableView!
    @IBOutlet weak var ClassVideos: WKWebView!
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        ClassTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Classes"
        
        Label(IDCode: "DN5V6UNRyEg")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        ClassVideos.load(URLRequest(url: url!))

    }

}


extension ClassesViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 17
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: ClassTitleTableViewCell!
        var code: ClassCodeTableViewCell!
        var answer: ClassAnswerTableViewCell!
        
        if indexPath.row == 16 {
            answer = ClassTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClassAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Anakin Skywalker is still alive!
            I am Anakin Skywalker
            Anakin Skywalker is not weak, I destroy him!
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 15 {
            
            code = ClassTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClassCodeTableViewCell
                                                                                             
             code?.textLabel?.font = setFont
                                                       
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "class ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "Jedi ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                         
                                         attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                         attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Anakin Skywalker\"\n", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                              attr.append(NSAttributedString(string: "init", attributes: [.foregroundColor: KeyboardSyntax]))
attr.append(NSAttributedString(string: "() {\n", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                   
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                      
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                         
              attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))

                     attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: " is still alive!\"", attributes: [.foregroundColor: StringSyntax]))
                               
             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))

              attr.append(NSAttributedString(string: "func", attributes: [.foregroundColor: KeyboardSyntax]))
                    attr.append(NSAttributedString(string: "greeting", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            attr.append(NSAttributedString(string: "() {\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"I am ", attributes: [.foregroundColor: StringSyntax]))
                       
                       attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                         attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                    
                         attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))

                                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                          
                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                       
            
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
            
            
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))

                  attr.append(NSAttributedString(string: "deinit", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                            
                                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "\" ", attributes: [.foregroundColor: StringSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                    attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                               
                                    attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))

                                           attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: " is not weak, I destoryed him.\"", attributes: [.foregroundColor: StringSyntax]))
                                                     
                                   attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                  
            attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
 attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "12. ", attributes: [.foregroundColor: counterSyntax]))
attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                       code?.textLabel?.attributedText = attr


            
                                                                     code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                                     code?.textLabel?.numberOfLines = 0
                                                                     code?.textLabel?.lineBreakMode = .byWordWrapping
                                                                     code?.textLabel?.textAlignment = .left
                                                                                           
                                                                                             
                                                                     return code!
            
        } else if indexPath.row == 14 {
            titleCell = ClassTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClassTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "It was a final tutorial. This class does not need mutability because These classes are variables that mean it was allowed otherwise if you wan change in the structure by using a mutability keyboard. The deinit as known deinitializers does look like Switch's default which allows you to define the statements."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 13 {
            answer = ClassTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClassAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       Fred
                       Jr
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 12 {
            
            code = ClassTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClassCodeTableViewCell
                                                                                             
            code?.textLabel?.font = setFont
                                                      
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "class ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "Worker ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: " var ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "\"Alan\"\n", attributes: [.foregroundColor: StringSyntax]))

                        attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "4. \n", attributes: [.foregroundColor: counterSyntax]))
            
            
              attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      attr.append(NSAttributedString(string: "WorkerName ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      
                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Worker", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "() \n", attributes: [.foregroundColor: PlainSyntax]))
                               
                                       
            
              attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
        
            attr.append(NSAttributedString(string: "WorkerName", attributes: [.foregroundColor: projectSyntax]))
            
                      attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: projectSyntax]))
            
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: "\"Fred\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            
              attr.append(NSAttributedString(string: "7. \n", attributes: [.foregroundColor: counterSyntax]))
            
            
              attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
            
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      attr.append(NSAttributedString(string: "newWorkerName ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      
                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Worker", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "()\n", attributes: [.foregroundColor: PlainSyntax]))

                                 attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                               
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "newWorkerName ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
   
                                       attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                             
                             attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: projectSyntax]))
                             
                             
                             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: projectSyntax]))
                             
                              attr.append(NSAttributedString(string: "\"Fred\"\n", attributes: [.foregroundColor: StringSyntax]))
            
                       code?.textLabel?.attributedText = attr


            
            
                                                                     code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                                     code?.textLabel?.numberOfLines = 0
                                                                     code?.textLabel?.lineBreakMode = .byWordWrapping
                                                                     code?.textLabel?.textAlignment = .left
                                                                                           
                                                                                             
                                                                     return code!
            
        } else if indexPath.row == 11 {
            titleCell = ClassTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClassTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "If you want to create many worker names than just one, then you can create a variable for calling and assignment operator to allow you to change the name."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 10 {
            answer = ClassTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClassAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            MEOW!
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 9 {
            
            code = ClassTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClassCodeTableViewCell
                                                                                             
             code?.textLabel?.font = setFont
            
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "class ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "Cat ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                      attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
            attr.append(NSAttributedString(string: " Noise", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            attr.append(NSAttributedString(string: "()  {\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
           attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                       
              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "\"MMMMEEEEOOOOWWW!\"", attributes: [.foregroundColor: StringSyntax]))
             
            
                  attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                    

            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
              attr.append(NSAttributedString(string: " } \n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                       
                         attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))
                       

                       attr.append(NSAttributedString(string: "6.\n", attributes: [.foregroundColor: counterSyntax]))
                                  
            
             attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                      attr.append(NSAttributedString(string: "class ", attributes: [.foregroundColor: KeyboardSyntax]))
                      attr.append(NSAttributedString(string: "realNoise", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
          
        attr.append(NSAttributedString(string: "Cat ", attributes: [.foregroundColor: projectSyntax]))
                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                      attr.append(NSAttributedString(string: "override func ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "Noise", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      attr.append(NSAttributedString(string: "() {\n", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                     attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"MEOW!\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
                      attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
                      attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
              attr.append(NSAttributedString(string: "12. ", attributes: [.foregroundColor: counterSyntax]))
              attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
              attr.append(NSAttributedString(string: "voiceCat ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
              attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "realNoise", attributes: [.foregroundColor: projectSyntax]))
              attr.append(NSAttributedString(string: "() \n", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "13. ", attributes: [.foregroundColor: counterSyntax]))
              attr.append(NSAttributedString(string: "voiceCat", attributes: [.foregroundColor: projectSyntax]))
              attr.append(NSAttributedString(string: "Noise ", attributes: [.foregroundColor: projectSyntax]))
              attr.append(NSAttributedString(string: "()", attributes: [.foregroundColor: PlainSyntax]))
          
            
            code?.textLabel?.attributedText = attr
                                                                     code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                                     code?.textLabel?.numberOfLines = 0
                                                                     code?.textLabel?.lineBreakMode = .byWordWrapping
                                                                     code?.textLabel?.textAlignment = .left
                                                                                           
                                                                                             
                                                                     return code!
            
        } else if indexPath.row == 8 {
            
            titleCell = ClassTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClassTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "That you did learn about the previous code concept has two things. Now, you could notice the override keyboard will be given these second functions from accident mixing with the first functions which the child class could put into the parent classes. You will see a new variable is called Cat_Voice does use the second class to replace that first function become a second function."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
            
        } else if indexPath.row == 7 {
            answer = ClassTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClassAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Owner -> favoriteAnimal: "Dog", name: "Tank"
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 6 {
            
            code = ClassTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClassCodeTableViewCell
                                                                                  
                  code?.textLabel?.font = setFont
                                            
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "class ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                       attr.append(NSAttributedString(string: "Animal ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))
                       
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
           attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
              
              attr.append(NSAttributedString(string: "favoriteAnimal", attributes: [.foregroundColor: TypeDeclarationSyntax]))

              attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

              attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                         
                         attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                         attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                         attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
                       
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                 
                      attr.append(NSAttributedString(string: "init", attributes: [.foregroundColor: PlainSyntax]))
                         
                         attr.append(NSAttributedString(string: "(favoriteAnimal: ", attributes: [.foregroundColor: PlainSyntax]))

                         attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                       
            attr.append(NSAttributedString(string: ", name: ", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                      
            attr.append(NSAttributedString(string: "self ", attributes: [.foregroundColor: KeyboardSyntax]))


          attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: projectSyntax]))

                         attr.append(NSAttributedString(string: "= name\n", attributes: [.foregroundColor: PlainSyntax]))

                         
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                      
             attr.append(NSAttributedString(string: "self", attributes: [.foregroundColor: KeyboardSyntax]))
             attr.append(NSAttributedString(string: ". ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: projectSyntax]))

              attr.append(NSAttributedString(string: "= name", attributes: [.foregroundColor: PlainSyntax]))

            code?.textLabel?.attributedText = attr
                      
       
                                                          code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                          code?.textLabel?.numberOfLines = 0
                                                          code?.textLabel?.lineBreakMode = .byWordWrapping
                                                          code?.textLabel?.textAlignment = .left
                                                                                
                                                                                  
                                                          return code!
            
        } else if indexPath.row == 5 {
            titleCell = ClassTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClassTitleTableViewCell
                                             
                       titleCell?.textLabel?.text = "The class allows you to include in this second class. The super initialization does look like child classes, but initializations is a parent class, which it's gives that super initialization as child classes basically from Animal."
                                               
                       titleCell?.textLabel?.numberOfLines = 0
                                               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                               titleCell?.textLabel?.textAlignment = .center
                                               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                               
                                               return titleCell!
        } else if indexPath.row == 4 {
            answer = ClassTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClassAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            favoriteAnimal: "Dog", name: "Tank"
            favoriteAnimal: "Cat", name: "Rio"
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 3 {
            
           code = ClassTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClassCodeTableViewCell
                                                                       
           code?.textLabel?.font = setFont
                                 
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "class ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "Animal ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
               attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
               attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
               attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
               attr.append(NSAttributedString(string: "favoriteAnimal ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
               attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
               attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                      
                         attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                         attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                         attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                         attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                      
                         attr.append(NSAttributedString(string: "init ", attributes: [.foregroundColor: KeyboardSyntax]))
                         attr.append(NSAttributedString(string: "favoriteAnimal( ", attributes: [.foregroundColor: PlainSyntax]))
            
                         attr.append(NSAttributedString(string: "favoriteAnimal ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                       attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                       attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: PlainSyntax]))
                          attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                          attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
            
    
            attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
            attr.append(NSAttributedString(string: "5.", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "self", attributes: [.foregroundColor: KeyboardSyntax]))
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "favoriteAnimal ", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "favoriteAnimal\n", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "6.", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "self", attributes: [.foregroundColor: KeyboardSyntax]))
             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: projectSyntax]))
                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "name\n", attributes: [.foregroundColor: PlainSyntax]))
          
             attr.append(NSAttributedString(string: "7.", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))
                   
             attr.append(NSAttributedString(string: "8.", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                   
            
             attr.append(NSAttributedString(string: "9.\n", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                         attr.append(NSAttributedString(string: "favorite", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
              attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "Animal", attributes: [.foregroundColor: projectSyntax]))
                         attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "favoriteAnimal", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Dog\"", attributes: [.foregroundColor: StringSyntax]))
                    attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))
                        attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                       
              attr.append(NSAttributedString(string: "\"Tank\"", attributes: [.foregroundColor: StringSyntax]))
            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "11.", attributes: [.foregroundColor: counterSyntax]))
               attr.append(NSAttributedString(string: "\\\\ or this\n", attributes: [.foregroundColor: CommentSyntax]))
               attr.append(NSAttributedString(string: "12.", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "Animal", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "favoriteAnimal", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "\"Cat\"", attributes: [.foregroundColor: StringSyntax]))
                              attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                 
                        attr.append(NSAttributedString(string: "\"Rio\"", attributes: [.foregroundColor: StringSyntax]))
                      attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
            
             code?.textLabel?.attributedText = attr
            
                                               code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                               code?.textLabel?.numberOfLines = 0
                                               code?.textLabel?.lineBreakMode = .byWordWrapping
                                               code?.textLabel?.textAlignment = .left
                                                                     
                                                                       
                                               return code!
            
        } else if indexPath.row == 2 {
            
            titleCell = ClassTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClassTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "When the type annotations have created in the properties, then put the type annotation without a keyboard in the initialization. You have learned about the last concept from the structures, in which the statements refer to properties. You have two methods of calling the class. You can calling the class in the variable's value or without the variable need in which it's familiar to functions does."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
            
        } else if indexPath.row == 1 {
            
            code = ClassTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClassCodeTableViewCell
                                                                       
            code?.textLabel?.font = setFont
                               
            // MARK: Nsattributedstring
                                                          let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                                              
                                                          attr.append(NSAttributedString(string: "class ", attributes: [.foregroundColor: KeyboardSyntax]))
                                               
                                               attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
                                              
                                               attr.append(NSAttributedString(string: " { \n", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                
                                       attr.append(NSAttributedString(string: "2.    ", attributes: [.foregroundColor: counterSyntax]))
                                               
                                                attr.append(NSAttributedString(string: " properties ", attributes: [.backgroundColor: dynamicBackground]))
                                       
                               attr.append(NSAttributedString(string: "d\n", attributes: [.foregroundColor: CodeBackground]))
                       
                                                          attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                      
                       attr.append(NSAttributedString(string: "init ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                       
                                      attr.append(NSAttributedString(string: "( ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       
                                                  attr.append(NSAttributedString(string: " parameter ", attributes: [.backgroundColor: dynamicBackground]))
                       
                       attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))
                              
                       
                                                          attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                                     
                          attr.append(NSAttributedString(string: " statements ", attributes: [.backgroundColor: dynamicBackground]))
                                                                        
                                attr.append(NSAttributedString(string: "d\n", attributes: [.foregroundColor: CodeBackground]))
                       
                                   attr.append(NSAttributedString(string: "5.    ", attributes: [.foregroundColor: counterSyntax]))
                       
                        attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                                   attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                       
                           attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                       
                                               code?.textLabel?.attributedText = attr
                                    
            
                                               code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                               code?.textLabel?.numberOfLines = 0
                                               code?.textLabel?.lineBreakMode = .byWordWrapping
                                               code?.textLabel?.textAlignment = .left
                                                                     
                                                                       
                                               return code!
            
        } else {
            
            titleCell = ClassTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClassTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "The classes are very same as structures does. However, classes always allow doing something like variables does."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
            
        }
        
    }
    
    
    
}
