//
//  ElseIfViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/6/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class ElseIfViewController: UIViewController {

    @IBOutlet weak var ElseIfTableView: UITableView!
    @IBOutlet weak var ElseIfVideos: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        ElseIfTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Else If"
        
        Label(IDCode: "EmnBn8tPrxo")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        ElseIfVideos.load(URLRequest(url: url!))

    }

}

extension ElseIfViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 8
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let titleCell: ElseifTitleTableViewCell!
        let code: ElseIfCodeTableViewCell!
        let answer: ElseIfAnswerTableViewCell!
        
        if indexPath.row == 7 {
            answer = ElseIfTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ElseIfAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            459.23 is moderate risk level
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 6 {
                   code = ElseIfTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ElseIfCodeTableViewCell
                                               
                   code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                           let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                           attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "radioactive_Level ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                
                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: "300.27\n", attributes: [.foregroundColor: NumberSyntax]))
                                
                                attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                                
                                attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                 attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                 attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                
                                attr.append(NSAttributedString(string: "100 ", attributes: [.foregroundColor: NumberSyntax]))
                                
                                attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                  attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                      
                                            attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "is tolerable risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                                           
                                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                 attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                                
                        
                                attr.append(NSAttributedString(string: " else if ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                 attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                 attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                
                                attr.append(NSAttributedString(string: "500 ", attributes: [.foregroundColor: NumberSyntax]))
                                
                                attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                          
                                          attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                     
                                           attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                                          
                                          attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                           attr.append(NSAttributedString(string: "is moderate risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                                          
                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                
                                
                   
                                 attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                             
                          attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                       
                                attr.append(NSAttributedString(string: " else ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                                attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                                 attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                          
                                          attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                     
                                           attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                                          
                                          attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                           attr.append(NSAttributedString(string: "is high risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                                          
                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "10.", attributes: [.foregroundColor: counterSyntax]))
                                
                                 attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                                
                               code?.textLabel?.attributedText = attr
                                
                                                                                                            
                                                                                                            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                                                                            code?.textLabel?.numberOfLines = 0
                                                                                                            code?.textLabel?.lineBreakMode = .byWordWrapping
                                                                                                            code?.textLabel?.textAlignment = .left
                                                                                                                                  
                                                                                                                                    
                                                                                                            return code!
        } else if indexPath.row == 5 {
            titleCell = ElseIfTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ElseifTitleTableViewCell
                                  
                                  titleCell?.textLabel?.text = "It was a final tutorial about if, else, and else if. You could see the else if's condition had the limited number is 100 to 500 to executing else if's statements when they are calling by radiation_Level."
                                    
                                    titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 4 {
             answer = ElseIfTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ElseIfAnswerTableViewCell
                      answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                      answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                      answer?.textLabel?.text = """
                      Tommorrow is cloudy day!

                      """
                      answer?.textLabel?.numberOfLines = 0
                      answer?.textLabel?.lineBreakMode = .byWordWrapping
                      answer?.textLabel?.textAlignment = .center
                      answer?.textLabel?.textColor = UIColor.white
                      return answer!
        } else if indexPath.row == 3 {
            code = ElseIfTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ElseIfCodeTableViewCell
                                                  
                       code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1.  ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "weatherToday ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Sunny\"\n", attributes: [.foregroundColor: StringSyntax]))
        
             attr.append(NSAttributedString(string: "2.  ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                        attr.append(NSAttributedString(string: "weatherTommorrow ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "\"Cloudy\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "3.  ", attributes: [.foregroundColor: counterSyntax]))
                       
                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                  
                                   attr.append(NSAttributedString(string: "checkWeather ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "weatherTommorrow\n", attributes: [.foregroundColor: StringSyntax]))
                       
            attr.append(NSAttributedString(string: "4.  \n", attributes: [.foregroundColor: counterSyntax]))
                                  
            attr.append(NSAttributedString(string: "5.  ", attributes: [.foregroundColor: counterSyntax]))

                                  attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                                             
                                              attr.append(NSAttributedString(string: "weatherToday ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                             
                                             attr.append(NSAttributedString(string: "!= ", attributes: [.foregroundColor: PlainSyntax]))
                                             
                                             attr.append(NSAttributedString(string: "\"Sunny\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "6.  ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "\"Today is sunny day!\"", attributes: [.foregroundColor: StringSyntax]))
             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
            attr.append(NSAttributedString(string: "7.  ", attributes: [.foregroundColor: counterSyntax]))
            
              attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
            
      attr.append(NSAttributedString(string: " else if ", attributes: [.foregroundColor: KeyboardSyntax]))
                                             
                                              attr.append(NSAttributedString(string: "checkWeather ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                             
                                             attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: PlainSyntax]))
                                             
                                             attr.append(NSAttributedString(string: "\"Cloudly\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "8.  ", attributes: [.foregroundColor: counterSyntax]))

                      attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "\"Tommorrow is cloudy day!\"", attributes: [.foregroundColor: StringSyntax]))
                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: StringSyntax]))
                      
                      
                      attr.append(NSAttributedString(string: "9.  ", attributes: [.foregroundColor: counterSyntax]))

             attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
            
              attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                             
                              attr.append(NSAttributedString(string: "\"There's no sunny day!\"", attributes: [.foregroundColor: StringSyntax]))
                              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: StringSyntax]))
                             
                             
                             attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))

                    attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
            

             code?.textLabel?.attributedText = attr
                          
                          code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                          code?.textLabel?.numberOfLines = 0
                          code?.textLabel?.lineBreakMode = .byWordWrapping
                          code?.textLabel?.textAlignment = .left
                                                
                                                  
                          return code!
        } else if indexPath.row == 2 {
            titleCell = ElseIfTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ElseifTitleTableViewCell
            
            titleCell?.textLabel?.text = "You can see two variables were called check and other_Check. You could add the else keyboard after else if's statements to executing if this other_Check are false."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 1 {
            code = ElseIfTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ElseIfCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                               let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                                   
                                               attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                                    
                                    attr.append(NSAttributedString(string: " condition ", attributes: [.backgroundColor: dynamicBackground]))
                                    
                                    attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
                           
                            attr.append(NSAttributedString(string: "2.    ", attributes: [.foregroundColor: counterSyntax]))
                                    
                                     attr.append(NSAttributedString(string: " first statements ", attributes: [.backgroundColor: dynamicBackground]))
                            attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
                                               attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                           
                           attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                               attr.append(NSAttributedString(string: "else if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: " second condition ", attributes: [.backgroundColor: dynamicBackground]))
                                
                                                              attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
            
                                                             attr.append(NSAttributedString(string: "4.    ", attributes: [.foregroundColor: counterSyntax]))
                       
                          attr.append(NSAttributedString(string: " second statements ", attributes: [.backgroundColor: dynamicBackground]))
                attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
               attr.append(NSAttributedString(string: "5.    ", attributes: [.foregroundColor: counterSyntax]))
                       attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
            
              attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))
            
               attr.append(NSAttributedString(string: "6.    ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: " third condition ", attributes: [.backgroundColor: dynamicBackground]))
                                           
                                                                         attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
                       
            
                                                          attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                      
                                      attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       
                                    code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else {
            
            titleCell = ElseIfTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ElseifTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "The Swift allows you to create a second condition by this if to replace an else if keyboard to execute the second statements."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        }
        
    }
    
    
    
    
}
