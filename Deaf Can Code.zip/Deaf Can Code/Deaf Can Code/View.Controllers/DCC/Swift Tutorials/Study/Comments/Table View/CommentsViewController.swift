//
//  CommentsViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/31/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class CommentsViewController: UIViewController {

    @IBOutlet weak var CommentVideos: WKWebView!
    
    @IBOutlet weak var CommentsTableView: UITableView!
    
    
      override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        CommentsTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Comments"
        
        Label(IDCode: "EXJSoqdHvpo")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        CommentVideos.load(URLRequest(url: url!))

    }


}


extension CommentsViewController: UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 11
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: CommentTitleTableViewCell!
        var code: CommentCodeTableViewCell!
        var answer: CommentAnswerTableViewCell!
        
        if indexPath.row == 10 {
            code = CommentsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? CommentCodeTableViewCell
                                  
        code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                  
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                
            attr.append(NSAttributedString(string: "/*\n", attributes: [.foregroundColor: CommentSyntax]))
            attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "This is\n", attributes: [.foregroundColor: CommentSyntax]))
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "called a\n", attributes: [.foregroundColor: CommentSyntax]))
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "multi-line comment\n", attributes: [.foregroundColor: CommentSyntax]))
            attr.append(NSAttributedString(string: "6.\n", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "*/", attributes: [.foregroundColor: CommentSyntax]))
                                                  
                                                  code?.textLabel?.attributedText = attr
                                                 
                                                  code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                  code?.textLabel?.numberOfLines = 0
                                                  code?.textLabel?.lineBreakMode = .byWordWrapping
                                                  code?.textLabel?.textAlignment = .left

            
                                  return code!
        } else if indexPath.row == 9 {
            
            titleCell = CommentsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? CommentTitleTableViewCell
                       
            titleCell?.textLabel?.text = "When you create the slash with the asterisk is allows you to create many line sentences is called multi-line comments."
                         
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
            return titleCell!
            
        } else if indexPath.row == 8 {
            
            code = CommentsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? CommentCodeTableViewCell
                           
             code?.textLabel?.font = setFont
                               
    
            
            // MARK: Nsattributedstring
            
           let nameString = "Title"
                let string = "// MARK: \(nameString)"

                let attributes = [NSAttributedString.Key.font: setFont, NSAttributedString.Key.foregroundColor: CommentSyntax]
                let boldAttribute = [NSAttributedString.Key.font: BoldFont, NSAttributedString.Key.foregroundColor: MarksSyntax]

                let attributedString = NSMutableAttributedString(string: string, attributes: attributes)

                let nsString = NSString(string: string)
                let range = nsString.range(of: nameString)

                if range.length > 0 { attributedString.setAttributes(boldAttribute, range: range) }

            
                
                  code?.textLabel?.attributedText = attributedString
            
                                            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                            code?.textLabel?.numberOfLines = 0
                                            code?.textLabel?.lineBreakMode = .byWordWrapping
                                            code?.textLabel?.textAlignment = .left
                                  
                                  return code!
            
        } else if indexPath.row == 7 {
            titleCell = CommentsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? CommentTitleTableViewCell
                       
                         titleCell?.textLabel?.text = "The comment with the MARK: is a mark these comments. It'll appear the bold title on editor minimap to make the top course of the coding."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 6 {
            answer = CommentsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? CommentAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Hello, World!
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 5 {
            code = CommentsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? CommentCodeTableViewCell
                       
  code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                          
            attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                  
            attr.append(NSAttributedString(string: " str = ", attributes: [.foregroundColor: UIColor.white]))
            
            attr.append(NSAttributedString(string: "\"Hello World!\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                            
            attr.append(NSAttributedString(string: "// Hello, World!", attributes: [.foregroundColor: CommentSyntax]))
                                            
            code?.textLabel?.attributedText = attr
                                            
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
                                                                  
            return code!
            
        } else if indexPath.row == 4 {
            titleCell = CommentsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? CommentTitleTableViewCell
            
              titleCell?.textLabel?.text = "That comment could help a lot of the beginner. For example, If you are confused with a lot of the coding. The comment will be helpful. When you write a code concept, then you could write a comment could use under code concept where did you writing code that executes in the console."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 3 {
            code = CommentsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? CommentCodeTableViewCell
        
            
               code?.textLabel?.font = setFont
            
            code?.textLabel?.text = """
                      1. // This is a comment
                      """
            
            // MARK: Nsattributedstring
                    
                     let attributedCoding = NSMutableAttributedString(string: (code?.textLabel!.text)!)
                     
                     let oneCodeconecpt = ((code?.textLabel!.text)! as NSString).range(of: "1.")
                     attributedCoding.addAttribute(NSAttributedString.Key.foregroundColor, value: counterSyntax , range: oneCodeconecpt)
                     
                     
                     let oneCodeconecptOne = ((code?.textLabel!.text)! as NSString).range(of: "// This is a comment")
                     attributedCoding.addAttribute(NSAttributedString.Key.foregroundColor, value: CommentSyntax, range: oneCodeconecptOne)
                     
                     code?.textLabel?.attributedText = attributedCoding
                    
            
                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                      code?.textLabel?.numberOfLines = 0
                      code?.textLabel?.lineBreakMode = .byWordWrapping
                      code?.textLabel?.textAlignment = .left
            
        
            return code!
        } else if indexPath.row == 2 {
            titleCell = CommentsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? CommentTitleTableViewCell
            
              titleCell?.textLabel?.text = "Those comments will not display in the console or playground editor panel. This comment is like a reminder, to do list, or  important."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 1 {
            
            code = CommentsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? CommentCodeTableViewCell
            
            
               code?.textLabel?.font = setFont
            
        
                // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                  
                      attr.append(NSAttributedString(string: "// This is comment", attributes: [.foregroundColor: CommentSyntax]))
                      code?.textLabel?.attributedText = attr
            
                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                      code?.textLabel?.numberOfLines = 0
                      code?.textLabel?.lineBreakMode = .byWordWrapping
                      code?.textLabel?.textAlignment = .left
          
           
            
            return code!
            
        } else {
            titleCell = CommentsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? CommentTitleTableViewCell
                       
                         titleCell?.textLabel?.text = "When you text double forward slash turn the light green was called comment. This called comment in the Swift Language."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
            
        }
    }
    
    
    
    
}


