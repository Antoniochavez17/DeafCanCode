//
//  BitIntExampledViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class BitIntExampledViewController: UIViewController {

    @IBOutlet weak var ExampledTableView: UITableView!
    @IBOutlet weak var ExampledVideo: WKWebView!
    
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        ExampledTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Exampled"
        
        Label(IDCode: "PL0jJZQWCWo")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        ExampledVideo.load(URLRequest(url: url!))

    }

}

extension BitIntExampledViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 11
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: ExampleTitleTableViewCell!
        var code: ExampleCodeTableViewCell!
        var answer: ExampleAnswerTableViewCell!
        
        
        if indexPath.row == 10 {
            titleCell = ExampledTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ExampleTitleTableViewCell
                                          
                                          titleCell?.textLabel?.text = "2 x 2 x 2 x 2 x 2 x 2 x 2 x 2 = 128 - 1 = 127"
                                            
            
            let font = UIFont.systemFont(ofSize: 10)
                     
                               let attr = NSMutableAttributedString(string: "Int8 = 2", attributes: [.foregroundColor: counterSyntax])

                             attr.append(NSMutableAttributedString(string: "8", attributes: [.foregroundColor: titleText]))
                                 
                               attr.setAttributes([.font: font,.baselineOffset:10], range: NSRange(location:8,length:1))

                               attr.append(NSMutableAttributedString(string: " = 2 x 2 x 2 x 2 x 2 x 2 x 2 x 2 = 128 - 1 = 127", attributes: [.foregroundColor: counterSyntax]))
                     
             
                     
                 
                                titleCell?.textLabel?.attributedText = attr
                     
            
                                            titleCell?.textLabel?.numberOfLines = 0
                                            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                            titleCell?.textLabel?.textAlignment = .center
                                            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                            
                                            return titleCell!
        } else if indexPath.row == 9 {
            titleCell = ExampledTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ExampleTitleTableViewCell
                                
        titleCell?.textLabel?.text = "Why does this 2 have a small 8? That is called exponents. For example, 2^3 means 2 x 2 x 2 = 8 This does not mean 2 x 3 = 6. Now, In Int8 means 2^8 to take the final answer is 128, but in the code programming is based start with 0, not 1.  That is how bit integer work! Now, This means Int32 means 2^32 to final answers like that."
                                  
                        
             let font = UIFont.systemFont(ofSize: 10)
            
                      let attr = NSMutableAttributedString(string: "Why does this 2 have a small 8? That is called exponents. For example, 2", attributes: [.foregroundColor: counterSyntax])

                    attr.append(NSMutableAttributedString(string: "3", attributes: [.foregroundColor: titleText]))
                        
                      attr.setAttributes([.font: font,.baselineOffset:10], range: NSRange(location:72,length:1))

                      attr.append(NSMutableAttributedString(string: "means 2 x 2 x 2 = 8 This does not mean 2 x 3 = 6. Now, In Int8 means 2^8 to take the final answer is 128, but in the code programming is based start with 0, not 1.  That is how bit integer work! Now, This means Int32 means 2^32 to final answers like that.", attributes: [.foregroundColor: counterSyntax]))
            
    
            
        
                       titleCell?.textLabel?.attributedText = attr
            
            
                                  titleCell?.textLabel?.numberOfLines = 0
                                  titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                  titleCell?.textLabel?.textAlignment = .center
                                  titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                  
                                  return titleCell!
        } else if indexPath.row == 8 {
            
            
            titleCell = ExampledTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ExampleTitleTableViewCell
            
       
           
       
        
                           
            titleCell?.textLabel?.text = "Int8 = 28 = 128"
                     
            let attr = NSMutableAttributedString(string: "Int8 = 2", attributes: [.foregroundColor: counterSyntax])

            let font = UIFont.systemFont(ofSize: 10)
           
            
                        
            attr.append(NSMutableAttributedString(string: "8", attributes: [.foregroundColor: counterSyntax]))
              
            attr.setAttributes([.font: font,.baselineOffset:10], range: NSRange(location:8,length:1))

            attr.append(NSMutableAttributedString(string: " = 128", attributes: [.foregroundColor: counterSyntax]))
             titleCell?.textLabel?.attributedText = attr
            
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
 

              
              return titleCell!
        } else if indexPath.row == 7 {
            titleCell = ExampledTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ExampleTitleTableViewCell
                     
                     titleCell?.textLabel?.text = "Why does Apple create a bit integers?  Alright, Let me example you about this bit integers works. Let's talk about 8-Bit Integers, and I will example you about these numbers with the exponents."
                       
                       titleCell?.textLabel?.numberOfLines = 0
                       titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                       titleCell?.textLabel?.textAlignment = .center
                       titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                       
                       return titleCell!
        } else if indexPath.row == 6 {
            answer = ExampledTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ExampleAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  errorSignColor
                       answer?.textLabel?.text = """
                         Execution was interrupted, reason: EXC_BAD_INSTRUCTION (code=EXC_I386_INVOP, subcode=0x0). The process has been left at the point where it was interrupted, use "thread return -x" to return to the state before expression evaluation.
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 5 {
            code = ExampledTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ExampleCodeTableViewCell
                                        
           code?.textLabel?.font = setFont
            
            
                // MARK: Nsattributedstring
                          let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                          attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                          
                          attr.append(NSAttributedString(string: "number", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                          attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "129 \n", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "Int8", attributes: [.foregroundColor: projectSyntax]))

               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "number", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                          
                           code?.textLabel?.attributedText = attr

            
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 4 {
            titleCell = ExampledTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ExampleTitleTableViewCell
            
            titleCell?.textLabel?.text = "You have noticed the signed integers doesn't have maximum and minimum?  The signed integers is based use both maximum and minimum means opposite of positive and negative, but You can't pass the 8-bit signed integer's limited numbers like the previous."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 3 {
            answer = ExampledTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ExampleAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            The maximum value for Int8 is 127
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 2 {
            code = ExampledTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ExampleCodeTableViewCell
                                                    
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                           let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                           attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                       
                                       attr.append(NSAttributedString(string: "\"The minimun value for UInt8 is", attributes: [.foregroundColor: StringSyntax]))
                                       
                                        attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                                        attr.append(NSAttributedString(string: "UInt8", attributes: [.foregroundColor: projectSyntax]))
                                        attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                        attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                                        attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                        attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                       attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                       
                                       
                                            code?.textLabel?.attributedText = attr
                            
                            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                            code?.textLabel?.numberOfLines = 0
                            code?.textLabel?.lineBreakMode = .byWordWrapping
                            code?.textLabel?.textAlignment = .left
                                                  
                                                    
                            return code!
        } else if indexPath.row == 1  {
            titleCell = ExampledTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ExampleTitleTableViewCell
                                               
                                               titleCell?.textLabel?.text = "The 8-bits signed integer has 127 means you can using 0 between 127, otherwise, If you over that limited numbers will get errors:  error: Execution was interrupted, reason: EXC_BAD_INSTRUCTION(code=EXC_I386_INVOP, subcode=0x0). The process has been left at the point where it was interrupted, use \"thread return -x\" to return to the state before expression evaluation. That means you just passed the 8-bits signed integer's limited numbers."
                                                 
                                                 titleCell?.textLabel?.numberOfLines = 0
                                                 titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                                 titleCell?.textLabel?.textAlignment = .center
                                                 titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                                 
                                                 return titleCell!
        } else {
            titleCell = ExampledTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ExampleTitleTableViewCell
                                    
                                    titleCell?.textLabel?.text = "Why bit integers have two different limited numbers in Int between UIInt? This Int stands for a signed integer, otherwise, UInt is an unsigned integer."
                                      
                                      titleCell?.textLabel?.numberOfLines = 0
                                      titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                      titleCell?.textLabel?.textAlignment = .center
                                      titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                      
                                      return titleCell!
        }
    }
    
    
}
