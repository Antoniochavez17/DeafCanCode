//
//  BitIntViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/9/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class BitIntViewController: UIViewController {

   
    @IBOutlet weak var BitIntVideos: WKWebView!
    @IBOutlet weak var BitIntTableView: UITableView!
    
    // Setting Storyboard ID
    var StoryboardID = [String]()
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        BitIntTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Bit Integers"
        
        Label(IDCode: "eshhEHBn7wQ")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        BitIntVideos.load(URLRequest(url: url!))

    }


}

extension BitIntViewController: UITableViewDataSource, UITableViewDelegate {
    
     
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 61
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: BitIntTitleTableViewCell!
        var code: BitIntCodeTableViewCell!
        var answer: BitIntAnswerTableViewCell!
        var exampled: ExampledTableViewCell!
        
          if indexPath.row == 60 {
             answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                                                 answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                                 answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                                 answer?.textLabel?.text = """
                                                 The minimum value for UInt64 is 0
                                                 """
                                                 answer?.textLabel?.numberOfLines = 0
                                                 answer?.textLabel?.lineBreakMode = .byWordWrapping
                                                 answer?.textLabel?.textAlignment = .center
                                                 answer?.textLabel?.textColor = UIColor.white
                                                 return answer!
         } else if indexPath.row == 59 {
             code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                         
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                           let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                           attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                       
                                       attr.append(NSAttributedString(string: "\"The minimun value for Unsigned UInt64 is", attributes: [.foregroundColor: StringSyntax]))
                                       
                                        attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                                        attr.append(NSAttributedString(string: "UInt64", attributes: [.foregroundColor: projectSyntax]))
                                        attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                        attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                                        attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                        attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                       attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                       
                                       
                                            code?.textLabel?.attributedText = attr
                                    
                 
                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                 code?.textLabel?.numberOfLines = 0
                 code?.textLabel?.lineBreakMode = .byWordWrapping
                 code?.textLabel?.textAlignment = .left
                                       
                                         
                 return code!
         } else if indexPath.row == 58 {
             titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
                         
                         titleCell?.textLabel?.text = "The minimum numbers have limited in the 64-bit unsigned integers."
            
         
                           
                           titleCell?.textLabel?.numberOfLines = 0
                           titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                           titleCell?.textLabel?.textAlignment = .center
                           titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                           
                           return titleCell!
         } else if indexPath.row == 57 {
             answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                                     answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                     answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                     answer?.textLabel?.text = """
                                     The maximum value for UInt64 is
                                     18446744073709551615
                                     """
                                     answer?.textLabel?.numberOfLines = 0
                                     answer?.textLabel?.lineBreakMode = .byWordWrapping
                                     answer?.textLabel?.textAlignment = .center
                                     answer?.textLabel?.textColor = UIColor.white
                                     return answer!
         } else if indexPath.row == 56 {
             code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                                                 
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "\"The maximum value for Unsigned UInt64 is", attributes: [.foregroundColor: StringSyntax]))
                              
                               attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "UInt64", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                              
                              
                                   code?.textLabel?.attributedText = attr
                           
                                         
                                         code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                         code?.textLabel?.numberOfLines = 0
                                         code?.textLabel?.lineBreakMode = .byWordWrapping
                                         code?.textLabel?.textAlignment = .left
                                                               
                                                                 
                                         return code!
         } else if indexPath.row == 55 {
             titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
             
             titleCell?.textLabel?.text = "The maximum numbers have limited in the 64-bit unsigned integers."
               
               titleCell?.textLabel?.numberOfLines = 0
               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
               titleCell?.textLabel?.textAlignment = .center
               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
               
               return titleCell!
         } else if indexPath.row == 54{
             answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                         answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                         answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                         answer?.textLabel?.text = """
                         The minimum value for UInt32 is 0
                         """
                         answer?.textLabel?.numberOfLines = 0
                         answer?.textLabel?.lineBreakMode = .byWordWrapping
                         answer?.textLabel?.textAlignment = .center
                         answer?.textLabel?.textColor = UIColor.white
                         return answer!
         } else if indexPath.row == 53 {
             code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                                     
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "\"The minimum value for Unsigned Int is", attributes: [.foregroundColor: StringSyntax]))
                              
                               attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "UInt32", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                              
                              
                                   code?.textLabel?.attributedText = attr
                           
                             
                             code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                             code?.textLabel?.numberOfLines = 0
                             code?.textLabel?.lineBreakMode = .byWordWrapping
                             code?.textLabel?.textAlignment = .left
                                                   
                                                     
                             return code!
         } else if indexPath.row == 52 {
             titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
             
             titleCell?.textLabel?.text = "The minimum numbers have limited in the 32-bit unsigned integers."
            
            
               
               titleCell?.textLabel?.numberOfLines = 0
               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
               titleCell?.textLabel?.textAlignment = .center
               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
               
               return titleCell!
         } else if indexPath.row == 51 {
             answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
             answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
             answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
             answer?.textLabel?.text = """
             The maximum value for UInt32 is
             4294967295
             """
             answer?.textLabel?.numberOfLines = 0
             answer?.textLabel?.lineBreakMode = .byWordWrapping
             answer?.textLabel?.textAlignment = .center
             answer?.textLabel?.textColor = UIColor.white
             return answer!
         } else if indexPath.row == 50 {
             code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                         
               code?.textLabel?.font = setFont
                 
            // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "\"The maximum value for Unsigned Int is", attributes: [.foregroundColor: StringSyntax]))
                              
                               attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "UInt32", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                              
                              
                                   code?.textLabel?.attributedText = attr
                           
            
                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                 code?.textLabel?.numberOfLines = 0
                 code?.textLabel?.lineBreakMode = .byWordWrapping
                 code?.textLabel?.textAlignment = .left
                                       
                                         
                 return code!

         } else if indexPath.row == 49 {
             titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
             
             titleCell?.textLabel?.text = "The maximum numbers have limited in the 32-bit unsigned integers."
            
            
               
               titleCell?.textLabel?.numberOfLines = 0
               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
               titleCell?.textLabel?.textAlignment = .center
               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
               
               return titleCell!
         } else if indexPath.row == 48 {
             answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                                               answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                               answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                               answer?.textLabel?.text = """
                                               The minimum value for UInt16 is
                                               0
                                               """
                                               answer?.textLabel?.numberOfLines = 0
                                               answer?.textLabel?.lineBreakMode = .byWordWrapping
                                               answer?.textLabel?.textAlignment = .center
                                               answer?.textLabel?.textColor = UIColor.white
                                               return answer!
         } else if indexPath.row == 47 {
             code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                         
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "\"The minimum value for Unsigned Int is", attributes: [.foregroundColor: StringSyntax]))
                              
                               attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "UInt16", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                              
                              
                                   code?.textLabel?.attributedText = attr
                           
                 
                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                 code?.textLabel?.numberOfLines = 0
                 code?.textLabel?.lineBreakMode = .byWordWrapping
                 code?.textLabel?.textAlignment = .left
                                       
                                         
                 return code!
         } else if indexPath.row == 46 {
             titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
             
             titleCell?.textLabel?.text = "The minimum numbers have limited in the 16-bit unsigned integers."
               
               titleCell?.textLabel?.numberOfLines = 0
               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
               titleCell?.textLabel?.textAlignment = .center
               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
               
               return titleCell!
         } else if indexPath.row == 45 {
             answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                                   answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                   answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                   answer?.textLabel?.text = """
                                   The maximum value for Unsigned Int16 is 65535
                                   """
                                   answer?.textLabel?.numberOfLines = 0
                                   answer?.textLabel?.lineBreakMode = .byWordWrapping
                                   answer?.textLabel?.textAlignment = .center
                                   answer?.textLabel?.textColor = UIColor.white
                                   return answer!
         } else if indexPath.row == 45 {
             code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                         
                code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "\"The maximum value for Unsigned Int16 is", attributes: [.foregroundColor: StringSyntax]))
                              
                               attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "UInt16", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                              
                              
                                   code?.textLabel?.attributedText = attr
                           
                 
                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                 code?.textLabel?.numberOfLines = 0
                 code?.textLabel?.lineBreakMode = .byWordWrapping
                 code?.textLabel?.textAlignment = .left
                                       
                                         
                 return code!
         } else if indexPath.row == 44 {
             titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
                        
                        titleCell?.textLabel?.text = "The maximum numbers have limited in the 16-bit unsigned integers."
                          
                          titleCell?.textLabel?.numberOfLines = 0
                          titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                          titleCell?.textLabel?.textAlignment = .center
                          titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                          
                          return titleCell!
         } else if indexPath.row == 43 {
             answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
             answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
             answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
             answer?.textLabel?.text = """
             The minimum value for Unsigned Int8 is 0
             """
             answer?.textLabel?.numberOfLines = 0
             answer?.textLabel?.lineBreakMode = .byWordWrapping
             answer?.textLabel?.textAlignment = .center
             answer?.textLabel?.textColor = UIColor.white
             return answer!
         } else if indexPath.row == 42 {
             code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                         
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "\"The minimum value for Unsigned Int is", attributes: [.foregroundColor: StringSyntax]))
                              
                               attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "UInt8", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                              
                              
                                   code?.textLabel?.attributedText = attr
                           
                 
                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                 code?.textLabel?.numberOfLines = 0
                 code?.textLabel?.lineBreakMode = .byWordWrapping
                 code?.textLabel?.textAlignment = .left
                                       
                                         
                 return code!
         } else if indexPath.row == 41 {
             titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
                                    
                                    titleCell?.textLabel?.text = "The minimum numbers have limited in the 8-bit unsigned integers."
                                      
                                      titleCell?.textLabel?.numberOfLines = 0
                                      titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                      titleCell?.textLabel?.textAlignment = .center
                                      titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                      
                                      return titleCell!
         } else if indexPath.row == 40 {
             answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
             answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
             answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
             answer?.textLabel?.text = """
             The maximum value for Unsigned Int8 is
             255
             """
             answer?.textLabel?.numberOfLines = 0
             answer?.textLabel?.lineBreakMode = .byWordWrapping
             answer?.textLabel?.textAlignment = .center
             answer?.textLabel?.textColor = UIColor.white
             return answer!
         } else if indexPath.row == 39 {
             code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                         
              code?.textLabel?.font = setFont
                 
            // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "\"The maximum value for Unsigned Int8 is", attributes: [.foregroundColor: StringSyntax]))
                              
                               attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "UInt8", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                              
                              
                                   code?.textLabel?.attributedText = attr
                           
            
                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                 code?.textLabel?.numberOfLines = 0
                 code?.textLabel?.lineBreakMode = .byWordWrapping
                 code?.textLabel?.textAlignment = .left
                                       
                                         
                 return code!
         } else if indexPath.row == 38 {
             titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
                        
                        titleCell?.textLabel?.text = "The maximum numbers have limited in the 8-bit unsigned integers."
                          
                          titleCell?.textLabel?.numberOfLines = 0
                          titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                          titleCell?.textLabel?.textAlignment = .center
                          titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                          
                          return titleCell!
         } else if indexPath.row == 37 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                                  answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                  answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                  answer?.textLabel?.text = """
                                  The minimum value for Unsigned Int is 0
                                  """
                                  answer?.textLabel?.numberOfLines = 0
                                  answer?.textLabel?.lineBreakMode = .byWordWrapping
                                  answer?.textLabel?.textAlignment = .center
                                  answer?.textLabel?.textColor = UIColor.white
                                  return answer!
        } else if indexPath.row == 36 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                        
                code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                 attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                             
                             attr.append(NSAttributedString(string: "\"The minimum value for Unsigned Int is", attributes: [.foregroundColor: StringSyntax]))
                             
                              attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                              attr.append(NSAttributedString(string: "UInt", attributes: [.foregroundColor: projectSyntax]))
                              attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                              attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                              attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                             
                             
                                  code?.textLabel?.attributedText = attr
                          
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 35 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
            
            titleCell?.textLabel?.text = "The minimum in the unsigned integers will be full zero means you can't pass anywhere like positive or negative numbers."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 34 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       The maximum value for unsigned Int is 255
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 33 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                        
                code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The maximum value for Unsigned Int is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "UInt", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 32 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
            
            titleCell?.textLabel?.text = "The UInt is standing for Unsigned Integers, and Int is a signed Integers. The UInt could be differents limited numbers than Int. Both integers in macOS and may be 32-bit, or 64-bit integers depending on the target for iOS."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 31 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            The maximum value for Int64 is 9223372036854775807
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 30 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The minimum value for Int64 is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Int64", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 29 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
                                  
                                  titleCell?.textLabel?.text = "The minimum numbers have limited in the 64-bit signed integers."
                                    
                                    titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 28 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                           answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                           answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                           answer?.textLabel?.text = """
                           The maximum value for Int64 is 9223372036854775807
                           """
                           answer?.textLabel?.numberOfLines = 0
                           answer?.textLabel?.lineBreakMode = .byWordWrapping
                           answer?.textLabel?.textAlignment = .center
                           answer?.textLabel?.textColor = UIColor.white
                           return answer!
        } else if indexPath.row == 27 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                                   
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The maximum value for Int64 is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Int64", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                           
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        } else if indexPath.row == 26 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "The regular signed integers always fill up to 64-bit signed integers. The maximum numbers have limited in the 64-bit signed integers."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!

        } else if indexPath.row == 25 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                answer?.textLabel?.text = """
                The minimum value for Int is -2147483647
                """
                answer?.textLabel?.numberOfLines = 0
                answer?.textLabel?.lineBreakMode = .byWordWrapping
                answer?.textLabel?.textAlignment = .center
                answer?.textLabel?.textColor = UIColor.white
                return answer!
          
        } else if indexPath.row == 24 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The minimum value for Int32 is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Int32", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 23 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
            
            titleCell?.textLabel?.text = "The minimum numbers have limited in the 32-bit signed integers."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!

        } else if indexPath.row == 22 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            The maximum value for Int is 2147483647
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 21 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                                                         
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The maximum value for Int32 is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Int32", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                                                 
                                                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                 code?.textLabel?.numberOfLines = 0
                                                 code?.textLabel?.lineBreakMode = .byWordWrapping
                                                 code?.textLabel?.textAlignment = .left
                                                                       
                                                                         
                                                 return code!
        } else if indexPath.row == 20 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
            
            titleCell?.textLabel?.text = "The maximum numbers have limited in the 32-bit signed integers."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 19 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                                  answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                  answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                  answer?.textLabel?.text = """
                                  The minimum value for Int16 is -32767
                                  """
                                  answer?.textLabel?.numberOfLines = 0
                                  answer?.textLabel?.lineBreakMode = .byWordWrapping
                                  answer?.textLabel?.textAlignment = .center
                                  answer?.textLabel?.textColor = UIColor.white
                                  return answer!
        } else if indexPath.row == 18 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
            
            code?.textLabel?.font = setFont
            
                                      
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The minimum value for Int16 is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Int16", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 17 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
            
            titleCell?.textLabel?.text = "The minimum numbers have limited in the 16-bit signed integers."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 16 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       The maximum value for Int is 32767
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!

        } else if indexPath.row == 15 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                                   
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The maximum value for Int16 is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Int16", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                           
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        } else if indexPath.row == 14 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
            
            titleCell?.textLabel?.text = "The maximum numbers have limited in the 16-bit signed integers."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 13 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       The minimum value for Int8 is -127
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 12 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The minimum value for Int8 is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Int8", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!

        } else if indexPath.row == 11 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
            
            titleCell?.textLabel?.text = "Now, Let maximum instead to a minimum to see how much does limited numbers are 8-bit signed integers."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 10 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            The maximum value for Int8 is 127
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 9 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The maximum value for Int is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Int8", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 8 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
            
            titleCell?.textLabel?.text = "You will see how much-limited numbers for 8-bit signed integers is the beginning number from Int's limited number at maximum."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 7 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       The minimum value for Int is -9223372036854775807
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 6 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                                   
            code?.textLabel?.font = setFont
                           
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"The minimum value for Int is", attributes: [.foregroundColor: StringSyntax]))
                   
                    attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                   
                        code?.textLabel?.attributedText = attr
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        } else if indexPath.row == 5 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
                                  
                                  titleCell?.textLabel?.text = "The min stands for minimum numbers means you can't pass these negative limited numbers."
                                    
                                    titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!

        } else if indexPath.row == 4 {
            answer = BitIntTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BitIntAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            The maximum value for Int is 9223372036854775807
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 3 {
            code = BitIntTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BitIntCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
            
                // MARK: Nsattributedstring
                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"The maximum value for Int is", attributes: [.foregroundColor: StringSyntax]))
            
             attr.append(NSAttributedString(string: " \\(", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            
                 code?.textLabel?.attributedText = attr

            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 2 {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
                                  
                                  titleCell?.textLabel?.text = "The max stands for maximum numbers means you can't pass these highly limited numbers."
                                    
                                    titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 1 {
          
        
            exampled = BitIntTableView.dequeueReusableCell(withIdentifier: "ExampledCells") as? ExampledTableViewCell
            
            exampled?.footerLbl.text = "You can learn before using bit integers."
            exampled?.ExampledLbl.text = "Bit Inegters: Exampled"
            exampled?.ExampledLbl?.textColor = UIColor.white
             return exampled

        } else {
            titleCell = BitIntTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BitIntTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "Apple introduced A7 processors chips build on 64-bit architecture for iPhone 5S, and iPad Air, and Mini with Retina Display feature in 2013. Since Apple introduced the early iPhone and iPad has a 32-Bit architecture. Apple alerts millions of iOS Developers since 64-Bit architecture rolled out. If you don't update these apps to support 64-Bit architecture, Then the app will not be working anymore. Apple had announced iOS 11 at WWDC17,  due to iOS 11 has no longer to support 32-Bit architecture devices means you have to update apps to support 64-Bit architecture for iOS 11."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        if indexPath.row == 1 {
        
            let Swift = storyboard?.instantiateViewController(withIdentifier: "Exampled")
                             

        self.navigationController?.pushViewController(Swift!, animated: true)
            
        }
        
    }
    
    
}
