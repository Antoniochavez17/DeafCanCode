//
//  IfViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/4/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class IfViewController: UIViewController {

    @IBOutlet weak var IfVideos: WKWebView!
    
    @IBOutlet weak var ifTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        ifTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "If"
        
        Label(IDCode: "5S8DEHKjjz8")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        IfVideos.load(URLRequest(url: url!))

    }
    
}


extension IfViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 14
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let titleCell: IfTitleTableViewCell!
        let code: IfCodeTableViewCell!
        let answer: IfAnswerTableViewCell!
        
        if indexPath.row == 13 {
            answer = ifTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? IfAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            300.27 is moderate risk level.
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 12 {
            code = ifTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? IfCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "radioactive_Level ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "300.27\n", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       
             attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "100 ", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
              attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                  
                        attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                       
                        attr.append(NSAttributedString(string: "is tolerable risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                       
                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       
             attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "500 ", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                 
                       attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "is moderate risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                      
                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
             attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
            
            
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
         
            attr.append(NSAttributedString(string: "if", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       
             attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: " > ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "500 ", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                 
                       attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "is high risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                      
                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "11.", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
           code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 11 {
            titleCell = ifTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? IfTitleTableViewCell
            
            titleCell?.textLabel?.text = "Let's talk about the radiation level. You can custom a number in the variable's values to see how the console will tell you. Remember, what you learned about Int() in the course of the number? The first condition has limited as 0 to 100 then a tolerable level will be displayed in the console. The second condition has limited as 100 to 500 then a moderate risk will be displayed in the console.  The third condition has limited as 500 and above then a high risk will be displayed in the console."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 10 {
            answer = ifTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? IfAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Statement one
            Statement two
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 9 {
            code = ifTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? IfCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "x ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "10\n", attributes: [.foregroundColor: NumberSyntax]))
                
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                      attr.append(NSAttributedString(string: "y ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                     
                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "8\n", attributes: [.foregroundColor: NumberSyntax]))
            
                attr.append(NSAttributedString(string: "3. \n", attributes: [.foregroundColor: counterSyntax]))
            
                         
             attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
              attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "x ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "> ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
              attr.append(NSAttributedString(string: "0 ", attributes: [.foregroundColor: projectSyntax]))
            
              attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            
             attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
              attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Frist Statements\"", attributes: [.foregroundColor: StringSyntax]))
            
              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "7. \n", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                        attr.append(NSAttributedString(string: "y ", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: "!= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                       
                         attr.append(NSAttributedString(string: "x ", attributes: [.foregroundColor: projectSyntax]))
                       
                         attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
              attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Frist Statements\"", attributes: [.foregroundColor: StringSyntax]))
            
              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
             attr.append(NSAttributedString(string: "10.", attributes: [.foregroundColor: counterSyntax]))
            
              attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
            code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 8 {
            titleCell = ifTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? IfTitleTableViewCell
            
            titleCell?.textLabel?.text = "When you text two variables, you can make more if statements to execute these statements they'll be displayed in the console, unless it was true."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 7 {
            answer = ifTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? IfAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            It's time to show!
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 6 {
           code = ifTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? IfCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
                // MARK: Nsattributedstring
                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\'It's time to show!\"\n", attributes: [.foregroundColor: StringSyntax]))
             attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "str", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                        
                         attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                        
                          code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 5 {
            titleCell = ifTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? IfTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "The printing allows executing the statements to display in the console if the condition is a true otherwise, if conditions is a false, then it will not be display in the consoles."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 4 {
            answer = ifTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? IfAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            true
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 3 {
            code = ifTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? IfCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

             attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "strFirst ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"Swift\"\n", attributes: [.foregroundColor: StringSyntax]))
            
             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                     attr.append(NSAttributedString(string: "strSecond ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "\"Swift\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                              attr.append(NSAttributedString(string: "checkStr ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                              attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                              attr.append(NSAttributedString(string: "strFirst ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: PlainSyntax]))
                     
            
            attr.append(NSAttributedString(string: "strSecond\n", attributes: [.foregroundColor: projectSyntax]))
                     
            
            attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "checkStr ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
                   attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"true\"", attributes: [.foregroundColor: StringSyntax]))

             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
                 attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
             code?.textLabel?.attributedText = attr
            
            
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 2 {
            titleCell = ifTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? IfTitleTableViewCell
            
            titleCell?.textLabel?.text = "You could see this final code with name values to include in the if's condition to execute the statements in the console. That will be telling you if these two values are equal or not. The reason this printing will not display in the console is if these two values are false."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 1 {
            code = ifTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? IfCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                    
                                attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: " condition ", attributes: [.backgroundColor: dynamicBackground]))
                     
                     attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "2.    ", attributes: [.foregroundColor: counterSyntax]))
                     
                      attr.append(NSAttributedString(string: " first statements ", attributes: [.backgroundColor: dynamicBackground]))
             attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
                                attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                                    
                     code?.textLabel?.attributedText = attr
            
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
            
        } else {
           titleCell = ifTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? IfTitleTableViewCell
            
            titleCell?.textLabel?.text = "The if's condition means You can choose any codes based on true, To execute a statement. If you don't want to add the code in the condition, then you could dismiss this condition. The if's statements mean statements will execute code on the evaluation on one condition or more conditions."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        }
    }
    
    
}
