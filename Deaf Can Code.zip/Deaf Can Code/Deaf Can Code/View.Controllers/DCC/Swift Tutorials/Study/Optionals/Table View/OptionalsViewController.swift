//
//  OptionalsViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class OptionalsViewController: UIViewController {

    @IBOutlet weak var OptionalsTableView: UITableView!
    @IBOutlet weak var OptionalVideos: WKWebView!
    
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        OptionalsTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Optionals"
        
        Label(IDCode: "2l8NC3UtSFs")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        OptionalVideos.load(URLRequest(url: url!))

    }

}

extension OptionalsViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 41
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: OptionalsTitleTableViewCell!
        var code: OptionalsCodeTableViewCell!
        var answer: OptionalsAnswerTableViewCell!
        
        if indexPath.row == 40 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            No Error
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 39 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                                                         
           code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                          let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                          attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                          
                                          attr.append(NSAttributedString(string: "errorDescription", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                          attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                
            attr.append(NSAttributedString(string: "errorDescription ", attributes: [.foregroundColor: projectSyntax]))

                                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "nil\n", attributes: [.foregroundColor: KeyboardSyntax]))

            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                            
                         attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                         
                         attr.append(NSAttributedString(string: "description ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                         attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                          
                         attr.append(NSAttributedString(string: "errorDescription ", attributes: [.foregroundColor: projectSyntax]))
                      
                      
                       attr.append(NSAttributedString(string: "?? ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "\"No Error\"", attributes: [.foregroundColor: StringSyntax]))
                                           code?.textLabel?.attributedText = attr
                                                 
                                                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                 code?.textLabel?.numberOfLines = 0
                                                 code?.textLabel?.lineBreakMode = .byWordWrapping
                                                 code?.textLabel?.textAlignment = .left
                                                                       
                                                                         
                                                 return code!
        } else if indexPath.row == 38 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
                       
            titleCell?.textLabel?.text = "Now, It's calling the errorDescription to set all the concepts to empty.  The double question mark will check this then it'll return the right values due to empty. There does have two paths, that left is available, or right is for empty."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 37 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
                                            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                            answer?.textLabel?.text = """
                                            No Error
                                            """
                                            answer?.textLabel?.numberOfLines = 0
                                            answer?.textLabel?.lineBreakMode = .byWordWrapping
                                            answer?.textLabel?.textAlignment = .center
                                            answer?.textLabel?.textColor = UIColor.white
                                            return answer!
        } else if indexPath.row == 36 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                                              
            code?.textLabel?.font = setFont
            
              
                      // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "errorDescription", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                      attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      

               attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
               
               attr.append(NSAttributedString(string: "description ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                
               attr.append(NSAttributedString(string: "errorDescription ", attributes: [.foregroundColor: projectSyntax]))
            
            
             attr.append(NSAttributedString(string: "?? ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "\"No Error\"", attributes: [.foregroundColor: StringSyntax]))
                                 code?.textLabel?.attributedText = attr
                                      
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 35 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
                       
            titleCell?.textLabel?.text = "Or this code concept if you want to call from previous code concept. The double question mark means to check if errorDescription is available or not. If they are available, then it will stay."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 34 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
                                 answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                 answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                 answer?.textLabel?.text = """
                                 No Error
                                 """
                                 answer?.textLabel?.numberOfLines = 0
                                 answer?.textLabel?.lineBreakMode = .byWordWrapping
                                 answer?.textLabel?.textAlignment = .center
                                 answer?.textLabel?.textColor = UIColor.white
                                 return answer!
        } else if indexPath.row == 33 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                                   
             code?.textLabel?.font = setFont
                             
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "errorDescription", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "String ", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))

                        attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                          
                          attr.append(NSAttributedString(string: "description", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                          attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                attr.append(NSAttributedString(string: "String ", attributes: [.foregroundColor: projectSyntax]))

                attr.append(NSAttributedString(string: "!\n", attributes: [.foregroundColor: PlainSyntax]))
         
                      attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                          attr.append(NSAttributedString(string: "if let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                        
                                        attr.append(NSAttributedString(string: "descriptionString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                              attr.append(NSAttributedString(string: "errorDescription ", attributes: [.foregroundColor: projectSyntax]))

                              attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "description ", attributes: [.foregroundColor: projectSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "descriptionString\n", attributes: [.foregroundColor: projectSyntax]))


            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
               attr.append(NSAttributedString(string: " else ", attributes: [.foregroundColor: KeyboardSyntax]))
            
               attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "description ", attributes: [.foregroundColor: projectSyntax]))

                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "\"No Error\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))

                   attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
                       code?.textLabel?.attributedText = attr


            
          
                           
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        } else if indexPath.row == 32 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
                       
            titleCell?.textLabel?.text = "The final tutorials about optional. The if's statements have a errorDescription of which assignment to errorDescription from previous to see if errorDescription does have available or not. That's called nil coalescing operator."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 31 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       604: RESOURCE WAS NOT FOUND.
                       Please try again!
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 30 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                        
            code?.textLabel?.font = setFont
    
            // MARK: Nsattributedstring
                             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                             attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                             
                             attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                             attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                   attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))

                   attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                   attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))

                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                   attr.append(NSAttributedString(string: "\"404\"\n", attributes: [.foregroundColor: StringSyntax]))

                   attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                   
                                   attr.append(NSAttributedString(string: "errorDescription ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                   attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                         attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))

                         attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                         
                   attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                   
                   attr.append(NSAttributedString(string: "if let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                              
                        attr.append(NSAttributedString(string: "theError ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                   
                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
                   
                   attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                              
                   attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                         
                                   attr.append(NSAttributedString(string: "errorCodeInteger ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                              
                              attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                              
                    attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                    attr.append(NSAttributedString(string: "theError", attributes: [.foregroundColor: projectSyntax]))
                   
                    attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                              attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                         
                 
                            attr.append(NSAttributedString(string: "errorCodeInteger ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: "404 ", attributes: [.foregroundColor: NumberSyntax]))
                   
                   attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                   
                     attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                   attr.append(NSAttributedString(string: "errorDescription ", attributes: [.foregroundColor: projectSyntax]))
                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                        attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
                   attr.append(NSAttributedString(string: "errorCodeInteger ", attributes: [.foregroundColor: projectSyntax]))
                   attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                   attr.append(NSAttributedString(string: "200", attributes: [.foregroundColor: NumberSyntax]))
                   attr.append(NSAttributedString(string: ": resource was not found.\"\n", attributes: [.foregroundColor: StringSyntax]))
                   attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                   attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                   
                    attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                   attr.append(NSAttributedString(string: "upCaseErrorDescription ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                     attr.append(NSAttributedString(string: "errorDescription", attributes: [.foregroundColor: projectSyntax]))
                   
                   attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                   attr.append(NSAttributedString(string: "uppercased", attributes: [.foregroundColor: projectSyntax]))

                    attr.append(NSAttributedString(string: "()\n", attributes: [.foregroundColor: PlainSyntax]))
                   
                    attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))

                    attr.append(NSAttributedString(string: "errorDescription\n", attributes: [.foregroundColor: projectSyntax]))
             
                   
             attr.append(NSAttributedString(string: "9.\n", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "upCaseerrorDescription", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "uppercased", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "?.", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: projectSyntax]))
           
            attr.append(NSAttributedString(string: "\"Please try again!\"", attributes: [.foregroundColor: StringSyntax]))
            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: projectSyntax]))

            
             attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
            

            attr.append(NSAttributedString(string: "upCaseErrorDescription", attributes: [.foregroundColor: projectSyntax]))
                              code?.textLabel?.attributedText = attr

            
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 29 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
            
            titleCell?.textLabel?.text = "You notice this errorCodeInteger is to use Int( ) to allows these strings to become integers, and inside of the statements is to use the string interpolation to allow the errorCodeInteger total the numbers. The question mark appears after the calling name value because errorDescription does pull the errorInteger, which behind the errorCodeString had the optional, too. You could know about append( ) that allows you to add somethings at the end sentence."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 28 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            604: RESOURCE WAS NOT FOUND.
            604: resource was not found.
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 27 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
               
             code?.textLabel?.font = setFont
                
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"404\"\n", attributes: [.foregroundColor: StringSyntax]))

            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                            
                            attr.append(NSAttributedString(string: "errorDescription ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                  attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))

                  attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                  
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "if let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                       
                 attr.append(NSAttributedString(string: "theError ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                       
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                  
                            attr.append(NSAttributedString(string: "errorCodeInteger ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                       
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "theError", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                  
          
                     attr.append(NSAttributedString(string: "errorCodeInteger ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
                
                attr.append(NSAttributedString(string: "404 ", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "errorDescription ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "errorCodeInteger ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            attr.append(NSAttributedString(string: "200", attributes: [.foregroundColor: NumberSyntax]))
            attr.append(NSAttributedString(string: ": resource was not found.\"\n", attributes: [.foregroundColor: StringSyntax]))
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                     attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "upCaseErrorDescription ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

              attr.append(NSAttributedString(string: "errorDescription", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "uppercased", attributes: [.foregroundColor: projectSyntax]))

             attr.append(NSAttributedString(string: "()\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))

             attr.append(NSAttributedString(string: "errorDescription", attributes: [.foregroundColor: projectSyntax]))
      
            
                       code?.textLabel?.attributedText = attr

                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 26 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
            
            titleCell?.textLabel?.text = "If you want those string to become full uppercases strings, then use uppercased(), or lowercased() is allows strings to become a full lowercase strings. Otherwise, leave the calling alone if you don't want to customize."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 25 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            nil
            nil
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 24 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                                                         let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                         attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                         
                                                         attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                         attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                               attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                               attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: PlainSyntax]))
                                               
              attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))

              attr.append(NSAttributedString(string: "nil\n", attributes: [.foregroundColor: KeyboardSyntax]))
                                     attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                    attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                            
                                                                                            attr.append(NSAttributedString(string: "firstMethod", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                                                                  attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                                                           
                                                                                  
                                                 attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))

                                                 attr.append(NSAttributedString(string: "errorCodeString\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                              attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                                      
                                                                                                      attr.append(NSAttributedString(string: "secondMethod", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                                    
                                                                                            
                                                           attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                                           attr.append(NSAttributedString(string: "errorCodeString\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                              attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                                      
                                                                                                      attr.append(NSAttributedString(string: "thirdMethod", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                                                                            attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                                                                  
            attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: PlainSyntax]))
                                                                                            
                                                           attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))

                                                           attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
                                                         
                                                          code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 23 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "Will does this third methods face the crash? No, that third method was enabled optional, which was the same to errorCodeString will solve the crash."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 22 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                                    let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                                    attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                    
                                                                    attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                                          attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                                          attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: PlainSyntax]))
                                                          
                         attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))

                         attr.append(NSAttributedString(string: "nil\n", attributes: [.foregroundColor: KeyboardSyntax]))
                                                attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                               attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                                       
                                                                                                       attr.append(NSAttributedString(string: "firstMethod", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                                       attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                                                                             attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                                                                      
                                                                                             
                                                            attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))

                                                            attr.append(NSAttributedString(string: "errorCodeString\n", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                                         attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                                                 
                                                                                                                 attr.append(NSAttributedString(string: "secondMethod", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                                               
                                                                                                       
                                                                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                                                      attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
                       
                                                                    
                                                                     code?.textLabel?.attributedText = attr
                
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 21 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
            
            titleCell?.textLabel?.text = "Let's show you a two-method which behind the unwrapped optional. When you try to calling a first method in the printing, then the first method faced the crash due to the value is empty otherwise, it will not crashed if the value is available. What's about the second method? No, It will not face the crash if the value is empty or available."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 20 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Optional("404")
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 19 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                         let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                         attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                         
                                                         attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                         attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                               attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                               attr.append(NSAttributedString(string: "!\n", attributes: [.foregroundColor: PlainSyntax]))
                                               

                                     attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                     attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))
                                     
                                     
                                     attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                     
                                     attr.append(NSAttributedString(string: "\"404\"\n", attributes: [.foregroundColor: StringSyntax]))
                                     
                                               attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                               

                                               attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                               
                                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
                                               
                       
                           
                                                           attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                                         
                                                          code?.textLabel?.attributedText = attr
                       
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 18 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "It is time to learn about unwrapped optional.  Perhaps you could not use those unwrapped optional mostly. Let's rolled back. When you replace this question mark to exclamation mark is means forced unwrapping, which it's called implicitly unwrapped optional."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 17 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
                                            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                            answer?.textLabel?.text = """
                                            "404 : 404"
                                            """
                                            answer?.textLabel?.numberOfLines = 0
                                            answer?.textLabel?.lineBreakMode = .byWordWrapping
                                            answer?.textLabel?.textAlignment = .center
                                            answer?.textLabel?.textColor = UIColor.white
                                            return answer!
        } else if indexPath.row == 16 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            
            // MARK: Nsattributedstring
                                                                          let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                                          attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                          
                                                                          attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                          attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                                                attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                                                attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                                                                

                                                      attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                                      attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))
                                                      
                                                      
                                                      attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                                      
                                                      attr.append(NSAttributedString(string: "\"404\"\n", attributes: [.foregroundColor: StringSyntax]))
                                                      
                                                                attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                                                
                              attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))

                             attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "theError ", attributes: [.foregroundColor: PlainSyntax]))

                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                             
                              attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
                             
                              attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
                             
                                   attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
               attr.append(NSAttributedString(string: " if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                          
                                          attr.append(NSAttributedString(string: "errorCodeInteger ", attributes: [.foregroundColor: PlainSyntax]))

                                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                        
              attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
            
              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                         attr.append(NSAttributedString(string: "theError", attributes: [.foregroundColor: PlainSyntax]))
                                        
              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                         attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                   
            
                                               attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                                                                    
                                                                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                          attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                                                          
                                                                                          attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                                                                            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                       
                                                                                            attr.append(NSAttributedString(string: "theError", attributes: [.foregroundColor: PlainSyntax]))

                                                                                                   attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                                                                   
            attr.append(NSAttributedString(string: " : ", attributes: [.foregroundColor: StringSyntax]))
       
                     attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
                                
                     attr.append(NSAttributedString(string: "errorCodeInteger", attributes: [.foregroundColor: PlainSyntax]))

                            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                                                
            
                                                                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                              attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                             
                             attr.append(NSAttributedString(string: " } \n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                      
                                      attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
                                     
                                                                           code?.textLabel?.attributedText = attr
                                        
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 15 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
            
            titleCell?.textLabel?.text = "The optional binding has this theError is assignment to errorCodeString, which it's behind the optional with the String, but a new optional binding called errorCodeInteger to allows the String to become a Integers by using Int( ). Now you can see the other optional binding inside of the optional binding, which it's called nests optional binding."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 14 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
                                 answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                 answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                 answer?.textLabel?.text = """
                                 "404"
                                 """
                                 answer?.textLabel?.numberOfLines = 0
                                 answer?.textLabel?.lineBreakMode = .byWordWrapping
                                 answer?.textLabel?.textAlignment = .center
                                 answer?.textLabel?.textColor = UIColor.white
                                 return answer!
        } else if indexPath.row == 13 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                                   
           code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                
                                                                attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                                      attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                                      attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                                                      

                                            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                            attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))
                                            
                                            
                                            attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                            
                                            attr.append(NSAttributedString(string: "\"404\"\n", attributes: [.foregroundColor: StringSyntax]))
                                            
                                                      attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                                      
                    attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))

                   attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: "theError ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                   
                    attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
                   
                    attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
                   
                         attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                                      attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                                      
                                            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                 attr.append(NSAttributedString(string: "theError", attributes: [.foregroundColor: projectSyntax]))
                                                      
                             
                                                                  attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                                                

                                    attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                   
                   attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
                           
                                                                 code?.textLabel?.attributedText = attr
                              
                           
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        } else if indexPath.row == 12 {
          titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
            
            titleCell?.textLabel?.text = "The optionals could use the value bundling which it's called optional binding."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 11 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
                      answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                      answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                      answer?.textLabel?.text = """
                      "404"
                      """
                      answer?.textLabel?.numberOfLines = 0
                      answer?.textLabel?.lineBreakMode = .byWordWrapping
                      answer?.textLabel?.textAlignment = .center
                      answer?.textLabel?.textColor = UIColor.white
                      return answer!
        } else if indexPath.row == 10 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                         let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                         attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                         
                                                         attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                         attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                               attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                               attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                                               

                                     attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                     attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))
                                     
                                     
                                     attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                     
                                     attr.append(NSAttributedString(string: "\"404\"\n", attributes: [.foregroundColor: StringSyntax]))
                                     
                                               attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                               
             attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))

             attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            
            attr.append(NSAttributedString(string: "nil ", attributes: [.foregroundColor: KeyboardSyntax]))

            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

              attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
              
              attr.append(NSAttributedString(string: "theError ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

              attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: "!\n", attributes: [.foregroundColor: PlainSyntax]))
            
                  attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                               attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                               
                                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          attr.append(NSAttributedString(string: "theError", attributes: [.foregroundColor: projectSyntax]))
                                               
                      
                                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                                         

                             attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
                    
                                                          code?.textLabel?.attributedText = attr
                       
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 9 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
            
            titleCell?.textLabel?.text = "The optional has enabled in the errorCodeString's value, but the not equal operator in the if's condition means to check if two values is not equal will result true. otherwise false if two values is equal. That means it was true because errorCodeString's value was avaiables and other values is a empty is not equal. The exclamation mark means unwrapped optionals. You will learning about the unwrapped optionals."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 8 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Optional("404")
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 7 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
                // MARK: Nsattributedstring
                                              let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                              attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                              
                                              attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                              attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                    attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                                    attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                                    

                          attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                          attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))
                          
                          
                          attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                          
                          attr.append(NSAttributedString(string: "\"404\"\n", attributes: [.foregroundColor: StringSyntax]))
                          
                                    attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                    

                                    attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                    
                          attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))
                                    
                 attr.append(NSAttributedString(string: "as Any", attributes: [.foregroundColor: KeyboardSyntax]))
                
                                                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                              
                                               code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 6 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
            
            titleCell?.textLabel?.text = "You could notice the yellow alert which it stand for warning that says: \"Expression implicitly coerced from 'String?' to 'Any'\" due to the type has enabled the optionals which make confuse which is it, Then Any keyboard is allows you to take any kind of the code what you want."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 5 {
            answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Optional("404")
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 4 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
                
             // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                      attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
                      

            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "errorCodeString ", attributes: [.foregroundColor: projectSyntax]))
            
            
            attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "\"404\"\n", attributes: [.foregroundColor: StringSyntax]))
            
                      attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                      

                      attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                      
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
                      
                                  attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 code?.textLabel?.attributedText = attr
            
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 3 {
            titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
                      
                      titleCell?.textLabel?.text = "The previous is check the values which it was empty. Now, It's check if values does have aviables will display the Optional becuase of the optional operator been enabled behind the Type."
                        
                        titleCell?.textLabel?.numberOfLines = 0
                        titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                        titleCell?.textLabel?.textAlignment = .center
                        titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                        
                        return titleCell!
        } else if indexPath.row == 2 {
           answer = OptionalsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OptionalsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            nil
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 1 {
            code = OptionalsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OptionalsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "?\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
            
  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
       attr.append(NSAttributedString(string: "errorCodeString", attributes: [.foregroundColor: projectSyntax]))
            
                        attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                      
                       code?.textLabel?.attributedText = attr

                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else {
           titleCell = OptionalsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OptionalsTitleTableViewCell
            
            titleCell?.textLabel?.text = "The optional and operator is a bit differant means. It's does have a two things to know about the optional. The question mark to check if those values does have a avaiables, otherwise empty which it's called nil."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        }
        
    }
    
    
    
}
