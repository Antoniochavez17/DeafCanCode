//
//  SwiftTutorialsViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 11/29/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class SwiftTutorialsViewController: UIViewController {
    
    let Tutorials = ["Operators", "Printing", "Comments", "Variables", "Constants", "Strings", "String Interpolation", "Numbers", "Booleans", "If", "Else", "Else If", "Arrays", "Dictionaries", "Loops", "Type Annotations", "Sets", "Bit Integers", "Tuples", "Switchs", "Optionals", "Functions", "Closures", "Enumerations", "Structures", "Classes"]
    
    let headerTitles = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26"]
    
    var identifies = [String]()
    
    let diseabledTutorials = ["Protocols", "Error Handling", "Memory Managements"]
       
       let readIcon = [UIImage(named: "Untitled 6-13")]
       let forwardIcon = [UIImage(named: "Untitled 6")]
   
    
    @IBOutlet weak var SwiftTutorials: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        identifies = ["Operators", "Printing", "Comments", "Variables", "Constants", "Strings", "String Interpolation", "Numbers", "Booleans", "If", "Else", "Else If", "Arrays", "Dictionaries", "Loops", "Type Annotations", "Sets", "Bit Integers", "Tuples", "Switchs", "Optionals", "Functions", "Closures", "Enumerations", "Structures", "Classes"]
        
        self.SwiftTutorials.separatorStyle = UITableViewCell.SeparatorStyle.none
     
        let headerView = UIView()
               let footerView = UIView()
                   
                   headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
                   footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
                   
        let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 3.5)
                   
                   headerView.frame = sizeView
                   footerView.frame = sizeView
                   SwiftTutorials.tableHeaderView = headerView
                   SwiftTutorials.tableFooterView = footerView
     
        self.navigationItem.title = "Study"
    }
    
  
}

extension SwiftTutorialsViewController: UITableViewDelegate, UITableViewDataSource {
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Tutorials.count
        
    }
    
   
    

    // Height for cells
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    
    

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? SwiftTableViewCell
        cells?.SwiftTitle.text = Tutorials[indexPath.row]
        
        
        
        return cells!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
           
           let vcName = identifies[indexPath.row]
           
           let Swift = storyboard?.instantiateViewController(withIdentifier: vcName)
          
        
           self.navigationController?.pushViewController(Swift!, animated: true)
           
       }
    
    
    
}
