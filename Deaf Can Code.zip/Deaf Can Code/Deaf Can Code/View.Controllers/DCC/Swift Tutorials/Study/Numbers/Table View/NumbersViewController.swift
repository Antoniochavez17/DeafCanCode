//
//  NumbersViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/2/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class NumbersViewController: UIViewController {

    @IBOutlet weak var NumberVideo: WKWebView!
    @IBOutlet weak var NumberTableView: UITableView!

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        NumberTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Numbers"
        
        Label(IDCode: "OnnldSq_tBg")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        NumberVideo.load(URLRequest(url: url!))

    }
    
    
}


extension NumbersViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        23
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: NumberTitleTableViewCell!
        var code: NumberCodeTableViewCell!
        var answer: NumberAnswerTableViewCell!
        
        if indexPath.row == 22 {
            answer = NumberTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? NumberAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            10
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 21 {
            code = NumberTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? NumberCodeTableViewCell
                                        
          code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "wordCount ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
            attr.append(NSAttributedString(string: "\"Hello\"", attributes: [.foregroundColor: StringSyntax]))
                       
            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
               
             attr.append(NSAttributedString(string: "count\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "wordCount ", attributes: [.foregroundColor: projectSyntax]))
                                  
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                       attr.append(NSAttributedString(string: "\"World\"", attributes: [.foregroundColor: StringSyntax]))
                                  
                       attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                          
                        attr.append(NSAttributedString(string: "count\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
             code?.textLabel?.attributedText = attr
            
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 20 {
            titleCell = NumberTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? NumberTitleTableViewCell
            
            titleCell?.textLabel?.text = "When you create a variable called wordCount, and calling the name-value to combine this value to new values to see how much character does both values have, then it'll answer the total number."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 19 {
            answer = NumberTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? NumberAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            5
            """
            
            
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 18 {
            code = NumberTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? NumberCodeTableViewCell
                                        
          code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "wordCount ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
            attr.append(NSAttributedString(string: "\"Hello\"", attributes: [.foregroundColor: StringSyntax]))
                       
            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
               
             attr.append(NSAttributedString(string: "count", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
             code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 17 {
            titleCell = NumberTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? NumberTitleTableViewCell
            
            titleCell?.textLabel?.text = "The count keyboard is a collection of how many does characters had."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 16 {
            answer = NumberTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? NumberAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
              Mr.Smith's homework got 3 percentage.
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 15 {
            code = NumberTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? NumberCodeTableViewCell
                                        
            code?.textLabel?.font = setFont
            
             // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "wrong ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                
                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: "3.5\n", attributes: [.foregroundColor: NumberSyntax]))
                                
                                attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "num_Question ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                
                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: "10\n", attributes: [.foregroundColor: NumberSyntax]))
                                
                                attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "addType ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                
                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "wrong", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: " % ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
             attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "num_Question", attributes: [.foregroundColor: projectSyntax]))
                                           
                                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "4.", attributes: [.foregroundColor: counterSyntax]))
            
                                attr.append(NSAttributedString(string: "\"Mr.Smith's HomeWork results is ", attributes: [.foregroundColor: StringSyntax]))
                                
                                attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
                                
                                
                                attr.append(NSAttributedString(string: "addType", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                
                                 code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 14 {
            titleCell = NumberTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? NumberTitleTableViewCell
            
            titleCell?.textLabel?.text = "The doubles value in the Int with parenthesis is called floating-pointing to allows that Double become an Int."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 13 {
            code = NumberTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? NumberCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "int ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "() ", attributes: [.foregroundColor: PlainSyntax]))
            
            
             code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 12 {
            titleCell = NumberTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? NumberTitleTableViewCell
            
            titleCell?.textLabel?.text = "The Int( ) allows a double number to round number. For example, Leave it the same if the next digit is less than 5 (this is called rounding down), But increase it by 1 if the next digit is 5 or more (this is called rounding up)."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 11 {
            answer = NumberTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? NumberAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.8879147172, green: 0.1352083981, blue: 0.1976608932, alpha: 1)
            answer?.textLabel?.text = """
            Red error: Binary operator '+' cannot be applied to operands of type 'Double' and 'Int'.
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 10 {
            
        code = NumberTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? NumberCodeTableViewCell
                                    
           code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                       attr.append(NSAttributedString(string: "wrong ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "3.5\n", attributes: [.foregroundColor: NumberSyntax]))
                       
                       attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                       
                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                       attr.append(NSAttributedString(string: "num_Question ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "10\n", attributes: [.foregroundColor: NumberSyntax]))
                       
                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
                       attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                       attr.append(NSAttributedString(string: "finalResult ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "\"Mr.Smith's HomeWork results is ", attributes: [.foregroundColor: StringSyntax]))
                       
                       attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "wrong", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: " % ", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: "num_Question", attributes: [.foregroundColor: projectSyntax]))
                       
                       attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                       
                        code?.textLabel?.attributedText = attr
            
            
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
                                  
                                    
            return code!
        } else if indexPath.row == 9 {
            titleCell = NumberTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? NumberTitleTableViewCell
            
            titleCell?.textLabel?.text = "Why does this code concept get an error?  The double and integer is a different type number, which does request to executing the same type numbers to answer the total numbers."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 8 {
            answer = NumberTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? NumberAnswerTableViewCell
                                  answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                  answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                  answer?.textLabel?.text = """
                                    Mr.Smith's homework got 3 percentage.
                                  """
                                  answer?.textLabel?.numberOfLines = 0
                                  answer?.textLabel?.lineBreakMode = .byWordWrapping
                                  answer?.textLabel?.textAlignment = .center
                                  answer?.textLabel?.textColor = UIColor.white
                                  return answer!
        } else if indexPath.row == 7 {
            code = NumberTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? NumberCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "wrong ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "3\n", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "num_Question ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "10\n", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "finalResult ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Mr.Smith's HomeWork results is ", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "wrong", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: " % ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "num_Question", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
             code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 6 {
            titleCell = NumberTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? NumberTitleTableViewCell
            
            titleCell?.textLabel?.text = "You can make numbers with the addition, subtract,  multiply,  divide,  and modulus operator to answer a total number."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 5 {
            answer = NumberTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? NumberAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       35.5 is a double
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 4 {
            code = NumberTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? NumberCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "dou ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "35.5\n", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                    attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                   
                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "dou", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: " is a double.\" ", attributes: [.foregroundColor: StringSyntax]))
             code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 3 {
            titleCell = NumberTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? NumberTitleTableViewCell
            
            titleCell?.textLabel?.text = "The number does have a decimal point called double."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 2 {
            answer = NumberTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? NumberAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            35 is a integer
            """
            
            
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 1 {
            code = NumberTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? NumberCodeTableViewCell
                                    
           code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "int ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "35\n", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                    attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                   
                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "int", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: " is a integer.\" ", attributes: [.foregroundColor: StringSyntax]))

             code?.textLabel?.attributedText = attr
            
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
                                  
                                    
            return code!
        } else {
            titleCell = NumberTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? NumberTitleTableViewCell
            
            titleCell?.textLabel?.text = "The number doesn't have a decimal point called integers."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        }
    }
    
}
