//
//  ElseViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/6/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class ElseViewController: UIViewController {

    @IBOutlet weak var ElseTableView: UITableView!
    @IBOutlet weak var ElseVideos: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        ElseTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Else"
        
        Label(IDCode: "ia_WZLotQtg")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        ElseVideos.load(URLRequest(url: url!))

    }

}


extension ElseViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 11
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: ElseTitleTableViewCell!
        var code: ElseCodeTableViewCell!
        var answer: ElseAnswerTableViewCell!
        
        if indexPath.row == 10 {
            answer = ElseTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ElseAnswerTableViewCell
                                                   answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                                   answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                                   answer?.textLabel?.text = """
                       3530.42 is high risk level
                       """
                                                   answer?.textLabel?.numberOfLines = 0
                                                   answer?.textLabel?.lineBreakMode = .byWordWrapping
                                                   answer?.textLabel?.textAlignment = .center
                                                   answer?.textLabel?.textColor = UIColor.white
                                                   return answer!
        }  else if indexPath.row == 9 {
                         
            code = ElseTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ElseCodeTableViewCell
                                                                                                                         
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: "radioactive_Level ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                     
                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     
                     attr.append(NSAttributedString(string: "300.27\n", attributes: [.foregroundColor: NumberSyntax]))
                     
                     attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                     
                     attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                     
                     attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                      attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                     
                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                
                      attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: PlainSyntax]))
                     
                     attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                     
                     attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                     
                     attr.append(NSAttributedString(string: "100 ", attributes: [.foregroundColor: NumberSyntax]))
                     
                     attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                     
                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                 attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "is tolerable risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                                
                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                     
                      attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                     
                     attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                      attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                     
                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                
                      attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: PlainSyntax]))
                     
                     attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                     
                     attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                     
                     attr.append(NSAttributedString(string: "500 ", attributes: [.foregroundColor: NumberSyntax]))
                     
                     attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                     
                     attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                               
                               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                               
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                               
                                attr.append(NSAttributedString(string: "is moderate risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                               
                                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                     
        
                      attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                  
               attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
                     attr.append(NSAttributedString(string: " else ", attributes: [.foregroundColor: KeyboardSyntax]))
            
                     attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                     
                     attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                               
                               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                attr.append(NSAttributedString(string: "radioactive_Level", attributes: [.foregroundColor: projectSyntax]))
                               
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                               
                                attr.append(NSAttributedString(string: "is high risk level.\"", attributes: [.foregroundColor: StringSyntax]))
                               
                                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "10.", attributes: [.foregroundColor: counterSyntax]))
                     
                      attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                     
                    code?.textLabel?.attributedText = attr
                     
                                                                                                 
                                                                                                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                                                                 code?.textLabel?.numberOfLines = 0
                                                                                                 code?.textLabel?.lineBreakMode = .byWordWrapping
                                                                                                 code?.textLabel?.textAlignment = .left
                                                                                                                       
                                                                                                                         
                                                                                                return code!
        } else if indexPath.row == 8 {
                                 titleCell = ElseTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ElseTitleTableViewCell
                                 
                                 titleCell?.textLabel?.text = "The first condition is a checkI took copying from if course about radioactive and paste this code, but I replaced this last if keyboard to else keyboard is check if the number is high than the 500 in the variable."
                                   
                                   titleCell?.textLabel?.numberOfLines = 0
                                   titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                   titleCell?.textLabel?.textAlignment = .center
                                   titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                   
                                   return titleCell!
        } else if indexPath.row == 7 {
                          answer = ElseTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ElseAnswerTableViewCell
                                     answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                     answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                     answer?.textLabel?.text = """
                                     The both of the value are not equal
                                     """
                                     answer?.textLabel?.numberOfLines = 0
                                     answer?.textLabel?.lineBreakMode = .byWordWrapping
                                     answer?.textLabel?.textAlignment = .center
                                     answer?.textLabel?.textColor = UIColor.white
                                     return answer!
        } else if indexPath.row == 6 {
                               
            code = ElseTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ElseCodeTableViewCell
                                                             
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                              let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                              attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                              
                       attr.append(NSAttributedString(string: "lowNumber ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "3\n", attributes: [.foregroundColor: NumberSyntax]))
                      
                        attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                         
                                  attr.append(NSAttributedString(string: "highNumber ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "4\n", attributes: [.foregroundColor: NumberSyntax]))
            
             attr.append(NSAttributedString(string: "3.\n", attributes: [.foregroundColor: counterSyntax]))
              attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                      attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                                attr.append(NSAttributedString(string: "lowNumber ", attributes: [.foregroundColor: projectSyntax]))
            
                 attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
              attr.append(NSAttributedString(string: "highNumber ", attributes: [.foregroundColor: projectSyntax]))
            
                                attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                      
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
                      attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                          attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                           attr.append(NSAttributedString(string: "\"The both of the value are equal.\"", attributes: [.foregroundColor: StringSyntax]))
                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                     
                      attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                                 
                      attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                                      
                      
                      attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                     
                                                      attr.append(NSAttributedString(string: "\"The both of the value are not equal.\"", attributes: [.foregroundColor: StringSyntax]))
                                                      attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                            
                                 attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                 
                      
                               code?.textLabel?.attributedText = attr
            
                                     
                                     code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                     code?.textLabel?.numberOfLines = 0
                                     code?.textLabel?.lineBreakMode = .byWordWrapping
                                     code?.textLabel?.textAlignment = .left
                                                           
                                                             
                                     return code!
        } else if indexPath.row == 5 {
            
            titleCell = ElseTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ElseTitleTableViewCell
                      
                      titleCell?.textLabel?.text = "That you learned from if course, and create a else's statements to check if conditions is a false, then it will executing else's statements."
                        
                        titleCell?.textLabel?.numberOfLines = 0
                        titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                        titleCell?.textLabel?.textAlignment = .center
                        titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                        
                        return titleCell!
            
        } else if indexPath.row == 4 {
            answer = ElseTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ElseAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            false
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 3 {
            code = ElseTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ElseCodeTableViewCell
                                                 
               code?.textLabel?.font = setFont
                         
            // MARK: Nsattributedstring
                    let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                    attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                    
             attr.append(NSAttributedString(string: "check ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "\"Cloud\"\n", attributes: [.foregroundColor: StringSyntax]))
            
              attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                      attr.append(NSAttributedString(string: "check ", attributes: [.foregroundColor: projectSyntax]))
                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "\"This statements is execute true\"", attributes: [.foregroundColor: StringSyntax]))
                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                           
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                            
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "\"This statements is execute false\"", attributes: [.foregroundColor: StringSyntax]))
                                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                  
                       attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                       
            
                     code?.textLabel?.attributedText = attr
            
            
                         code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                         code?.textLabel?.numberOfLines = 0
                         code?.textLabel?.lineBreakMode = .byWordWrapping
                         code?.textLabel?.textAlignment = .left
                                               
                                                 
                         return code!
                     
        } else if indexPath.row == 2 {
            
            titleCell = ElseTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ElseTitleTableViewCell
            
            titleCell?.textLabel?.text = "Let's talk about if the course is over how does else work. You could notice this two string is not equal means it will result in second statements."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
            
        } else if indexPath.row == 1 {
            
            code = ElseTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ElseCodeTableViewCell
                                        
           code?.textLabel?.font = setFont
            
        // MARK: Nsattributedstring
                                    let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                        
                                    attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                         
                         attr.append(NSAttributedString(string: " condition ", attributes: [.backgroundColor: dynamicBackground]))
                         
                         attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "2.    ", attributes: [.foregroundColor: counterSyntax]))
                         
                          attr.append(NSAttributedString(string: " first statements ", attributes: [.backgroundColor: dynamicBackground]))
                 attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
                                    attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                
                attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                    attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
                                               attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))
            
                                                  attr.append(NSAttributedString(string: "4.    ", attributes: [.foregroundColor: counterSyntax]))
            
               attr.append(NSAttributedString(string: " second statements ", attributes: [.backgroundColor: dynamicBackground]))
            attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
                                               attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                           
                           attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
            
            
                         code?.textLabel?.attributedText = attr

            
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
            
        } else {
            
            titleCell = ElseTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ElseTitleTableViewCell
            
            titleCell?.textLabel?.text = "The else does not have the condition because this is always to collection true to execute the first statement. This else always to collection false to execute the second statements."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
            
        }
    }
    
    
}
