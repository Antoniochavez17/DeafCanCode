//
//  ClosuresViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit


class ClosuresViewController: UIViewController {

    @IBOutlet weak var ClosuresTableView: UITableView!
    @IBOutlet weak var ClosuresVideos: WKWebView!
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        ClosuresTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Closures"
        
        Label(IDCode: "kKL2MFEtg_A")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        ClosuresVideos.load(URLRequest(url: url!))

    }

}


extension ClosuresViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 23
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: ClosuresTitleTableViewCell!
        var code: ClosuresCodeTableViewCell!
        var answer: ClosuresAnswerTableViewCell!
        
        if indexPath.row == 22 {
            answer = ClosuresTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClosuresAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            I am going to Japan.
            I am going to U.S.
            I am going to Germany.
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            
            return answer!
        } else if indexPath.row == 21 {
            code = ClosuresTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClosuresCodeTableViewCell
                                        
          code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "travel", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "() (", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ") -> ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "Void ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
    
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: " return ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"I am going to ", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\($0)", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: ".\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
        
            attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
                attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "6. \n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
            
          attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
          
          attr.append(NSAttributedString(string: "traveling ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "travel", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "()\n", attributes: [.foregroundColor: PlainSyntax]))

           attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
             
            attr.append(NSAttributedString(string: "traveling", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"Japan\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
              
            attr.append(NSAttributedString(string: "traveling", attributes: [.foregroundColor: projectSyntax]))

                                            
                                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "\"U.S\"", attributes: [.foregroundColor: StringSyntax]))
                                  
                                 
                                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "traveling", attributes: [.foregroundColor: projectSyntax]))

                                            
                                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "\"Germany\"", attributes: [.foregroundColor: StringSyntax]))
                                  
                                 
                                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
              
            
            
             code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 20 {
            titleCell = ClosuresTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClosuresTitleTableViewCell
            
            titleCell?.textLabel?.text = "You can create more than one to calling the implementation to execute it, which it's familiar to subsequent parameter."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!

        } else if indexPath.row == 19 {
            answer = ClosuresTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClosuresAnswerTableViewCell
                                  answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                  answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                  answer?.textLabel?.text = """
                                  I'm going to Great Bend KS
                                  """
                                  answer?.textLabel?.numberOfLines = 0
                                  answer?.textLabel?.lineBreakMode = .byWordWrapping
                                  answer?.textLabel?.textAlignment = .center
                                  answer?.textLabel?.textColor = UIColor.white
                                  
                                  return answer!
        } else if indexPath.row == 18 {
            code = ClosuresTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClosuresCodeTableViewCell
                                        
            code?.textLabel?.font = setFont
                

            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "Home ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "() -> (", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: ") -> ", attributes: [.foregroundColor: PlainSyntax]))
 attr.append(NSAttributedString(string: "Void ", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                      
            attr.append(NSAttributedString(string: "2. " , attributes: [.foregroundColor: counterSyntax]))
              attr.append(NSAttributedString(string: " return", attributes: [.foregroundColor: KeyboardSyntax]))
            
              attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
          
                  attr.append(NSAttributedString(string: "3. " , attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "  print", attributes: [.foregroundColor: projectSyntax]))

                            
                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                  attr.append(NSAttributedString(string: "\"I'm going to ", attributes: [.foregroundColor: StringSyntax]))
                  
                  attr.append(NSAttributedString(string: "\\($0)", attributes: [.foregroundColor: PlainSyntax]))
        
                
                  attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                     
                   attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
attr.append(NSAttributedString(string: "4. " , attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "5. " , attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "6. \n" , attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "7. " , attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "\\\\ First Method\n" , attributes: [.foregroundColor: CommentSyntax]))
            
             attr.append(NSAttributedString(string: "8. " , attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "result ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

           
            attr.append(NSAttributedString(string: "Home", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "()\n", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "9. " , attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "result", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                        attr.append(NSAttributedString(string: "\"Great Bend KS\"", attributes: [.foregroundColor: StringSyntax]))

                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "10. " , attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "\\\\ Second Method\n" , attributes: [.foregroundColor: CommentSyntax]))
            
             attr.append(NSAttributedString(string: "11. " , attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "Home", attributes: [.foregroundColor: projectSyntax]))
                      attr.append(NSAttributedString(string: "()(", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "\"Great Bend KS\"", attributes: [.foregroundColor: StringSyntax]))

                                  attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

            
                       code?.textLabel?.attributedText = attr

            
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!

        } else if indexPath.row == 17 {
            titleCell = ClosuresTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClosuresTitleTableViewCell
            
            titleCell?.textLabel?.text = "The two methods to use for calling the closures. The first method is to allow the use of variable name-value behind the functions, which closures have used in it, then you can set the parameter in the parenthesis. The second method could likely allowable to use it otherwise,  couldn't recommend it."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 16 {
            answer = ClosuresTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClosuresAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       I am going to Great Bend at 60 miles per hour.
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       
                       return answer!
        } else if indexPath.row == 15 {
            code = ClosuresTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClosuresCodeTableViewCell
                                        
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                        attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                        
                                     attr.append(NSAttributedString(string: "Home", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                     attr.append(NSAttributedString(string: "(action: (", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                 attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            
                 attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                 attr.append(NSAttributedString(string: ") -> ", attributes: [.foregroundColor: PlainSyntax]))
                                     attr.append(NSAttributedString(string: "Strings", attributes: [.foregroundColor: projectSyntax]))
                                 
                                     attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                  
                                     attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                 
                                     attr.append(NSAttributedString(string: "action(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"Great Bend\"", attributes: [.foregroundColor: StringSyntax]))
                       attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "60", attributes: [.foregroundColor: NumberSyntax]))
                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
                       attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
                       attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                       
            
            attr.append(NSAttributedString(string: "Home ", attributes: [.foregroundColor: projectSyntax]))
                                          
                                          attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))
                                      
                                          
                                          
                                          attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                                          
                                          
                                          attr.append(NSAttributedString(string: "\"I am going to ", attributes: [.foregroundColor: StringSyntax]))
                                           attr.append(NSAttributedString(string: "\\($0) ", attributes: [.foregroundColor: PlainSyntax]))
                                              attr.append(NSAttributedString(string: "at ", attributes: [.foregroundColor: StringSyntax]))
            
             attr.append(NSAttributedString(string: "\\($1)", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: " miles pre hours\"\n", attributes: [.foregroundColor: StringSyntax]))
                                  attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                                  attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                
            code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 14 {
            titleCell = ClosuresTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClosuresTitleTableViewCell
            
            titleCell?.textLabel?.text = "The closures use the U.S dollar symbols to calling the arguments like arrays, dictionaries, and tuples that calling the values in the stored. Remember, it's always to calling the first arguments by starting with $0."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 13 {
            answer = ClosuresTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClosuresAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            I am leaving School.
            I am going to Great Bend
            I arrived home!
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            
            return answer!
        } else if indexPath.row == 12 {
            code = ClosuresTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClosuresCodeTableViewCell
                                        
            code?.textLabel?.font = setFont
                  
         
            // MARK: Nsattributedstring
                          let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                          attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                             
                          attr.append(NSAttributedString(string: "Home ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                          attr.append(NSAttributedString(string: "(action: (", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: ") -> ", attributes: [.foregroundColor: PlainSyntax]))
                          attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                      
                          attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))
                      
                       
                          attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      
                          attr.append(NSAttributedString(string: "action(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"Great Bend\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "// Frist Method \n", attributes: [.foregroundColor: CommentSyntax]))
            
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "Home ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: " { place -> ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "String ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "in \n", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "return ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "\"I am going to ", attributes: [.foregroundColor: StringSyntax]))
             attr.append(NSAttributedString(string: "\\(place)", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"\n", attributes: [.foregroundColor: StringSyntax]))
            
             attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
            
            
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
                     
                     attr.append(NSAttributedString(string: "// Second Method \n", attributes: [.foregroundColor: CommentSyntax]))
                     
                     attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
                     
                     attr.append(NSAttributedString(string: "Home ", attributes: [.foregroundColor: projectSyntax]))
                     
                     attr.append(NSAttributedString(string: "{ place ", attributes: [.foregroundColor: PlainSyntax]))
                 
                     
                     attr.append(NSAttributedString(string: "in \n", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: "12. ", attributes: [.foregroundColor: counterSyntax]))
             
                       attr.append(NSAttributedString(string: "return ", attributes: [.foregroundColor: KeyboardSyntax]))
                     attr.append(NSAttributedString(string: "\"I am going to ", attributes: [.foregroundColor: StringSyntax]))
                      attr.append(NSAttributedString(string: "\\(place)", attributes: [.foregroundColor: PlainSyntax]))
                         attr.append(NSAttributedString(string: "\"\n", attributes: [.foregroundColor: StringSyntax]))
             attr.append(NSAttributedString(string: "13. ", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                     
            
            attr.append(NSAttributedString(string: "14. ", attributes: [.foregroundColor: counterSyntax]))
                               
                               attr.append(NSAttributedString(string: "// Third Method \n", attributes: [.foregroundColor: CommentSyntax]))
                               
                               attr.append(NSAttributedString(string: "15. ", attributes: [.foregroundColor: counterSyntax]))
                               
                               attr.append(NSAttributedString(string: "Home ", attributes: [.foregroundColor: projectSyntax]))
                               
                               attr.append(NSAttributedString(string: "{ place ", attributes: [.foregroundColor: PlainSyntax]))
                           
                               
                               attr.append(NSAttributedString(string: "in \n", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "16. ", attributes: [.foregroundColor: counterSyntax]))
                            
                               
                               attr.append(NSAttributedString(string: "\"I am going to ", attributes: [.foregroundColor: StringSyntax]))
                                attr.append(NSAttributedString(string: "\\(place)", attributes: [.foregroundColor: PlainSyntax]))
                                   attr.append(NSAttributedString(string: "\"\n", attributes: [.foregroundColor: StringSyntax]))
                       attr.append(NSAttributedString(string: "17. ", attributes: [.foregroundColor: counterSyntax]))
                       attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
            attr.append(NSAttributedString(string: "18. ", attributes: [.foregroundColor: counterSyntax]))
                               
                               attr.append(NSAttributedString(string: "// Fourth Method \n", attributes: [.foregroundColor: CommentSyntax]))
                               
                               attr.append(NSAttributedString(string: "19. ", attributes: [.foregroundColor: counterSyntax]))
                               
                               attr.append(NSAttributedString(string: "Home ", attributes: [.foregroundColor: projectSyntax]))
                               
                               attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))
                           
                               
                               
                               attr.append(NSAttributedString(string: "20. ", attributes: [.foregroundColor: counterSyntax]))
                               
                               
                               attr.append(NSAttributedString(string: "\"I am going to ", attributes: [.foregroundColor: StringSyntax]))
                                attr.append(NSAttributedString(string: "\\($0)", attributes: [.foregroundColor: PlainSyntax]))
                                   attr.append(NSAttributedString(string: "\"\n", attributes: [.foregroundColor: StringSyntax]))
                       attr.append(NSAttributedString(string: "21. ", attributes: [.foregroundColor: counterSyntax]))
                       attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
            
            code?.textLabel?.attributedText = attr
            
           
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 11 {
            titleCell = ClosuresTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClosuresTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "Those methods that closures allow you to use to call the argument. The function has uploaded to the closure's statements. The first method is an original closures in the Swift.The second methods allow you to call the function without return type needs. The third methods allow you to call the function without return keyboard needs. The forth methods allow you to call the function without argument needs but set the U.S dollars symbols to calling first arguments. Next character will example you about how do U.S dollars work in the closures."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 10 {
            answer = ClosuresTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClosuresAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            I am leaving School.
            Driving*
            I arrived home!
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
            
        } else if indexPath.row == 9 {
            
            code = ClosuresTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClosuresCodeTableViewCell
                                        
            code?.textLabel?.font = setFont
                
            
            // MARK: Nsattributedstring
                                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                        
                                        attr.append(NSAttributedString(string: "driving ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                              
                                
                              attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                  
                         attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                        attr.append(NSAttributedString(string: "\"Driving*\"", attributes: [.foregroundColor: StringSyntax]))
                        
                       
                             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
                  attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "Home", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
             attr.append(NSAttributedString(string: "( action: () -> ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "Void", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"I am leaving school.\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "action", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "()\n", attributes: [.foregroundColor: PlainSyntax]))
                   
             attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"I arrived home!\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "9.\n", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "Home", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "(action: ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "driving ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 8 {
            titleCell = ClosuresTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClosuresTitleTableViewCell
                      
                      titleCell?.textLabel?.text = "The closures have created called driving. If you don't want to bother the statements, then set a void in which means never set tuples like empty in the arguments. Then upload the closure in the parameter to execute, and you will see the second line of the statements has show driving* in the console."
                        
                        titleCell?.textLabel?.numberOfLines = 0
                        titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                        titleCell?.textLabel?.textAlignment = .center
                        titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                        
                        return titleCell!
        } else if indexPath.row == 7 {
            
            answer = ClosuresTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClosuresAnswerTableViewCell
                     answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                     answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                     answer?.textLabel?.text = """
                     They're a Great Bend High School students
                     """
                     answer?.textLabel?.numberOfLines = 0
                     answer?.textLabel?.lineBreakMode = .byWordWrapping
                     answer?.textLabel?.textAlignment = .center
                     answer?.textLabel?.textColor = UIColor.white
                     return answer!
            
        } else if indexPath.row == 6 {
            code = ClosuresTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClosuresCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                               let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                               attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "students ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     
                     attr.append(NSAttributedString(string: "{ (place: ", attributes: [.foregroundColor: PlainSyntax]))
                     
            attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: " in\n", attributes: [.foregroundColor: KeyboardSyntax]))
                           
                           
            
                    
                     attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                        

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                              
                                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                    attr.append(NSAttributedString(string: "\"They're a ", attributes: [.foregroundColor: StringSyntax]))
                                    
                                    attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                 
                                      attr.append(NSAttributedString(string: "place", attributes: [.foregroundColor: projectSyntax]))

                                             attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                                    attr.append(NSAttributedString(string: "students\"", attributes: [.foregroundColor: StringSyntax]))
                                                       
                                     attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

     attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
                 attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
            
                 attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
                 attr.append(NSAttributedString(string: "students", attributes: [.foregroundColor: projectSyntax]))
                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "\"Great Bend High School\"", attributes: [.foregroundColor: StringSyntax]))
              attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            

                                code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
            
        } else if indexPath.row == 5 {
            
            titleCell = ClosuresTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClosuresTitleTableViewCell
            
            titleCell?.textLabel?.text = "The closure doesn't need an external parameter to called by the parameter. However, The parameter has created by use tuples. Remembers, The part of the closure is very familiar to functions. You can use the arguments into the statement to set the calling by the parameters as functions does. The in keyboard is allows the arguments to access the statement."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
            
        } else if indexPath.row == 4 {
            
          answer = ClosuresTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ClosuresAnswerTableViewCell
          answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
          answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
          answer?.textLabel?.text = """
          Cora
          Koa
          Saul
          """
          answer?.textLabel?.numberOfLines = 0
          answer?.textLabel?.lineBreakMode = .byWordWrapping
          answer?.textLabel?.textAlignment = .center
          answer?.textLabel?.textColor = UIColor.white
          return answer!
            
        } else if indexPath.row == 3 {
            code = ClosuresTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClosuresCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "students ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"Cora\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                      
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                   attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                                        
                               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              attr.append(NSAttributedString(string: "\"Koa\"", attributes: [.foregroundColor: StringSyntax]))
                              
                             
                                   attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                   attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                                        
                               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              attr.append(NSAttributedString(string: "\"Saul\"", attributes: [.foregroundColor: StringSyntax]))
                              
                             
                                   attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                      
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                   attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))

                       code?.textLabel?.attributedText = attr
        
            
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!

        } else if indexPath.row == 2 {
            titleCell = ClosuresTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClosuresTitleTableViewCell
                      
                      titleCell?.textLabel?.text = "The closures are very familiar to variables including in the functions. Remembers, Constant is always to prevent the values."
                        
                        titleCell?.textLabel?.numberOfLines = 0
                        titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                        titleCell?.textLabel?.textAlignment = .center
                        titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                        
                        return titleCell!
        } else if indexPath.row == 1 {
            code = ClosuresTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ClosuresCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                          
                                      attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                           
                           attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                          
                           attr.append(NSAttributedString(string: " { ( ", attributes: [.foregroundColor: PlainSyntax]))
                  
                  attr.append(NSAttributedString(string: " argument ", attributes: [.backgroundColor: dynamicBackground]))
                  
                    attr.append(NSAttributedString(string: " ) -> ", attributes: [.foregroundColor: PlainSyntax]))
                  
              attr.append(NSAttributedString(string: " return type ", attributes: [.backgroundColor: dynamicBackground]))
            
                 attr.append(NSAttributedString(string: " in \n", attributes: [.foregroundColor: KeyboardSyntax]))
            
                   attr.append(NSAttributedString(string: "2.    ", attributes: [.foregroundColor: counterSyntax]))
                           
                            attr.append(NSAttributedString(string: " statements ", attributes: [.backgroundColor: dynamicBackground]))
                   attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: CodeBackground]))
                                      attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                  
                  attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
                                      attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                           
                                attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                              
                           attr.append(NSAttributedString(string: "( ", attributes: [.foregroundColor: PlainSyntax]))
                  
                  attr.append(NSAttributedString(string: " parameter ", attributes: [.backgroundColor: dynamicBackground]))
                  
                    attr.append(NSAttributedString(string: " ) ", attributes: [.foregroundColor: PlainSyntax]))
                  
                                                          
                           code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!

        } else {
            titleCell = ClosuresTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ClosuresTitleTableViewCell
                      
                      titleCell?.textLabel?.text = "The Closures are very familiar to variables to inducted the functions. Remember, using the variable if you want to control the values, which stored in the statement otherwise, using the constant if you want these value to prevent from an accident."
                        
                        titleCell?.textLabel?.numberOfLines = 0
                        titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                        titleCell?.textLabel?.textAlignment = .center
                        titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                        
                        return titleCell!
        }
    }
    
     
    
}
