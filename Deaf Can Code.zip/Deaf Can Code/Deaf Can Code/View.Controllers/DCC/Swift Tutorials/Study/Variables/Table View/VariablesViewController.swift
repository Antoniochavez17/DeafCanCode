//
//  VariablesViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/1/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class VariablesViewController: UIViewController {

    @IBOutlet weak var VariableVideo: WKWebView!
    @IBOutlet weak var VariableTableView: UITableView!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        VariableTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Variables"
        
        Label(IDCode: "9P1qd22Dkzc")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        VariableVideo.load(URLRequest(url: url!))

    }

}

extension VariablesViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        17
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: VariableTitleTableViewCell!
        var code: VariableCodeTableViewCell!
        var answer: VariableAnswerTableViewCell!
        
        if indexPath.row == 16 {
            answer = VariableTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? VariableAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            false
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 15 {
            code = VariableTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? VariableCodeTableViewCell
                                    
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                                                     
                                                                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                          
                                                    attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                    
                                                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                              
                                                    attr.append(NSAttributedString(string: "\"Welcome\"\n", attributes: [.foregroundColor: StringSyntax]))

                                                 attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                                                 attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                      
                                                attr.append(NSAttributedString(string: "combineGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                
                                                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                        
                                                attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: projectSyntax]))
                                                     
                                                attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: projectSyntax]))
                                                
                                                
                                                attr.append(NSAttributedString(string: "\"We're glad you're here!\"\n", attributes: [.foregroundColor: StringSyntax]))
                                            
                                            attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
                                                         attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                                        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                              
                                                        attr.append(NSAttributedString(string: "leaveGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                        
                                                         attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                                
                                                        attr.append(NSAttributedString(string: "greeting\n", attributes: [.foregroundColor: projectSyntax]))
                                            
                                             attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                                            
                                            attr.append(NSAttributedString(string: "leaveGreeting ", attributes: [.foregroundColor: projectSyntax]))
                                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                            attr.append(NSAttributedString(string: "\"Have a nice time!\"\n", attributes: [.foregroundColor: StringSyntax]))
                      
                 attr.append(NSAttributedString(string: "7.\n", attributes: [.foregroundColor: counterSyntax]))
                       
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "check ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "leaveGreeting", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: " == ", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "greeting", attributes: [.foregroundColor: projectSyntax]))
                      code?.textLabel?.attributedText = attr
            
                                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                              code?.textLabel?.numberOfLines = 0
                                              code?.textLabel?.lineBreakMode = .byWordWrapping
                                              code?.textLabel?.textAlignment = .left
                                  
                                    
                                    return code!
        } else if indexPath.row == 14 {
            titleCell = VariableTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? VariableTitleTableViewCell
                       
                         titleCell?.textLabel?.text = "The three things is when you create the double assignments operator to allows you to calling the name-values to check if first values is equal to the new values."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 13 {
            answer = VariableTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? VariableAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Have a nice time!
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 12 {
            code = VariableTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? VariableCodeTableViewCell
                                    
                code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                     
                                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                          
                    attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    
                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                              
                    attr.append(NSAttributedString(string: "\"Welcome\"\n", attributes: [.foregroundColor: StringSyntax]))

                 attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                 attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                attr.append(NSAttributedString(string: "combineGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                        
                attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: projectSyntax]))
                     
                attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: projectSyntax]))
                
                
                attr.append(NSAttributedString(string: "\"We're glad you're here!\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
                         attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                              
                        attr.append(NSAttributedString(string: "leaveGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                        
                         attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                
                        attr.append(NSAttributedString(string: "greeting\n", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "leaveGreeting ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"Have a nice time!\"", attributes: [.foregroundColor: StringSyntax]))
                                     
                                 
                      code?.textLabel?.attributedText = attr
            
                                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                              code?.textLabel?.numberOfLines = 0
                                              code?.textLabel?.lineBreakMode = .byWordWrapping
                                              code?.textLabel?.textAlignment = .left
                                  
                                    
                                    return code!
        } else if indexPath.row == 11 {
            titleCell = VariableTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? VariableTitleTableViewCell
            
              titleCell?.textLabel?.text = "The second things is when you created the assignment operator is allow you to calling the name-values to change the values from the frist values."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!

        } else if indexPath.row == 10 {
            answer = VariableTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? VariableAnswerTableViewCell
                                               answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                               answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       Welcome! We're glad
                       you're here!
                       """
                                               answer?.textLabel?.numberOfLines = 0
                                               answer?.textLabel?.lineBreakMode = .byWordWrapping
                                               answer?.textLabel?.textAlignment = .center
                                               answer?.textLabel?.textColor = UIColor.white
                                               return answer!
        } else if indexPath.row == 9 {
            code = VariableTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? VariableCodeTableViewCell
                                    
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                     
                                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                          
                attr.append(NSAttributedString(string: "\"Welcome\"\n", attributes: [.foregroundColor: StringSyntax]))

             attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                  
            attr.append(NSAttributedString(string: "combineGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                    
            attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: projectSyntax]))
                 
            attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: projectSyntax]))
            
            
            attr.append(NSAttributedString(string: "\"We're glad you're here!\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                      code?.textLabel?.attributedText = attr
            
                                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                              code?.textLabel?.numberOfLines = 0
                                              code?.textLabel?.lineBreakMode = .byWordWrapping
                                              code?.textLabel?.textAlignment = .left
                                  
                                    
                                    return code!
        } else if indexPath.row == 8 {
            titleCell = VariableTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? VariableTitleTableViewCell
            
              titleCell?.textLabel?.text = "I am showing you the three things about the variables that will be allowed to use those operators. You may noticed this greeting becomes a highlight from which the variable's name-values has calling is called type inference. The first thing is when you text this addition operator between two value is called the combine."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 7 {
            answer = VariableTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? VariableAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Happy Birthday!
            """
            
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 6 {
            code = VariableTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? VariableCodeTableViewCell
                         
                 code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                     
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
            attr.append(NSAttributedString(string: "\"Happy Birthday!\"", attributes: [.foregroundColor: StringSyntax]))

                
                                 
                      code?.textLabel?.attributedText = attr
            
                                   code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                   code?.textLabel?.numberOfLines = 0
                                   code?.textLabel?.lineBreakMode = .byWordWrapping
                                   code?.textLabel?.textAlignment = .left
                       
                         
                         return code!
        } else if indexPath.row == 5 {
            titleCell = VariableTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? VariableTitleTableViewCell
            
              titleCell?.textLabel?.text = "When you create new variables is called greeting to assignments the values which name-values actually means like a values collapse to one means for this name-values."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 4 {
            answer = VariableTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? VariableAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Tim Cook
            Craig Federighi
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 3 {
            code = VariableTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? VariableCodeTableViewCell
                         
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                     
                                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                attr.append(NSAttributedString(string: "CEO_Apple ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"Tim Cook\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                          attr.append(NSAttributedString(string: "softwareEnginner ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      
                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
               attr.append(NSAttributedString(string: "\"Craig Federighi\"", attributes: [.foregroundColor: StringSyntax]))
                                     
                                 
                      code?.textLabel?.attributedText = attr
            
            
                                   code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                   code?.textLabel?.numberOfLines = 0
                                   code?.textLabel?.lineBreakMode = .byWordWrapping
                                   code?.textLabel?.textAlignment = .left
                       
                         
                         return code!
                   } else if indexPath.row == 2 {
                      titleCell = VariableTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? VariableTitleTableViewCell
                       
                         titleCell?.textLabel?.text = "You will see two name-value have different. If you text whitespace, it will cause \"Found an unexpected second identifier in constant declaration; is there an accidental break?\". Now, This whitespace will instead to underscore could stand for whitespace."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 1 {
            code = VariableTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? VariableCodeTableViewCell
                                    
                       code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                           
                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
            
            attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: " value ", attributes: [.backgroundColor: dynamicBackground]))
                       
            code?.textLabel?.attributedText = attr
            
                                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                              code?.textLabel?.numberOfLines = 0
                                              code?.textLabel?.lineBreakMode = .byWordWrapping
                                              code?.textLabel?.textAlignment = .left
                                  
                                    
                                    return code!
        } else {
            titleCell = VariableTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? VariableTitleTableViewCell
            
              titleCell?.textLabel?.text = "The Variables and Constants is a difference in Swift. Let's start to learn about Variables. The Variables allow you to combine, change, check if the two value matches, or not. That variables were collapse to var. That name value means like you have texted a lot of the things for that value to collapse to one means in name value."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        }
    }
    
    
    
}
