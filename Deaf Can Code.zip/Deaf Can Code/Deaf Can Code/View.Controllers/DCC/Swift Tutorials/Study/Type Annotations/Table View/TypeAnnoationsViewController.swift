//
//  TypeAnnoationsViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class TypeAnnoationsViewController: UIViewController {

    @IBOutlet weak var TATableView: UITableView!
    @IBOutlet weak var TAVideos: WKWebView!
    
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        TATableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Type Annoations"
        
        Label(IDCode: "x-6r3eY5ZIY")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        TAVideos.load(URLRequest(url: url!))

    }

}


extension TypeAnnoationsViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 16
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: TATitleTableViewCell!
        var code: TACodeTableViewCell!
        
        if indexPath.row == 15 {
            code = TATableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TACodeTableViewCell
             
            code?.textLabel?.font = setFont
                                         
            // MARK: Nsattributedstring
                         let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                         attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                         
                         attr.append(NSAttributedString(string: "dic", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                         attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                         attr.append(NSAttributedString(string: "Dictionary ", attributes: [.foregroundColor: projectSyntax]))

               
               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

               
               attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))

            
            attr.append(NSAttributedString(string: ":", attributes: [.foregroundColor: PlainSyntax]))

            
               attr.append(NSAttributedString(string: "\"Dict1\"", attributes: [.foregroundColor: StringSyntax]))
               
               attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))

            
            attr.append(NSAttributedString(string: ":", attributes: [.foregroundColor: PlainSyntax]))

            
               
               attr.append(NSAttributedString(string: "\"Dict2\"", attributes: [.foregroundColor: StringSyntax]))

               
               attr.append(NSAttributedString(string: "] ", attributes: [.foregroundColor: PlainSyntax]))

                          code?.textLabel?.attributedText = attr
            
                                         code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                         code?.textLabel?.numberOfLines = 0
                                         code?.textLabel?.lineBreakMode = .byWordWrapping
                                         code?.textLabel?.textAlignment = .left
                                                               
                                                                 
                                         return code!
        } else if indexPath.row == 14 {
            titleCell = TATableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TATitleTableViewCell
                              
                              titleCell?.textLabel?.text = "If you want to use those dictionary on the type annotation, then an example of the code in this type annotation."
                                
                                titleCell?.textLabel?.numberOfLines = 0
                                titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                titleCell?.textLabel?.textAlignment = .center
                                titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                
                                return titleCell!
        } else if indexPath.row == 13 {
                   code = TATableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TACodeTableViewCell
                                                                        
                   code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "arr", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "Array ", attributes: [.foregroundColor: projectSyntax]))

            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"Array1\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "\"Array2\"", attributes: [.foregroundColor: StringSyntax]))

            
            attr.append(NSAttributedString(string: "] ", attributes: [.foregroundColor: PlainSyntax]))

                       code?.textLabel?.attributedText = attr
                                                
                                                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                code?.textLabel?.numberOfLines = 0
                                                code?.textLabel?.lineBreakMode = .byWordWrapping
                                                code?.textLabel?.textAlignment = .left
                                                                      
                                                                        
                                                return code!
        }  else if indexPath.row == 12 {
                   titleCell = TATableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TATitleTableViewCell
                   
                   titleCell?.textLabel?.text = "If you want to use those Arrays on the type annotation, then an example of the code in this type annotation."
                     
                     titleCell?.textLabel?.numberOfLines = 0
                     titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                     titleCell?.textLabel?.textAlignment = .center
                     titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                     
                     return titleCell!
        } else if indexPath.row == 11 {
                          code = TATableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TACodeTableViewCell
                                                                               
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "str", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "String ", attributes: [.foregroundColor: projectSyntax]))

            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))

                       code?.textLabel?.attributedText = attr
            
                                                       code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                       code?.textLabel?.numberOfLines = 0
                                                       code?.textLabel?.lineBreakMode = .byWordWrapping
                                                       code?.textLabel?.textAlignment = .left
                                                                             
                                                                               
                                                       return code!
        }  else if indexPath.row == 10 {
                          titleCell = TATableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TATitleTableViewCell
                                            
                                            titleCell?.textLabel?.text = "If you want to use those booleans on the type annotation, then an example of the code in this type annotation."
                                              
                                              titleCell?.textLabel?.numberOfLines = 0
                                              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                              titleCell?.textLabel?.textAlignment = .center
                                              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                              
                                              return titleCell!
        } else if indexPath.row == 9 {
            code = TATableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TACodeTableViewCell
                                                                 
             code?.textLabel?.font = setFont
                                         
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "dou", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "Double ", attributes: [.foregroundColor: projectSyntax]))

            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: " 25.5 ", attributes: [.foregroundColor: NumberSyntax]))

                       code?.textLabel?.attributedText = attr
            
                                         code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                         code?.textLabel?.numberOfLines = 0
                                         code?.textLabel?.lineBreakMode = .byWordWrapping
                                         code?.textLabel?.textAlignment = .left
                                                               
                                                                 
                                         return code!
        } else if indexPath.row == 8 {
                   titleCell = TATableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TATitleTableViewCell
                   
                   titleCell?.textLabel?.text = "If you want to use those double on the type annotation, then an example of the code in this type annotation."
                     
                     titleCell?.textLabel?.numberOfLines = 0
                     titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                     titleCell?.textLabel?.textAlignment = .center
                     titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                     
                     return titleCell!
        }  else if indexPath.row == 7 {
                  
            code = TATableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TACodeTableViewCell
                                                                        
             
            code?.textLabel?.font = setFont
                                                
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "int", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))

            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: " 25 ", attributes: [.foregroundColor: NumberSyntax]))

                       code?.textLabel?.attributedText = attr
            
                                                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                code?.textLabel?.numberOfLines = 0
                                                code?.textLabel?.lineBreakMode = .byWordWrapping
                                                code?.textLabel?.textAlignment = .left
                                                                      
                                                                        
                                                return code!
        } else if indexPath.row == 6 {
                          titleCell = TATableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TATitleTableViewCell
                          
                          titleCell?.textLabel?.text = "If you want to use those integers on the type annotation, then an example of the code in this type annotation."
                            
                            titleCell?.textLabel?.numberOfLines = 0
                            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                            titleCell?.textLabel?.textAlignment = .center
                            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                            
                            return titleCell!
        }  else if indexPath.row == 5 {
                          code = TATableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TACodeTableViewCell
                                                                               
                      code?.textLabel?.font = setFont
            
            
            // MARK: Nsattributedstring
                                            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                            
                                            attr.append(NSAttributedString(string: "str", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                            attr.append(NSAttributedString(string: " String ", attributes: [.foregroundColor: projectSyntax]))

                                  
                                  attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))

                                  
                                  attr.append(NSAttributedString(string: " \"String\" ", attributes: [.foregroundColor: StringSyntax]))

                                             code?.textLabel?.attributedText = attr
                                                       
                                                       code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                       code?.textLabel?.numberOfLines = 0
                                                       code?.textLabel?.lineBreakMode = .byWordWrapping
                                                       code?.textLabel?.textAlignment = .left
                                                                             
                                                                               
                                                       return code!
        } else if indexPath.row == 4 {
            titleCell = TATableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TATitleTableViewCell
                                                       
                                                       titleCell?.textLabel?.text = "If you want to use those strings on the type annotation, then an example of the code in this type annotation."
                                                         
                                                         titleCell?.textLabel?.numberOfLines = 0
                                                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                                         titleCell?.textLabel?.textAlignment = .center
                                                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                                         
                                                         return titleCell!
        } else if indexPath.row == 3 {
                   code = TATableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TACodeTableViewCell
                                                                        
                  code?.textLabel?.font = setFont
            
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                 attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                 attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                                 attr.append(NSAttributedString(string: " type ", attributes: [.backgroundColor: dynamicBackground]))

                       
                       attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))

                       
                       attr.append(NSAttributedString(string: " value ", attributes: [.backgroundColor: dynamicBackground]))

                                  code?.textLabel?.attributedText = attr

                                                
                                                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                code?.textLabel?.numberOfLines = 0
                                                code?.textLabel?.lineBreakMode = .byWordWrapping
                                                code?.textLabel?.textAlignment = .left
                                                                      
                                                                        
                                                return code!
        }  else if indexPath.row == 2 {
                   titleCell = TATableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TATitleTableViewCell
                                            
                                            titleCell?.textLabel?.text = "You can custom Type in constants, but if you change variables to constant, then constant may not get change, combine, and add because it was not allowed."
                                              
                                              titleCell?.textLabel?.numberOfLines = 0
                                              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                              titleCell?.textLabel?.textAlignment = .center
                                              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                              
                                              return titleCell!
        } else if indexPath.row == 1 {
                        
            code = TATableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TACodeTableViewCell
                                                      
                   code?.textLabel?.font = setFont
                              
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: " type ", attributes: [.backgroundColor: dynamicBackground]))

            
            attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: " value ", attributes: [.backgroundColor: dynamicBackground]))

                       code?.textLabel?.attributedText = attr

                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                              code?.textLabel?.numberOfLines = 0
                              code?.textLabel?.lineBreakMode = .byWordWrapping
                              code?.textLabel?.textAlignment = .left
                                                    
                                                      
                              return code!
        }  else {
                          titleCell = TATableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TATitleTableViewCell
                          
                          titleCell?.textLabel?.text = "You can custom type like String, Int, Double, Array, Dictionary, different types. But you have to focus on text on the value what types are request. For example, String means only text sentences with quotes."
                            
                            titleCell?.textLabel?.numberOfLines = 0
                            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                            titleCell?.textLabel?.textAlignment = .center
                            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                            
                            return titleCell!
        }
        
    }
    
    
}
