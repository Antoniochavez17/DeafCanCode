//
//  LoopsViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class LoopsViewController: UIViewController {

    @IBOutlet weak var LoopsTableView: UITableView!
    @IBOutlet weak var LoopsVideos: WKWebView!
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        LoopsTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Loops"
        
        Label(IDCode: "ryoiCOMCQXs")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        LoopsVideos.load(URLRequest(url: url!))

    }
    
}

extension LoopsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 59
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: LoopsTitleTableViewCell!
        var code: LoopsCodeTableViewCell!
        var answer: LoopsAnswerTableViewCell!
        
        if indexPath.row == 58 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            1 2 3 ... 18 19 20 End
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 57 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                                   
                      code?.textLabel?.font = setFont
            
            
                      // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "// Repeat Loop\n", attributes: [.foregroundColor: CommentSyntax]))
            
            
                                          
                      attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      
            
                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "0\n", attributes: [.foregroundColor: NumberSyntax]))

                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                
                                attr.append(NSAttributedString(string: "repeat ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                               attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                             attr.append(NSAttributedString(string: " num", attributes: [.foregroundColor: projectSyntax]))

                                                        
                                               attr.append(NSAttributedString(string: " += ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                     
                                                attr.append(NSAttributedString(string: "1\n", attributes: [.foregroundColor: NumberSyntax]))

                                            
            
                        attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                      attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                                                 
                                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              
                                         attr.append(NSAttributedString(string: "num", attributes: [.foregroundColor: projectSyntax]))

                                     
                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                        attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      attr.append(NSAttributedString(string: " sleep", attributes: [.foregroundColor: projectSyntax]))

                                                          
                                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                                  attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))

                                                
                                                                   
                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                        attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      
                         attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))

                        attr.append(NSAttributedString(string: " while", attributes: [.foregroundColor: KeyboardSyntax]))
                                             
                       
                       attr.append(NSAttributedString(string: " num", attributes: [.foregroundColor: projectSyntax]))
                       
                            attr.append(NSAttributedString(string: " < ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                          attr.append(NSAttributedString(string: "20\n", attributes: [.foregroundColor: NumberSyntax]))
                       
                        attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      
                      attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                          
                                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                
                                                  attr.append(NSAttributedString(string: "End", attributes: [.foregroundColor: StringSyntax]))

                                                attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                                   
                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
                                
                                 code?.textLabel?.attributedText = attr
            
                           
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        }else if indexPath.row == 56 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       1 2 3 ... 18 19 20 End
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 55 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
                
                   
                      // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "// While loops\n", attributes: [.foregroundColor: CommentSyntax]))
            
            
                                          
                      attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      
            
                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "0\n", attributes: [.foregroundColor: NumberSyntax]))

                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                
                                attr.append(NSAttributedString(string: "while", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: " num", attributes: [.foregroundColor: projectSyntax]))
                      
                           attr.append(NSAttributedString(string: " < ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                         attr.append(NSAttributedString(string: "20 ", attributes: [.foregroundColor: NumberSyntax]))
                      
                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                               attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                            
                      attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                                                 
                                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                              
                                         attr.append(NSAttributedString(string: "num", attributes: [.foregroundColor: projectSyntax]))

                                     
                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                        attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      attr.append(NSAttributedString(string: " sleep", attributes: [.foregroundColor: projectSyntax]))

                                                          
                                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                                  attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))

                                                
                                                                   
                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                        attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      
                         attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                      
                        attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      
                      attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                          
                                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                
                                                  attr.append(NSAttributedString(string: "End", attributes: [.foregroundColor: StringSyntax]))

                                                attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                                   
                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
                                
                                 code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 54 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            1 2 3 ... 18 19 20 End
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 53 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "// For-in loops\n", attributes: [.foregroundColor: CommentSyntax]))
                                
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
                      attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "count ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            
            attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
            
                 attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: PlainSyntax]))
               attr.append(NSAttributedString(string: "20 ", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

              attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                                       
                              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                    
                               attr.append(NSAttributedString(string: "count", attributes: [.foregroundColor: projectSyntax]))

                           
                              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

              attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: " sleep", attributes: [.foregroundColor: projectSyntax]))

                                                
                                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                        attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))

                                      
                                                         
                                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            
               attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                
                                       attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                      attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                      
                                        attr.append(NSAttributedString(string: "End", attributes: [.foregroundColor: StringSyntax]))

                                      attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                         
                                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
  
                      
                       code?.textLabel?.attributedText = attr

                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 52 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "I want to show you a final of the for-in, while, repeat-while loops which results in an end at 20 from 0 in the duration loop. Let start with the for-in unit repeat-while loops."
            
            titleCell?.textLabel?.font = UIFont.systemFont(ofSize: 17)
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 51 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
            titleCell?.textLabel?.font = UIFont.systemFont(ofSize: 20)
                
            titleCell?.textLabel?.text = "Final Loops"
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .left
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 50 {
                   answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
                   answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                   answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                   answer?.textLabel?.text = """
                   Jump Successful
                   You fell!
                   """
                   answer?.textLabel?.numberOfLines = 0
                   answer?.textLabel?.lineBreakMode = .byWordWrapping
                   answer?.textLabel?.textAlignment = .center
                   answer?.textLabel?.textColor = UIColor.white
                   return answer!
            
               } else if indexPath.row == 49 {
            
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
         code?.textLabel?.font = setFont
            
            

            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "jumpNumber ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "0\n", attributes: [.foregroundColor: NumberSyntax]))

            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "repeat ", attributes: [.foregroundColor: KeyboardSyntax]))

            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: " jumpNumber", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: " += ", attributes: [.foregroundColor: OtherDecluarationSyntax]))

            attr.append(NSAttributedString(string: "1\n", attributes: [.foregroundColor: NumberSyntax]))

            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))


            attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                      
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            
              attr.append(NSAttributedString(string: "Jump Successful!", attributes: [.foregroundColor: StringSyntax]))

            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                               
             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: " jumpNumber", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: " -= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))

            attr.append(NSAttributedString(string: "1\n", attributes: [.foregroundColor: NumberSyntax]))
            
            
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "while ", attributes: [.foregroundColor: KeyboardSyntax]))

            attr.append(NSAttributedString(string: " 0", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: " <", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                       
            attr.append(NSAttributedString(string: " jumpNumber\n", attributes: [.foregroundColor: projectSyntax]))

            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                               
                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                     
                     
                       attr.append(NSAttributedString(string: "You Fell!", attributes: [.foregroundColor: StringSyntax]))

                     attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                        
                      attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                      
                       code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!

        } else if indexPath.row == 48 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "When you add a new point by addition assignment for the next jump will results in \"Jump Successful\" by printing. However, while's condition will results \"You Fell!\", because It was 0 is start return to the jump's value."
                       
                       titleCell?.textLabel?.font = UIFont.systemFont(ofSize: 17)
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 47 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
            titleCell?.textLabel?.font = UIFont.systemFont(ofSize: 20)
                
            titleCell?.textLabel?.text = "Repeat-While Loops"
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .left
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 46 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            1
            2
            3
            4
            5
            6
            7
            8
            9
            10
            11
            12
            13
            14
            15
            16
            17
            18
            19
            20
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 45 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                       attr.append(NSAttributedString(string: "0\n", attributes: [.foregroundColor: NumberSyntax]))

                       attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                       attr.append(NSAttributedString(string: "while ", attributes: [.foregroundColor: KeyboardSyntax]))
                             
            attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "20 ", attributes: [.foregroundColor: NumberSyntax]))
            
                       attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                       
                                          
                                         
                                            attr.append(NSAttributedString(string: " num", attributes: [.foregroundColor: projectSyntax]))

                                          
                                           attr.append(NSAttributedString(string: " += ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: " 1\n", attributes: [.foregroundColor: NumberSyntax]))
                       
            
                                 attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                    attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                                            
                                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                  
                                 
                                    attr.append(NSAttributedString(string: "num", attributes: [.foregroundColor: projectSyntax]))

                                  
                                   attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))

                       attr.append(NSAttributedString(string: " sleep", attributes: [.foregroundColor: projectSyntax]))

                          attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "5", attributes: [.foregroundColor: NumberSyntax]))
                       
            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
                       
                       attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                       
                       
                       attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                  code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 44 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "Sometimes, Those loops are very fast. If you want to take those loops to become slow, then use a sleep keyboard to make loops slow for seconds in each of the duration loops units at the end."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 43 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Fire blasters!
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 42 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
            

            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "execute ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "true\n", attributes: [.foregroundColor: KeyboardSyntax]))

            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "while true ", attributes: [.foregroundColor: KeyboardSyntax]))
                    
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

         attr.append(NSAttributedString(string: " print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                         attr.append(NSAttributedString(string: "Fire blasters!", attributes: [.foregroundColor: StringSyntax]))

                       
                       attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                          
                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: " execute", attributes: [.foregroundColor: projectSyntax]))

               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "false\n", attributes: [.foregroundColor: KeyboardSyntax]))
            
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                       code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 41 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "You can stop infinite loop like previous code concept, But you need to add the false after the end of statements to stop the infinite loop."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 40 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  warningSignColor
            answer?.textLabel?.text = """
            The infinite loop initiated!
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 39 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
            
            
              // MARK: Nsattributedstring
                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                        attr.append(NSAttributedString(string: "while ", attributes: [.foregroundColor: KeyboardSyntax]))
                        
                        attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))

                        attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

      attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                      
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
           
              attr.append(NSAttributedString(string: "Fire blasters!", attributes: [.foregroundColor: StringSyntax]))

            
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                               
             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                        
               attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                         code?.textLabel?.attributedText = attr




                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 38 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "Be cautious! If you write this code to execute this statement will cause never to stop at the end is called an infinite loop.  This infinite loop is a bug."
            
            titleCell?.textLabel?.font = UIFont.systemFont(ofSize: 17)
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!

        } else if indexPath.row == 37 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
            titleCell?.textLabel?.font = UIFont.systemFont(ofSize: 20)
                
            titleCell?.textLabel?.text = "While Loops"
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .left
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 36 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       Anakin Skywalker
                       Shmi Skywalker
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 35 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                               let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                               attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "names ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                     attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
                     
                     attr.append(NSAttributedString(string: "\"Anakin Skywalker\" ", attributes: [.foregroundColor: StringSyntax]))
                     attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

                     attr.append(NSAttributedString(string: "\"Count Dooku\" ", attributes: [.foregroundColor: StringSyntax]))
                               

                     
                     attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

                     attr.append(NSAttributedString(string: "\"Shmi Skywalker\" ", attributes: [.foregroundColor: StringSyntax]))
                               

                     attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

                     attr.append(NSAttributedString(string: "\"Padme Amindala\" ", attributes: [.foregroundColor: StringSyntax]))
                               

                     attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

                     attr.append(NSAttributedString(string: "\"Obi-Wan Kenobi\" ", attributes: [.foregroundColor: StringSyntax]))
                               
                     attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))

                     attr.append(NSAttributedString(string: "2. \n", attributes: [.foregroundColor: counterSyntax]))

                     attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                 
                     attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                     attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: PlainSyntax]))

                     attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
                     attr.append(NSAttributedString(string: "names ", attributes: [.foregroundColor: projectSyntax]))
            
            
                              attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                        
                     attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "hasSuffix", attributes: [.foregroundColor: projectSyntax]))
                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "\"Skywalker\"", attributes: [.foregroundColor: StringSyntax]))
            attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                     attr.append(NSAttributedString(string: "  print", attributes: [.foregroundColor: projectSyntax]))

                                       
                              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       
                               attr.append(NSAttributedString(string: "names", attributes: [.foregroundColor: PlainSyntax]))

                         
                      
                              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))

                     attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))
                                
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))

                                attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                                           


                                code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 34 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "If you don't want to use where keyboard, then you can replace to if statements in the loop's statement. However, This code concept is similar to a previous one."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 33 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Anakin Skywalker
            Shmi Skywalker
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 32 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
       
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "names ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Anakin Skywalker\" ", attributes: [.foregroundColor: StringSyntax]))
            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"Count Dooku\" ", attributes: [.foregroundColor: StringSyntax]))
                      

            
            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"Shmi Skywalker\" ", attributes: [.foregroundColor: StringSyntax]))
                      

            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"Padme Amindala\" ", attributes: [.foregroundColor: StringSyntax]))
                      

            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"Obi-Wan Kenobi\" ", attributes: [.foregroundColor: StringSyntax]))
                      
            attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "2. \n", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

        
            attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
            attr.append(NSAttributedString(string: "names ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "where ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "hasSuffix", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "() {\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                              
                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
              
                      attr.append(NSAttributedString(string: "names", attributes: [.foregroundColor: PlainSyntax]))

                
             
                     attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                       

                       code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 31 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "When you create elements most of them are on the list to choose to include where's condition. The where keyboard means where do you need to call that inside of the code. The hasSuffix keyboard is the last string otherwise, hadPrefix keyboard is the first string in the once string."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 30 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
                                  answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                  answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                  answer?.textLabel?.text = """
                                  0
                                  1
                                  2
                                  🥳
                                  4
                                  5
                                  """
                                  answer?.textLabel?.numberOfLines = 0
                                  answer?.textLabel?.lineBreakMode = .byWordWrapping
                                  answer?.textLabel?.textAlignment = .center
                                  answer?.textLabel?.textColor = UIColor.white
                                  return answer!
        } else if indexPath.row == 29 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "i ", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "1 ", attributes: [.foregroundColor: NumberSyntax]))
                      attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: PlainSyntax]))
attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                          attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
                attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                              
            
            attr.append(NSAttributedString(string: "i ", attributes: [.foregroundColor: PlainSyntax]))
                    
            attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                    
              attr.append(NSAttributedString(string: "3 ", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                    
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
                    
                    attr.append(NSAttributedString(string: "  print", attributes: [.foregroundColor: projectSyntax]))

                              
                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                    
                
                      attr.append(NSAttributedString(string: "🥳", attributes: [.foregroundColor: projectSyntax]))

                          
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                       
                     attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                    
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                       
            attr.append(NSAttributedString(string: " }", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: " else", attributes: [.foregroundColor: KeyboardSyntax]))

            
            attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
            
            

              attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            
                       attr.append(NSAttributedString(string: "  print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                       
                   
                         attr.append(NSAttributedString(string: "i", attributes: [.foregroundColor: projectSyntax]))

                             
                       attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                          
                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                    
                    
                               attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                             
                             
                                        attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
            
                       code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 28 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "When you create an iterator called i and put in the if condition to equal to 3, it will execute the emoji to make this 3 instead to the emoji and else's statements will display the duration number in the console due to loops."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 27 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       H
                       e
                       l
                       l
                       o
                        
                       W
                       o
                       r
                       l
                       d
                       !
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 26 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
            code?.textLabel?.font = setFont
            
            
                     // MARK: Nsattributedstring
                               let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                               attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "range ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "\"Hello World!\" ", attributes: [.foregroundColor: StringSyntax]))

                   

                     attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                       attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                     
                      attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                     
                        attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                                       
                                       attr.append(NSAttributedString(string: "interator ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
                             
                             
                             attr.append(NSAttributedString(string: "range ", attributes: [.foregroundColor: projectSyntax]))
                             
                         attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                    
                             attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                             
                             attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                       
                              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                             attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                             
                             attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          
                               attr.append(NSAttributedString(string: "interator", attributes: [.foregroundColor: projectSyntax]))

                                      attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                             attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                                
                              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                             
                                         attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                             
                             attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                                        code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 25 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "You can create a character in the range to execute the line-break each of the character in the string based on the range."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 24 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            The start with 2 multiply iteration: 1 equal myFirstInt: 2
            The start with 2 multiply iteration: 2 equal myFirstInt: 4
            The start with 2 multiply iteration: 3 equal myFirstInt: 6
            The start with 2 multiply iteration: 4 equal myFirstInt: 8
            The start with 2 multiply iteration: 5 equal myFirstInt: 10
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 23 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
           code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                     let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                     attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                     
                                                     attr.append(NSAttributedString(string: "myFirstInt ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                            attr.append(NSAttributedString(string: "0\n", attributes: [.foregroundColor: NumberSyntax]))

                                           
                                             attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                           
                                              attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                             
                                                             attr.append(NSAttributedString(string: "i ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                      attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                   
                                                   
                                                   attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
            
                         attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "5", attributes: [.foregroundColor: NumberSyntax]))
                                                   
                                           
                                                             attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                                                   attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                                   
                                                   attr.append(NSAttributedString(string: "myFirstInt ", attributes: [.foregroundColor: projectSyntax]))

                                                             
                                                    attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                              
            attr.append(NSAttributedString(string: "2 \n", attributes: [.foregroundColor: NumberSyntax]))

  
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"The start with 2 multiply ideration: ", attributes: [.foregroundColor: StringSyntax]))

            attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "i", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "equal myFirstInt: ", attributes: [.foregroundColor: StringSyntax]))
           
            
            attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "myFirstInt", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))

            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
              attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                                                              code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 22 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "A new variable called number to create 0 in the value to put in the for-in's statements to addition and assignments to two will be up unit ends by end of the range."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 21 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            1: Fire blasters!
            2: Fire blasters!
            3: Fire blasters!
            4: Fire blasters!
            5: Fire blasters!
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 20 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
            
            
            // MARK: Nsattributedstring
                                            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                            
                                            attr.append(NSAttributedString(string: "range ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                   attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))

                                  attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: PlainSyntax]))
                                       attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                                  

                                  attr.append(NSAttributedString(string: "\n", attributes: [.foregroundColor: PlainSyntax]))
                                  
                                    attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                                  
                                   attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                  
                                     attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                    
                                                    attr.append(NSAttributedString(string: "interator ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                             attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
                                          
                                          
                                          attr.append(NSAttributedString(string: "range ", attributes: [.foregroundColor: projectSyntax]))
                                          
                                  
                                                    attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                                          attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                          
                                          attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                    
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                     
                                              attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
                                                       
                                            attr.append(NSAttributedString(string: "interator", attributes: [.foregroundColor: projectSyntax]))
                       
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                        
    
                       
                         attr.append(NSAttributedString(string: "\": Fire blasters!\"", attributes: [.foregroundColor: StringSyntax]))

                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                                      attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                          
                                          attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                                                     code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 19 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "The iterator is given duration number from a range which starts number unit end numbers, but iterator going to put in the string interpolation in the string to show you how does iterator works like multi-variables do."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!

        } else if indexPath.row == 18 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            1 2 3 4 5
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 17 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
                code?.textLabel?.font = setFont
            
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "range ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                        attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))

                       attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: PlainSyntax]))
                            attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                       

                       attr.append(NSAttributedString(string: "\n", attributes: [.foregroundColor: PlainSyntax]))
                       
                         attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                       
                        attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
                          attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                                         
                                         attr.append(NSAttributedString(string: "interator ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                  attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               
                               attr.append(NSAttributedString(string: "range ", attributes: [.foregroundColor: projectSyntax]))
                               
                       
                                         attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                               attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                               
                               attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                         
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                          
                               
                                            
                                 attr.append(NSAttributedString(string: "interator", attributes: [.foregroundColor: projectSyntax]))
            
              attr.append(NSAttributedString(string: ", terminator: ", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "\" \"", attributes: [.foregroundColor: StringSyntax]))

                                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                               
                                           attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                               
                               attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                                          code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!

        } else if indexPath.row == 16 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "If you don't want line-break, then create the terminator."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 15 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
                                  answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                  answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                  answer?.textLabel?.text = """
                                  5
                                  4
                                  3
                                  2
                                  1
                                  """
                                  answer?.textLabel?.numberOfLines = 0
                                  answer?.textLabel?.lineBreakMode = .byWordWrapping
                                  answer?.textLabel?.textAlignment = .center
                                  answer?.textLabel?.textColor = UIColor.white
                                  return answer!
        } else if indexPath.row == 14 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "range ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))

            attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
            

            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
               attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                              
                              attr.append(NSAttributedString(string: "interator ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                       attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
                    
                    
                    attr.append(NSAttributedString(string: "range", attributes: [.foregroundColor: projectSyntax]))
                    
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
               attr.append(NSAttributedString(string: "reversed", attributes: [.foregroundColor: projectSyntax]))
                   
                 attr.append(NSAttributedString(string: "()", attributes: [.foregroundColor: PlainSyntax]))
                              attr.append(NSAttributedString(string: "\n", attributes: [.foregroundColor: PlainSyntax]))

                    attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                    
                    attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                              
                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                    
                    attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                 
                      attr.append(NSAttributedString(string: "interator", attributes: [.foregroundColor: projectSyntax]))

                             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                                       
                     attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                    
                                attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                    
                    attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                               code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 13 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "The .reversed() allows a loop to turn backward to first from the end which is basically from a range."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 12 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       1
                       2
                       3
                       4
                       5
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 11 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
             
            code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "interator ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

               attr.append(NSAttributedString(string: "in ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            
            attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
            
               attr.append(NSAttributedString(string: "...", attributes: [.foregroundColor: PlainSyntax]))
                    
               attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                      
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                         
              attr.append(NSAttributedString(string: "interator", attributes: [.foregroundColor: projectSyntax]))

                     attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                               
             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
                        attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                       code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 10 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "You have to calling the iterator which behind the range based on duration number, and it will line-break by once code in the console."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 9 {
            answer = LoopsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? LoopsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Fire blasters!
            Fire blasters!
            Fire blasters!
            Fire blasters!
            Fire blasters!
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 8 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
          code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "blaster1 ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "\"Fire blasters!\"\n", attributes: [.foregroundColor: StringSyntax]))
            
               attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "blaster2 ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "\"Fire blasters!\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "blaster3 ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "\"Fire blasters!\"\n", attributes: [.foregroundColor: StringSyntax]))

            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "blaster4 ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "\"Fire blasters!\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "blaster5 ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "\"Fire blasters!\"", attributes: [.foregroundColor: StringSyntax]))
                      
                       code?.textLabel?.attributedText = attr
            
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 7 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "In the Star War, Those droids want to fire blasters at the Jedi. It is this code that you tried to write a multi-variables by use line-break?"
            
            titleCell?.textLabel?.font = UIFont.systemFont(ofSize: 17)
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 6 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
            titleCell?.textLabel?.font = UIFont.systemFont(ofSize: 20)
                
            titleCell?.textLabel?.text = "For-In Loops"
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .left
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 5 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            
               // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "repeat ", attributes: [.foregroundColor: KeyboardSyntax]))
                                  
        
                       
                                  attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                       
                            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                          attr.append(NSAttributedString(string: " statements ", attributes: [.backgroundColor: dynamicBackground ]))
                       
                         attr.append(NSAttributedString(string: ". \n", attributes: [.foregroundColor: CodeBackground ]))

                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
                               attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                                  

            attr.append(NSAttributedString(string: " while ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            
             attr.append(NSAttributedString(string: " condition ", attributes: [.backgroundColor: dynamicBackground ]))
            
               attr.append(NSAttributedString(string: ". ", attributes: [.foregroundColor: CodeBackground ]))
                                   code?.textLabel?.attributedText = attr
               
            
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!

        } else if indexPath.row == 4 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "The repeat doesn't have conditions, but a while condition will give the repeat will turn to loops otherwise, repeat will not execute duration loop if while conditions are false."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 3 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
                code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                               let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                               attr.append(NSAttributedString(string: "while ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: " condition ", attributes: [.backgroundColor: dynamicBackground ]))

                    
                               attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                    
                         attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                       attr.append(NSAttributedString(string: " statements ", attributes: [.backgroundColor: dynamicBackground ]))
                    
                      attr.append(NSAttributedString(string: ". \n", attributes: [.foregroundColor: CodeBackground ]))

                    attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                    
                            attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                               
                                code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 2 {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "While the loop does look similiar like if course. When you set a true in the condition could be executing these statements, otherwise, they will not be executing if the conditions were false."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 1 {
            code = LoopsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? LoopsCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "for ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                       attr.append(NSAttributedString(string: " interator ", attributes: [.backgroundColor: dynamicBackground ]))

             attr.append(NSAttributedString(string: " in ", attributes: [.foregroundColor: KeyboardSyntax]))
            
               attr.append(NSAttributedString(string: " range ", attributes: [.backgroundColor: dynamicBackground ]))
            
            
                       attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
                 attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

               attr.append(NSAttributedString(string: " statements ", attributes: [.backgroundColor: dynamicBackground ]))
            
              attr.append(NSAttributedString(string: ". \n", attributes: [.foregroundColor: CodeBackground ]))

            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
                    attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                       
                        code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else {
            titleCell = LoopsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? LoopsTitleTableViewCell
            
            titleCell?.textLabel?.text = "The integrator was close like the variable's name value. The integrator could put in the statements to executing it. The range is how much you want to start unit end number with thrice periods between two number. This range will allow these integrators and statements to repeat often as one executing."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        }
    }
    
    
}
