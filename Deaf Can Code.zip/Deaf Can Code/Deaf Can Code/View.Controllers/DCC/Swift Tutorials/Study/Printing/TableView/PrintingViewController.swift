//
//  PrintingViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/30/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class PrintingViewController: UIViewController {
    
    var titlePrint = [
        // 1
        "The print( ) is alike always executing into the console as the function does. The first thing, items is like calling the variable's value with name value or without calling them. The second thing is separator does like separate between each multiple items to add the new items. The third thing is a terminator is default this /n as known newlines.",
        // 2
        "The printing will output the items from inside the parenthesis to execute this will display in the console. If you do not text printing replace to variables or else could be display on only playground editor panel.",
        "",
        "",
        "You can use the math operators without assignment operators in anywhere with the code but in printing will tell you what answer in the console.",
        "",
        "",
        
        "When you text multiple printing, then it will not display as one line called a line-break. When you text printing will be output which is from each items for upon the console.",
        "",
        "",
        "You can text one or more than a single item. When you text whitespace, string, or could I said, star in the separator in the printing, then it will display a star in between each of the items. However, You could see \n stands for newlines, also I noticed for you, This is only a playground editor panel can display that but console can't.",
        "",
        "",
        
        "The terminator will default the new line because it's an only end at the sentence.",
        "",
        ""
    ]

    @IBOutlet weak var printing_Videos: WKWebView!
    @IBOutlet weak var PrintTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        PrintTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Printing"
        
        Label(IDCode: "d2nySxZ6830")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        printing_Videos.load(URLRequest(url: url!))

    }

}

extension PrintingViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: titlePrintTableViewCell!
        
        var code: codePrintTableViewCell!
        
        var answer: AnswerPrintTableViewCell!
        
        if indexPath.row == 19 {
            
                answer = PrintTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? AnswerPrintTableViewCell
                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                    answer?.textLabel?.text = """
                    Hello World
                    """
                answer?.textLabel?.numberOfLines = 0
                answer?.textLabel?.lineBreakMode = .byWordWrapping
                answer?.textLabel?.textAlignment = .center
                answer?.textLabel?.textColor = UIColor.white
                return answer!
            
        } else if indexPath.row == 18 {
            
                code = PrintTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? codePrintTableViewCell
                       
                code?.textLabel?.font = setFont
        
            
                // MARK: Nsattributedstring
                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
            
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"Hello\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"World\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "terminator: ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\" \"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                       
                return code!

        } else if indexPath.row == 17 {

                titleCell = PrintTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? titlePrintTableViewCell
            
                titleCell?.textLabel?.text = "The terminator will default the new line because it's an only end at the sentence."
              
                titleCell?.textLabel?.numberOfLines = 0
                titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                titleCell?.textLabel?.textAlignment = .center
                titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
                return titleCell!
            
        } else if indexPath.row == 16 {
            
                answer = PrintTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? AnswerPrintTableViewCell
                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                answer?.textLabel?.text = """
                Hello ⭐ World\\n
                """
            
                answer?.textLabel?.numberOfLines = 0
                answer?.textLabel?.lineBreakMode = .byWordWrapping
                answer?.textLabel?.textAlignment = .center
                answer?.textLabel?.textColor = UIColor.white
                return answer!
            
        } else if indexPath.row == 15 {
            
                code = PrintTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? codePrintTableViewCell
                       
                code?.textLabel?.font = setFont
                       
            
                // MARK: Nsattributedstring
                let attr = NSMutableAttributedString(string: "1.", attributes: [.foregroundColor: counterSyntax])
            
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
                attr.append(NSAttributedString(string: "\"Hello\"", attributes: [.foregroundColor: StringSyntax]))
            
                attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
            
                attr.append(NSAttributedString(string: "\"World\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: " separator: ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"⭐\"", attributes: [.foregroundColor: StringSyntax]))
            
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                       
                       return code!
            
        } else if indexPath.row == 14 {
            
                titleCell = PrintTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? titlePrintTableViewCell
                                                 
                titleCell?.textLabel?.text = "You can text one or more than a single item. When you text whitespace, string, or could I said, star in the separator in the printing, then it will display a star in between each of the items. However, You could see \n stands for newlines, also I noticed for you, This is only a playground editor panel can display that but console can't.  "
                                                   
                titleCell?.textLabel?.numberOfLines = 0
                titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                titleCell?.textLabel?.textAlignment = .center
                titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                                   
                 return titleCell!
            
        } else if indexPath.row == 13 {
            
        answer = PrintTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? AnswerPrintTableViewCell
                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                answer?.textLabel?.text = """
                item1-(SEP)-item2-(SEP)-
                """
                answer?.textLabel?.numberOfLines = 0
                answer?.textLabel?.lineBreakMode = .byWordWrapping
                answer?.textLabel?.textAlignment = .center
                answer?.textLabel?.textColor = UIColor.white
                return answer!
            
        } else if indexPath.row == 12 {
            
                code = PrintTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? codePrintTableViewCell
                   
                code?.textLabel?.font = setFont
                   
                code?.textLabel?.text = """
                1. print("item1", "item2", "item3", "...", separator: "-(SEP)-", terminator: "-(TERM)-")
                """
            
            
            // MARK: Nsattributedstring
                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
            
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
            
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
                attr.append(NSAttributedString(string: "\"item1\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: " \"item2\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: " \"item3\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: " \"...\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: " separator: ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"-(SEP)-\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: " terminator: ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"-(TERM)-\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                code?.textLabel?.attributedText = attr
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                   
                   return code!
            
        } else if indexPath.row == 11 {
            
                titleCell = PrintTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? titlePrintTableViewCell
                                      
                titleCell?.textLabel?.text = "You can text one or more than a single item. When you text whitespace, string, or could I said, star in the separator in the printing, then it will display a star in between each of the items. However, You could see \n stands for newlines, also I noticed for you, This is only a playground editor panel can display that but console can't."
                                        
                titleCell?.textLabel?.numberOfLines = 0
                titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                titleCell?.textLabel?.textAlignment = .center
                titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                        
                                        return titleCell!
            
        } else if indexPath.row == 10 {
            
                answer = PrintTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? AnswerPrintTableViewCell
                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                answer?.textLabel?.text = """
                Hello World!
                Hello World!
                Hello World!
                """
                answer?.textLabel?.numberOfLines = 0
                answer?.textLabel?.lineBreakMode = .byWordWrapping
                answer?.textLabel?.textAlignment = .center
                answer?.textLabel?.textColor = UIColor.white
                return answer!
        
            
        } else if indexPath.row == 9 {
                code = PrintTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? codePrintTableViewCell
                   
                code?.textLabel?.font = setFont
                   
                code?.textLabel?.text = """
                1. print("Hello World!")
                2. print("Hello World!")
                3. print("Hello World!")
                """
            
                // MARK: Nsattributedstring
                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                     
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                     
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                     
                attr.append(NSAttributedString(string: "\"Hello World!\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                
                attr.append(NSAttributedString(string: "\"Hello World!\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                
                attr.append(NSAttributedString(string: "\"Hello World!\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                   
                   return code!
            
        } else if indexPath.row == 8 {
        
                titleCell = PrintTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? titlePrintTableViewCell
                                       
                titleCell?.textLabel?.text = "When you text multiple printing, then it will not display as one line called a line-break. When you text printing will be output which is from each items for upon the console."
                                         
                titleCell?.textLabel?.numberOfLines = 0
                titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                titleCell?.textLabel?.textAlignment = .center
                titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                         
                return titleCell!
            
        } else if indexPath.row == 7 {
                answer = PrintTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? AnswerPrintTableViewCell
                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                answer?.textLabel?.text = """
                8
                """
                answer?.textLabel?.numberOfLines = 0
                answer?.textLabel?.lineBreakMode = .byWordWrapping
                answer?.textLabel?.textAlignment = .center
                answer?.textLabel?.textColor = UIColor.white
                return answer!
            
        } else if indexPath.row == 6 {
            
                code = PrintTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? codePrintTableViewCell
            
                code?.textLabel?.font = setFont
            
            
                // MARK: Nsattributedstring
                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
            
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
            
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
                attr.append(NSAttributedString(string: "3 ", attributes: [.foregroundColor: NumberSyntax]))
                attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                attr.append(NSAttributedString(string: "5", attributes: [.foregroundColor: NumberSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
            
                return code!
            
        } else if indexPath.row == 5 {
            
                titleCell = PrintTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? titlePrintTableViewCell
                                
                titleCell?.textLabel?.text = "You can use the math operators without assignment operators in anywhere with the code but in printing will tell you what answer in the console."
                                  
                titleCell?.textLabel?.numberOfLines = 0
                titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                titleCell?.textLabel?.textAlignment = .center
                titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                  
                return titleCell!
            
        } else if indexPath.row == 4 {
            
        
                answer = PrintTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? AnswerPrintTableViewCell
                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                answer?.textLabel?.text = """
                Hello World!
                """
                answer?.textLabel?.numberOfLines = 0
                answer?.textLabel?.lineBreakMode = .byWordWrapping
                answer?.textLabel?.textAlignment = .center
                answer?.textLabel?.textColor = UIColor.white
                return answer!
            
        } else if indexPath.row == 3 {
            
                code = PrintTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? codePrintTableViewCell
                     
                code?.textLabel?.font = setFont
            
            
                // MARK: Nsattributedstring
                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
            
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
            
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
                attr.append(NSAttributedString(string: "\"Hello World!\"", attributes: [.foregroundColor: StringSyntax]))
            
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                     
                return code!
            
        } else if indexPath.row == 2 {
            
                titleCell = PrintTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? titlePrintTableViewCell
                     
                titleCell?.textLabel?.text = "The printing will output the items from inside the parenthesis to execute this will display in the console. If you do not text printing replace to variables or else could be display on only playground editor panel."
                       
                titleCell?.textLabel?.numberOfLines = 0
                titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                titleCell?.textLabel?.textAlignment = .center
                titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                       
                return titleCell!
            
        } else if indexPath.row == 1 {
            
                code = PrintTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? codePrintTableViewCell
            
                code?.textLabel?.font = setFont
            
            code?.textLabel?.text = """
                      1. print( items: Any... , separator: String , terminator: String )
                      """
            

            
           
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                
            attr.append(NSAttributedString(string: " items: Any... ", attributes: [.backgroundColor: dynamicBackground]))
            
       
            attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                          
             attr.append(NSAttributedString(string: " separator: String ", attributes: [.backgroundColor: dynamicBackground]))
            
            attr.append(NSAttributedString(string: ",", attributes: [.foregroundColor: PlainSyntax]))
                                     
                        attr.append(NSAttributedString(string: " terminator: String ", attributes: [.backgroundColor: dynamicBackground]))
                       
            
            attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                
            code?.textLabel?.attributedText = attr
                                                            
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
                                                                                 
                                                                                    
            return code!
        } else {
            titleCell = PrintTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? titlePrintTableViewCell
          
            titleCell?.textLabel?.text = "The print( ) is alike always executing into the console as the function does. The first thing, items is like calling the variable's value with name value or without calling them. The second thing is separator does like separate between each multiple items to add the new items. The third thing is a terminator is default this /n as known newlines."
            
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
            
            return titleCell!
        }
        
        
    }
    
    
    
}
