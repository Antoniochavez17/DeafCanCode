//
//  DictionariesViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class DictionariesViewController: UIViewController {

    @IBOutlet weak var DictTableView: UITableView!
    @IBOutlet weak var DictVideos: WKWebView!
    
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        DictTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Dictionaries"
        
        Label(IDCode: "GSdOtv6dXhs")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        DictVideos.load(URLRequest(url: url!))

    }

}


extension DictionariesViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 23
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: DictTitleTableViewCell!
        var code: DictCodeTableViewCell!
        var answer: DictAnswerTableViewCell!
        
         if indexPath.row == 22  {
            answer = DictTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? DictAnswerTableViewCell
                               answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                               answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                               answer?.textLabel?.text = """
                               "Music"
                               """
                               answer?.textLabel?.numberOfLines = 0
                               answer?.textLabel?.lineBreakMode = .byWordWrapping
                               answer?.textLabel?.textAlignment = .center
                               answer?.textLabel?.textColor = UIColor.white
                               return answer!
        } else if indexPath.row == 21 {
              code = DictTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? DictCodeTableViewCell
             
              code?.textLabel?.font = setFont
             
             // MARK: Nsattributedstring
             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

             attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
             
             attr.append(NSAttributedString(string: "FavoriteItems ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
             
            

                                 attr.append(NSAttributedString(string: "\"Antonio\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                                 attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                   attr.append(NSAttributedString(string: "\"Programming\"", attributes: [.foregroundColor: StringSyntax]))
                                   attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                 attr.append(NSAttributedString(string: "\"Alan\"", attributes: [.foregroundColor: StringSyntax]))
                                 attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "\"Music\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
              attr.append(NSAttributedString(string: "FavoriteItems", attributes: [.foregroundColor: projectSyntax]))
             

              attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
             
               attr.append(NSAttributedString(string: "\"Alan\"", attributes: [.foregroundColor: StringSyntax]))

            attr.append(NSAttributedString(string: ", default:", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "\"Programming\"", attributes: [.foregroundColor: StringSyntax]))
            
            
              attr.append(NSAttributedString(string: "] ", attributes: [.foregroundColor: PlainSyntax]))
              
             
             code?.textLabel?.attributedText = attr
                  
                  
                  code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                  code?.textLabel?.numberOfLines = 0
                  code?.textLabel?.lineBreakMode = .byWordWrapping
                  code?.textLabel?.textAlignment = .left
                                        
                                          
                  return code!
        } else if indexPath.row == 20  {
            titleCell = DictTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? DictTitleTableViewCell
                             
                             titleCell?.textLabel?.text = "You'll have to add a default in the value to rid that execute in which Alan doesn't like it. It's called dictionaries default value."
                               
                               titleCell?.textLabel?.numberOfLines = 0
                               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                               titleCell?.textLabel?.textAlignment = .center
                               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                               
                               return titleCell!
        } else if indexPath.row == 19  {
            answer = DictTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? DictAnswerTableViewCell
                               answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                               answer?.backgroundColor =  errorSignColor
                               answer?.textLabel?.text = """
                               Missing argument label 'default:' in subscript
                               """
                               answer?.textLabel?.numberOfLines = 0
                               answer?.textLabel?.lineBreakMode = .byWordWrapping
                               answer?.textLabel?.textAlignment = .center
                               answer?.textLabel?.textColor = UIColor.white
                               return answer!
        } else if indexPath.row == 18  {
              code = DictTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? DictCodeTableViewCell
             
              code?.textLabel?.font = setFont
             
             // MARK: Nsattributedstring
             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

             attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
             
             attr.append(NSAttributedString(string: "FavoriteItems ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
             
            

                                 attr.append(NSAttributedString(string: "\"Antonio\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                                 attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                   attr.append(NSAttributedString(string: "\"Programming\"", attributes: [.foregroundColor: StringSyntax]))
                                   attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                 attr.append(NSAttributedString(string: "\"Alan\"", attributes: [.foregroundColor: StringSyntax]))
                                 attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "\"Music\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
              attr.append(NSAttributedString(string: "FavoriteItems", attributes: [.foregroundColor: projectSyntax]))
             

              attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
             
               attr.append(NSAttributedString(string: "\"Alan\"", attributes: [.foregroundColor: StringSyntax]))

            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "\"Programming\"", attributes: [.foregroundColor: StringSyntax]))
            
              attr.append(NSAttributedString(string: "] ", attributes: [.foregroundColor: PlainSyntax]))
              
             
             code?.textLabel?.attributedText = attr
                  
                  
                  code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                  code?.textLabel?.numberOfLines = 0
                  code?.textLabel?.lineBreakMode = .byWordWrapping
                  code?.textLabel?.textAlignment = .left
                                        
                                          
                  return code!
        } else if indexPath.row == 17  {
            titleCell = DictTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? DictTitleTableViewCell
                             
                             titleCell?.textLabel?.text = "If you set the value in which it does not match his likes. It's will errors because He's not a programmer."
                               
                               titleCell?.textLabel?.numberOfLines = 0
                               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                               titleCell?.textLabel?.textAlignment = .center
                               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                               
                               return titleCell!
        } else if indexPath.row == 16  {
            
            answer = DictTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? DictAnswerTableViewCell
                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                    answer?.textLabel?.text = """
                    "Music"
                    """
                    answer?.textLabel?.numberOfLines = 0
                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                    answer?.textLabel?.textAlignment = .center
                    answer?.textLabel?.textColor = UIColor.white
                    return answer!
        } else if indexPath.row == 15  {
              
                   code = DictTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? DictCodeTableViewCell
            
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "FavoriteItems ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
            
           

                                attr.append(NSAttributedString(string: "\"Antonio\"", attributes: [.foregroundColor: StringSyntax]))
                                
                                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                  attr.append(NSAttributedString(string: "\"Programming\"", attributes: [.foregroundColor: StringSyntax]))
                                  attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                attr.append(NSAttributedString(string: "\"Alan\"", attributes: [.foregroundColor: StringSyntax]))
                                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                attr.append(NSAttributedString(string: "\"Music\"", attributes: [.foregroundColor: StringSyntax]))
                                
                                attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                           
           attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "FavoriteItems", attributes: [.foregroundColor: projectSyntax]))
            

             attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "\"Alan\"", attributes: [.foregroundColor: StringSyntax]))

             attr.append(NSAttributedString(string: "] ", attributes: [.foregroundColor: PlainSyntax]))
             
            
            code?.textLabel?.attributedText = attr
                 
                 
                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                 code?.textLabel?.numberOfLines = 0
                 code?.textLabel?.lineBreakMode = .byWordWrapping
                 code?.textLabel?.textAlignment = .left
                                       
                                         
                 return code!
            
            
        } else if indexPath.row == 14  {
            titleCell = DictTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? DictTitleTableViewCell
                    
                    titleCell?.textLabel?.text = "Let's create a variable called FavoriteItems. The keys to using person and values are what a person likes. When you choose the key, then it'll execute the value."
                      
                      titleCell?.textLabel?.numberOfLines = 0
                      titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                      titleCell?.textLabel?.textAlignment = .center
                      titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                      
                      return titleCell!
        } else if indexPath.row == 13 {
            answer = DictTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? DictAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            [1:"dict1", 3: "dict3", 2:"dict2,]
            3
            [10: "dict10", 1: "dict1", 2:"dict2", 3: "dict3"]
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 12 {
            code = DictTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? DictCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "dict ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
                      
                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      
                        attr.append(NSAttributedString(string: "\"Dict1\"", attributes: [.foregroundColor: StringSyntax]))
                        attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "\"Dict2\"", attributes: [.foregroundColor: StringSyntax]))
                      
                      attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                 
                       attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      attr.append(NSAttributedString(string: "dict", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "3", attributes: [.foregroundColor: NumberSyntax]))
                      
                       attr.append(NSAttributedString(string: "] ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "\"dict3\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                               
                               attr.append(NSAttributedString(string: "dict", attributes: [.foregroundColor: projectSyntax]))
                               
                             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "count\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                          
                                          attr.append(NSAttributedString(string: "dict", attributes: [.foregroundColor: projectSyntax]))
                                          
                                        attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                       
                        attr.append(NSAttributedString(string: "updateValue", attributes: [.foregroundColor: projectSyntax]))
            
              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "\"dict10\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "forKey", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "10", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                       code?.textLabel?.attributedText = attr
                
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!

        } else if indexPath.row == 11 {
            titleCell = DictTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? DictTitleTableViewCell
            
            titleCell?.textLabel?.text = "If you want to remove those keys, then you can be calling that dict and add removeValue to remove that key and value, too."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 10 {
            answer = DictTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? DictAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            [1:"dict1", 3: "dict3", 2:"dict2,]
            3
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 9 {
            code = DictTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? DictCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "dict ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
                      
                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      
                        attr.append(NSAttributedString(string: "\"Dict1\"", attributes: [.foregroundColor: StringSyntax]))
                        attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: "\"Dict2\"", attributes: [.foregroundColor: StringSyntax]))
                      
                      attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                 
                       attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      
                      attr.append(NSAttributedString(string: "dict", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "3", attributes: [.foregroundColor: NumberSyntax]))
                      
                       attr.append(NSAttributedString(string: "] ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "\"dict3\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                               
                               attr.append(NSAttributedString(string: "dict", attributes: [.foregroundColor: projectSyntax]))
                               
                             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "count", attributes: [.foregroundColor: projectSyntax]))
            
                       code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 8 {
            titleCell = DictTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? DictTitleTableViewCell
            
            titleCell?.textLabel?.text = "You could know about count from the number and array, but count is a count how many keys does you have in that dictionaries unless it was only on the playground editor panel can display that if you use count."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 7 {
            answer = DictTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? DictAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       [1:"dict1", 3: "dict3", 2:"dict2,]
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 6 {
            code = DictTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? DictCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
                
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "dict ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "\"Dict1\"", attributes: [.foregroundColor: StringSyntax]))
              attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Dict2\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                       
             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "dict", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "3", attributes: [.foregroundColor: NumberSyntax]))
            
             attr.append(NSAttributedString(string: "] ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "\"dict3\"", attributes: [.foregroundColor: StringSyntax]))
            
             code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 5 {
            titleCell = DictTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? DictTitleTableViewCell
            
            titleCell?.textLabel?.text = "When you create a name value which it was calling dict and put the number for new key in the curly brackets and assignment to a string, then it will be adding new values in the inside of the dictionaries, but dictionaries couldn't order like Arrays."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 4 {
            answer = DictTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? DictAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            [1:"dict1", 2:"dict2,]
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 3 {
            code = DictTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? DictCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "dict ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "\"Dict1\"", attributes: [.foregroundColor: StringSyntax]))
              attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Dict2\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                       
            
             code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 2 {
            titleCell = DictTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? DictTitleTableViewCell
                   
                   titleCell?.textLabel?.text = "An example of the basics of the dictionary has shown you. You can add more key and value than one key and value."
                     
                     titleCell?.textLabel?.numberOfLines = 0
                     titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                     titleCell?.textLabel?.textAlignment = .center
                     titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                     
                     return titleCell!
        } else if indexPath.row == 1 {
            code = DictTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? DictCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "dict ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
             
                       attr.append(NSAttributedString(string: " key1 ", attributes: [.backgroundColor: dynamicBackground]))

                       attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
                      attr.append(NSAttributedString(string: " value1 ", attributes: [.backgroundColor: dynamicBackground]))
                      
                      attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

                 attr.append(NSAttributedString(string: " key2 ", attributes: [.backgroundColor: dynamicBackground]))
                       attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: " value2 ", attributes: [.backgroundColor: dynamicBackground]))
                      
                       attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                      
                 attr.append(NSAttributedString(string: " key3 ", attributes: [.backgroundColor: dynamicBackground]))
             attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      attr.append(NSAttributedString(string: " value3 ", attributes: [.backgroundColor: dynamicBackground]))
                      
                       attr.append(NSAttributedString(string: " ] ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else {
            titleCell = DictTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? DictTitleTableViewCell
            
            titleCell?.textLabel?.text = "The dictionaries use buckle brackets as Array does, But it was a request colon with the two things called key and value. This dictionary's key and value are very close looking the same as the variable's name and value."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        }
    }
    
    
    
}
