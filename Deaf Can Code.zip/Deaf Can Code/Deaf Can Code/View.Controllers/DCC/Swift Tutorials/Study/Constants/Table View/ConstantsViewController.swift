//
//  ConstantsViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/1/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class ConstantsViewController: UIViewController {

    @IBOutlet weak var ConstantsVideo: WKWebView!
    @IBOutlet weak var ConstantsTableView: UITableView!
   

 override func viewDidLoad() {
     super.viewDidLoad()

     // automatic height cells which you don't need add height for each cells
     ConstantsTableView.rowHeight = UITableView.automaticDimension
     
     // Remove large title on the navigation bar
     navigationController?.navigationBar.prefersLargeTitles = false
     
     self.navigationItem.title = "Constants"
     
     Label(IDCode: "XLV6NUwXdeo")
 }
 
 override func viewWillDisappear(_ animated: Bool) {
     super.viewWillDisappear(true)
     
     // When you return back to previous will be appear large title on the navigation bar
     navigationController?.navigationBar.prefersLargeTitles = true
 }

 // Videos
 func Label(IDCode: String) {
     let url = URL(string:
         "https://www.youtube.com/embed/\(IDCode)")
     ConstantsVideo.load(URLRequest(url: url!))

 }

}

extension ConstantsViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        14
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: ConstantsTitleTableViewCell!
        var code: ConstantsCodeTableViewCell!
        var answer: ConstantsAnswerTableViewCell!
        
        if indexPath.row == 13 {
            answer = ConstantsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ConstantsAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = UIColor.systemRed
            answer?.textLabel?.text = """
              Consecutive statements on a line must be separated by ';'
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 12 {
            code = ConstantsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ConstantsCodeTableViewCell
                                    
          code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                                                        
                                                                    attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                             
                                                       attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                       
                                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                                 
                                                       attr.append(NSAttributedString(string: "\"Welcome\"\n", attributes: [.foregroundColor: StringSyntax]))

                                                    attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                                                    attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                         
                                                   attr.append(NSAttributedString(string: "combineGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                   
                                                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                           
                                                   attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: projectSyntax]))
                                                        
                                                   attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: projectSyntax]))
                                                   
                                                   
                                                   attr.append(NSAttributedString(string: "\"We're glad you're here!\"\n", attributes: [.foregroundColor: StringSyntax]))
                                               
                                               attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
                                                            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                                           attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                 
                                                           attr.append(NSAttributedString(string: "leaveGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                           
                                                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                                   
                                                           attr.append(NSAttributedString(string: "greeting\n", attributes: [.foregroundColor: projectSyntax]))
                                               
                                                attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                                               
                                               attr.append(NSAttributedString(string: "leaveGreeting ", attributes: [.foregroundColor: projectSyntax]))
                                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                               attr.append(NSAttributedString(string: "\"Have a nice time!\"\n", attributes: [.foregroundColor: StringSyntax]))
                         
                    attr.append(NSAttributedString(string: "7.\n", attributes: [.foregroundColor: counterSyntax]))
                          
               attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
               
               attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
               
               attr.append(NSAttributedString(string: "check ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
               
               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
               
               attr.append(NSAttributedString(string: "leaveGreeting", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: " == ", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "greeting", attributes: [.foregroundColor: projectSyntax]))
                         code?.textLabel?.attributedText = attr
            
                                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                              code?.textLabel?.numberOfLines = 0
                                              code?.textLabel?.lineBreakMode = .byWordWrapping
                                              code?.textLabel?.textAlignment = .left
                                  
                                    
                                    return code!
        } else if indexPath.row == 11 {
            titleCell = ConstantsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ConstantsTitleTableViewCell
                       
                         titleCell?.textLabel?.text = "The constant will not allows you to calling the name-values to check if first values is equal to the new values The constant seems like they want this value to prevent it from accident."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 10 {
            answer = ConstantsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ConstantsAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  UIColor.systemRed
            answer?.textLabel?.text = """
              Cannot assign to value: 'greeting' is a 'let' constant
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 9 {
            code = ConstantsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ConstantsCodeTableViewCell
                                    
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                           
                                       attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                          attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                          
                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                    
                          attr.append(NSAttributedString(string: "\"Welcome\"\n", attributes: [.foregroundColor: StringSyntax]))

                       attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                      attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                            
                      attr.append(NSAttributedString(string: "combineGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                              
                      attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: projectSyntax]))
                           
                      attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: projectSyntax]))
                      
                      
                      attr.append(NSAttributedString(string: "\"We're glad you're here!\"\n", attributes: [.foregroundColor: StringSyntax]))
                  
                  attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
                               attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                              attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                    
                              attr.append(NSAttributedString(string: "leaveGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                              
                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                      
                              attr.append(NSAttributedString(string: "greeting\n", attributes: [.foregroundColor: projectSyntax]))
                  
                   attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                  
                  attr.append(NSAttributedString(string: "leaveGreeting ", attributes: [.foregroundColor: projectSyntax]))
                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                  attr.append(NSAttributedString(string: "\"Have a nice time!\"", attributes: [.foregroundColor: StringSyntax]))
                                           
                                       
                            code?.textLabel?.attributedText = attr
                  
            
            
                                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                              code?.textLabel?.numberOfLines = 0
                                              code?.textLabel?.lineBreakMode = .byWordWrapping
                                              code?.textLabel?.textAlignment = .left
                                  
                                    
                                    return code!
        } else if indexPath.row == 8 {
            titleCell = ConstantsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ConstantsTitleTableViewCell
            
              titleCell?.textLabel?.text = "The constant will not allows you to calling the name-values to check if first values is equal to the new values The constant seems like they want this value to prevent it from accident."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!

        } else if indexPath.row == 7 {
            answer = ConstantsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ConstantsAnswerTableViewCell
                                               answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  UIColor.systemRed
            
                       answer?.textLabel?.text = """
                          Red errors: Left side of mutating
                              operator isn't mutable:
                          'greeting' is a 'let' constant.
                       """
                                               answer?.textLabel?.numberOfLines = 0
                                               answer?.textLabel?.lineBreakMode = .byWordWrapping
                                               answer?.textLabel?.textAlignment = .center
                                               answer?.textLabel?.textColor = UIColor.white
                                               return answer!
        } else if indexPath.row == 6 {
            code = ConstantsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ConstantsCodeTableViewCell
                                    
                code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                           let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                               
                                           attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                          attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                          
                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                    
                          attr.append(NSAttributedString(string: "\"Welcome\"\n", attributes: [.foregroundColor: StringSyntax]))

                       attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                      attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                            
                      attr.append(NSAttributedString(string: "combineGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                              
                      attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: projectSyntax]))
                           
                      attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: projectSyntax]))
                      
                      
                      attr.append(NSAttributedString(string: "\"We're glad you're here!\"", attributes: [.foregroundColor: StringSyntax]))
                                           
                                code?.textLabel?.attributedText = attr
            
                                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                              code?.textLabel?.numberOfLines = 0
                                              code?.textLabel?.lineBreakMode = .byWordWrapping
                                              code?.textLabel?.textAlignment = .left
                                  
                                    
                                    return code!
        } else if indexPath.row == 5 {
            titleCell = ConstantsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ConstantsTitleTableViewCell
            
              titleCell?.textLabel?.text = "The constant will not allows you to calling the name-values to change a new values."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 4 {
            answer = ConstantsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? ConstantsAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Happy Birthday!
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 3 {
            code = ConstantsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ConstantsCodeTableViewCell
                         
                 code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                     
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "greeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
            attr.append(NSAttributedString(string: "\"Happy Birthday!\"", attributes: [.foregroundColor: StringSyntax]))

                
                                 
                      code?.textLabel?.attributedText = attr
                                   code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                   code?.textLabel?.numberOfLines = 0
                                   code?.textLabel?.lineBreakMode = .byWordWrapping
                                   code?.textLabel?.textAlignment = .left
                       
                         
                         return code!
        } else if indexPath.row == 2 {
            titleCell = ConstantsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ConstantsTitleTableViewCell
            
              titleCell?.textLabel?.text = "You could create a new value is called greeting to assignment a value like variables does."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 1 {
            code = ConstantsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? ConstantsCodeTableViewCell
                                    
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                           
                       attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
            
            attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: " value ", attributes: [.backgroundColor: dynamicBackground]))
                       
            code?.textLabel?.attributedText = attr
            
                                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                              code?.textLabel?.numberOfLines = 0
                                              code?.textLabel?.lineBreakMode = .byWordWrapping
                                              code?.textLabel?.textAlignment = .left
                                  
                                    
                                    return code!
        } else {
            titleCell = ConstantsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? ConstantsTitleTableViewCell
            
              titleCell?.textLabel?.text = "You have learned from Variables means it will allow you to do something, but constants will NOT allow you to do something."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        }
    }
    
    
    
}

