//
//  BooleansViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/3/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class BooleansViewController: UIViewController {

    @IBOutlet weak var booleanVideo: WKWebView!
    @IBOutlet weak var BoolTableView: UITableView!
    
  override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        BoolTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Booleans"
        
        Label(IDCode: "Fe8EFEO2oI8")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        booleanVideo.load(URLRequest(url: url!))

    }


}

extension BooleansViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        18
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: BooleansTitleTableViewCell!
        var code: BooleansCodeTableViewCell!
        var answer: BooleansAnswerTableViewCell!
        
         if indexPath.row == 17 {
            answer = BoolTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BooleansAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            false
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 16 {
            code = BoolTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BooleansCodeTableViewCell
                                        
               code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                          let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                          attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                 
                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
                         attr.append(NSAttributedString(string: "\"Grape\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                  attr.append(NSAttributedString(string: " != ", attributes: [.foregroundColor: PlainSyntax]))
                  
                  
                               attr.append(NSAttributedString(string: "\"Grape\"", attributes: [.foregroundColor: StringSyntax]))
                                                     
                               
                                code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 15 {
            titleCell = BoolTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BooleansTitleTableViewCell
            
            titleCell?.textLabel?.text = "The exclamation mark assignment operator means not equal. If you text the same word in both of the values, then it will result false. If you text different items in the next value, then it will result true."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 14 {
            answer = BoolTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BooleansAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            true
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 13 {
            code = BoolTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BooleansCodeTableViewCell
                                                   
                      code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                    let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                    attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                         
                         attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                           
                         attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                         
                   attr.append(NSAttributedString(string: "\"Grape\"", attributes: [.foregroundColor: StringSyntax]))
                           
            attr.append(NSAttributedString(string: " == ", attributes: [.foregroundColor: PlainSyntax]))
            
            
                         attr.append(NSAttributedString(string: "\"Grape\"", attributes: [.foregroundColor: StringSyntax]))
                                               
                         
                          code?.textLabel?.attributedText = attr
                           
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        } else if indexPath.row == 12 {
            titleCell = BoolTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BooleansTitleTableViewCell
            
            titleCell?.textLabel?.text = "The double assignment operator means to check if two values are equal or not. If you text the same word in both of the values, then it will result true. If you text different items in the next value, then it will result false."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 11 {
            answer = BoolTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BooleansAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            true
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 10 {
            code = BoolTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BooleansCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
            
                // MARK: Nsattributedstring
                                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                             
                             attr.append(NSAttributedString(string: "bool ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                               
                             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                             
                       attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                                              
                             attr.append(NSAttributedString(string: "false ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                   
                             
                              code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 9 {
                   titleCell = BoolTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BooleansTitleTableViewCell
                   
                   titleCell?.textLabel?.text = "It was changed in the booleans a \"not true\" to \"not false\" will results true."
                     
                     titleCell?.textLabel?.numberOfLines = 0
                     titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                     titleCell?.textLabel?.textAlignment = .center
                     titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                     
                     return titleCell!
        } else if indexPath.row == 8 {
            answer = BoolTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BooleansAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            false
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 7 {
            code = BoolTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BooleansCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                             attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                  
                  attr.append(NSAttributedString(string: "bool ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    
                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                  
            attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                                   
                  attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))
                                        
                  
                   code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 6 {
            titleCell = BoolTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BooleansTitleTableViewCell
            
            titleCell?.textLabel?.text = "If you don't agree with this true in boolean, then add an exclamation mark, \"It stand for not\" in front of the boolean, It'll convert true to false."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 5 {
            answer = BoolTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BooleansAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            false
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!

        } else if indexPath.row == 4 {
            code = BoolTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BooleansCodeTableViewCell
                                                                     
                                        
               code?.textLabel?.font = setFont
                                                
                                            
                                                       // MARK: Nsattributedstring
                                                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                            
                                            attr.append(NSAttributedString(string: "bool ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                              
                                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                                  
                                            attr.append(NSAttributedString(string: "false ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                  
                                            
                                             code?.textLabel?.attributedText = attr
                                            
                                                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                code?.textLabel?.numberOfLines = 0
                                                code?.textLabel?.lineBreakMode = .byWordWrapping
                                                code?.textLabel?.textAlignment = .left
                                                                      
                                                                        
                                                return code!
        } else if indexPath.row == 3 {
            titleCell = BoolTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BooleansTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "The Swift have an opposite of the true in booleans called false."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 2 {
           answer = BoolTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? BooleansAnswerTableViewCell
           answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
           answer?.backgroundColor = #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
           answer?.textLabel?.text = """
           true
           """
           answer?.textLabel?.numberOfLines = 0
           answer?.textLabel?.lineBreakMode = .byWordWrapping
           answer?.textLabel?.textAlignment = .center
           answer?.textLabel?.textColor = UIColor.white
           return answer!
        } else if indexPath.row == 1 {
            code = BoolTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? BooleansCodeTableViewCell
                                        
        
                                        
              code?.textLabel?.font = setFont
                
            
                       // MARK: Nsattributedstring
                       let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "bool ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
              
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
            attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))
                                  
            
             code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else {
           titleCell = BoolTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? BooleansTitleTableViewCell
            
            titleCell?.textLabel?.text = "The booleans are known as true or false in the swift. You could choose true or false up to your options if you agree or not."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        }
    }
    
    
    
}

