//
//  TuplesViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class TuplesViewController: UIViewController {

    @IBOutlet weak var TuplesTableView: UITableView!
    @IBOutlet weak var TuplesVideo: WKWebView!
    
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        TuplesTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Tuples"
        
        Label(IDCode: "Wp0d_Wuel38")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        TuplesVideo.load(URLRequest(url: url!))

    }

}



extension TuplesViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: TuplesTitleTableViewCell!
        var code: TuplesCodeTableViewCell!
        var answer: TuplesAnswerTableViewCell!
        
        if indexPath.row == 19 {
            
            answer = TuplesTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? TuplesAnswerTableViewCell
                                         answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                         answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                         answer?.textLabel?.text = """
                     Aliex
                     15
                     1943
                     (.0 "Aliex", .1 15, .2 1943)
                     false
                     You're not ready to be king
                     """
                                         answer?.textLabel?.numberOfLines = 0
                                         answer?.textLabel?.lineBreakMode = .byWordWrapping
                                         answer?.textLabel?.textAlignment = .center
                                         answer?.textLabel?.textColor = UIColor.white
                                         return answer!
            
        } else if indexPath.row == 18 {
            
            code = TuplesTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TuplesCodeTableViewCell
                                                   
          code?.textLabel?.font = setFont
            
            
            // MARK: Nsattributedstring
                                                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                                  attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                  
                                                                  attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                              attr.append(NSAttributedString(string: "\"Aliex\"\n", attributes: [.foregroundColor: StringSyntax]))
                              
                               attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                              attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                             
                                                                             attr.append(NSAttributedString(string: "age ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                         attr.append(NSAttributedString(string: "15\n", attributes: [.foregroundColor: NumberSyntax]))
                              
                               attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                              attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                    
                                                                                    attr.append(NSAttributedString(string: "birth ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                attr.append(NSAttributedString(string: "1943\n", attributes: [.foregroundColor: NumberSyntax]))
                                  
                               attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                              
                              
                              attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                  
                                                                  attr.append(NSAttributedString(string: "person ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))

                                                                  attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                                                     
                                                                    attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                                  attr.append(NSAttributedString(string: "age", attributes: [.foregroundColor: projectSyntax]))
                                                 
                                                                  attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                          attr.append(NSAttributedString(string: "birth", attributes: [.foregroundColor: projectSyntax]))
                                                                                          
                                                                  attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                              
                      attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                       
                                       
                                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                           
                                                                           attr.append(NSAttributedString(string: "check ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                                           attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))

                                                                           attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                              
                                                                             attr.append(NSAttributedString(string: "2 ", attributes: [.foregroundColor: NumberSyntax]))
                                                                           attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: PlainSyntax]))
                                                          
                                                                           attr.append(NSAttributedString(string: "18\n", attributes: [.foregroundColor: NumberSyntax]))
                                                                                              attr.append(NSAttributedString(string: "6.\n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "check ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                      
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "\"You're ready to be king!\"", attributes: [.foregroundColor: StringSyntax]))
            
           
                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                       
              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "\"You're not ready to be king!\"", attributes: [.foregroundColor: StringSyntax]))
             
            
                  attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                       
                              code?.textLabel?.attributedText = attr
                       
                             
                         
                           
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        
        } else if indexPath.row == 17 {
            
            titleCell = TuplesTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TuplesTitleTableViewCell
                                  
                                  titleCell?.textLabel?.text = "The tuples allow you to access the tuple's store values to use keys in the if, else, else if, switch, and more."
                                    
                                    titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        
        } else if indexPath.row == 16 {
            
            answer = TuplesTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? TuplesAnswerTableViewCell
                                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                answer?.textLabel?.text = """
            Aliex
            15
            1943
            (.0 "Aliex", .1 15, .2 1943)
            false
            """
                                answer?.textLabel?.numberOfLines = 0
                                answer?.textLabel?.lineBreakMode = .byWordWrapping
                                answer?.textLabel?.textAlignment = .center
                                answer?.textLabel?.textColor = UIColor.white
                                return answer!
        
        } else if indexPath.row == 15 {
            
            code = TuplesTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TuplesCodeTableViewCell
                                        
              code?.textLabel?.font = setFont
                  
            // MARK: Nsattributedstring
                                                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                        
                                                        attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                    attr.append(NSAttributedString(string: "\"Aliex\"\n", attributes: [.foregroundColor: StringSyntax]))
                    
                     attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                    attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                   
                                                                   attr.append(NSAttributedString(string: "age ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                               attr.append(NSAttributedString(string: "15\n", attributes: [.foregroundColor: NumberSyntax]))
                    
                     attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                    attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                          
                                                                          attr.append(NSAttributedString(string: "birth ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                      attr.append(NSAttributedString(string: "1943\n", attributes: [.foregroundColor: NumberSyntax]))
                        
                     attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                    
                    
                    attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                        
                                                        attr.append(NSAttributedString(string: "person ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))

                                                        attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                                           
                                                          attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                        attr.append(NSAttributedString(string: "age", attributes: [.foregroundColor: projectSyntax]))
                                       
                                                        attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                attr.append(NSAttributedString(string: "birth", attributes: [.foregroundColor: projectSyntax]))
                                                                                
                                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                    
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                             
                             
                             attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                 
                                                                 attr.append(NSAttributedString(string: "check ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                                 attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))

                                                                 attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                    
                                                                   attr.append(NSAttributedString(string: "2 ", attributes: [.foregroundColor: NumberSyntax]))
                                                                 attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: PlainSyntax]))
                                                
                                                                 attr.append(NSAttributedString(string: "18 ", attributes: [.foregroundColor: NumberSyntax]))
                                                                                         
                             
                    code?.textLabel?.attributedText = attr
             
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        
        } else if indexPath.row == 14 {
            
            titleCell = TuplesTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TuplesTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "The tuples allow you to check if the value between new value are equal or not."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        
        } else if indexPath.row == 13 {
            
            answer = TuplesTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? TuplesAnswerTableViewCell
                      answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                      answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                      answer?.textLabel?.text = """
                    Aliex
                    15
                    1943
                    (.0 "Aliex", .1 15, .2 1943)
                    """
                      answer?.textLabel?.numberOfLines = 0
                      answer?.textLabel?.lineBreakMode = .byWordWrapping
                      answer?.textLabel?.textAlignment = .center
                      answer?.textLabel?.textColor = UIColor.white
                      return answer!
        
        } else if indexPath.row == 12 {
            
            code = TuplesTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TuplesCodeTableViewCell
                                        
           code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                
                                                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "\"Aliex\"\n", attributes: [.foregroundColor: StringSyntax]))
            
             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                           
                                                           attr.append(NSAttributedString(string: "age ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                       attr.append(NSAttributedString(string: "15\n", attributes: [.foregroundColor: NumberSyntax]))
            
             attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                  
                                                                  attr.append(NSAttributedString(string: "birth ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                              attr.append(NSAttributedString(string: "1943\n", attributes: [.foregroundColor: NumberSyntax]))
                
             attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                
                                                attr.append(NSAttributedString(string: "person ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))

                                                attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                                   
                                                  attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                attr.append(NSAttributedString(string: "age", attributes: [.foregroundColor: projectSyntax]))
                               
                                                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                                        attr.append(NSAttributedString(string: "birth", attributes: [.foregroundColor: projectSyntax]))
                                                                        
                                                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        
        } else if indexPath.row == 11 {
            
            titleCell = TuplesTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TuplesTitleTableViewCell
            
            titleCell?.textLabel?.text = "If you don't want those variables or any code brings accidents or messing with the coding. You can calling those variables into the tuples to prevent it from accident."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        
        } else if indexPath.row == 10 {
            
            answer = TuplesTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? TuplesAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Aliex
            15
            1943
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        
        } else if indexPath.row == 9 {
            
            code = TuplesTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TuplesCodeTableViewCell
                                        
           code?.textLabel?.font = setFont
                  
            // MARK: Nsattributedstring
                                     let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                     attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                     
                                     attr.append(NSAttributedString(string: "person ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                     attr.append(NSAttributedString(string: "( ", attributes: [.foregroundColor: PlainSyntax]))

                                     attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))
                                     
                                     attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                     
                                       attr.append(NSAttributedString(string: "\"Aliex\"", attributes: [.foregroundColor: StringSyntax]))
                       
                                       attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                     attr.append(NSAttributedString(string: "age", attributes: [.foregroundColor: PlainSyntax]))
                                     attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                     
                                     attr.append(NSAttributedString(string: "15", attributes: [.foregroundColor: NumberSyntax]))
                                     attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                             attr.append(NSAttributedString(string: "birth", attributes: [.foregroundColor: PlainSyntax]))
                                                             attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                                             
                                                             attr.append(NSAttributedString(string: "1943", attributes: [.foregroundColor: NumberSyntax]))
                                     attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                    
             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "name\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                      
                       attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "age\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                 
                                  attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                  attr.append(NSAttributedString(string: "birth", attributes: [.foregroundColor: PlainSyntax]))
                       code?.textLabel?.attributedText = attr
                           
            
            
            
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        
        } else if indexPath.row == 8 {
            
            titleCell = TuplesTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TuplesTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "The second method is calling the values by text the keys."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        
        } else if indexPath.row == 7 {
            
            answer = TuplesTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? TuplesAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Aliex
            15
            1943
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
            
        } else if indexPath.row == 6 {
            
            code = TuplesTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TuplesCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                
                                                attr.append(NSAttributedString(string: "person ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                attr.append(NSAttributedString(string: "( ", attributes: [.foregroundColor: PlainSyntax]))

                                                attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))
                                                
                                                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                                
                                                  attr.append(NSAttributedString(string: "\"Aliex\"", attributes: [.foregroundColor: StringSyntax]))
                                  
                                                  attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                attr.append(NSAttributedString(string: "age", attributes: [.foregroundColor: PlainSyntax]))
                                                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                                
                                                attr.append(NSAttributedString(string: "15", attributes: [.foregroundColor: NumberSyntax]))
                                                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                                        attr.append(NSAttributedString(string: "birth", attributes: [.foregroundColor: PlainSyntax]))
                                                                        attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                                                        
                                                                        attr.append(NSAttributedString(string: "1943", attributes: [.foregroundColor: NumberSyntax]))
                                                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                               
                        attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                       
                        attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))
                        attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                        attr.append(NSAttributedString(string: "0\n", attributes: [.foregroundColor: NumberSyntax]))
                       
                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                 
                                  attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                     attr.append(NSAttributedString(string: "1\n", attributes: [.foregroundColor: NumberSyntax]))
                       
                       attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                            
                                             attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))
                                             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                                  code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
            
        } else if indexPath.row == 5 {
            
            titleCell = TuplesTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TuplesTitleTableViewCell
            
            titleCell?.textLabel?.text = "If you want to calling those key to executing the value? The tuples does have two methods to use calling the key. The first method is calling the first values by starting with the 0."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
            
        } else if indexPath.row == 4 {
            
            answer = TuplesTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? TuplesAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            (name "Aliex", age 15, birth: 1943)
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
            
        } else if indexPath.row == 3 {
            
            code = TuplesTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TuplesCodeTableViewCell
                                        
                code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                          let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                          attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                          
                          attr.append(NSAttributedString(string: "person ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                          attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))

                          attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: PlainSyntax]))
                          
                          attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                          
                            attr.append(NSAttributedString(string: "\"Aliex\"", attributes: [.foregroundColor: StringSyntax]))
            
                            attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                          attr.append(NSAttributedString(string: "age", attributes: [.foregroundColor: PlainSyntax]))
                          attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                          
                          attr.append(NSAttributedString(string: "15", attributes: [.foregroundColor: NumberSyntax]))
                          attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                  attr.append(NSAttributedString(string: "birth", attributes: [.foregroundColor: PlainSyntax]))
                                                  attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                                  
                                                  attr.append(NSAttributedString(string: "1943", attributes: [.foregroundColor: NumberSyntax]))
                          attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                         
            code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
            
        } else if indexPath.row == 2 {
            
            titleCell = TuplesTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TuplesTitleTableViewCell
                                                       
                                                       titleCell?.textLabel?.text = "The example of the Tuples in the Swift has shown you."
                                                         
                                                         titleCell?.textLabel?.numberOfLines = 0
                                                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                                         titleCell?.textLabel?.textAlignment = .center
                                                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                                         
                                                         return titleCell!
            
        } else if indexPath.row == 1 {
            
            code = TuplesTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? TuplesCodeTableViewCell
                                        
            code?.textLabel?.font = setFont
            

         // MARK: Nsattributedstring
                   let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                   attr.append(NSAttributedString(string: "tupl ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                   
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                   
                    attr.append(NSAttributedString(string: "( ", attributes: [.foregroundColor: PlainSyntax]))
         
                    attr.append(NSAttributedString(string: " key1 ", attributes: [.backgroundColor: dynamicBackground]))

                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
         
                   attr.append(NSAttributedString(string: " value1 ", attributes: [.backgroundColor: dynamicBackground]))
                   
                   attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

              attr.append(NSAttributedString(string: " key2 ", attributes: [.backgroundColor: dynamicBackground]))
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                   attr.append(NSAttributedString(string: " value2 ", attributes: [.backgroundColor: dynamicBackground]))
                   
                    attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                   
              attr.append(NSAttributedString(string: " key3 ", attributes: [.backgroundColor: dynamicBackground]))
          attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                   attr.append(NSAttributedString(string: " value3 ", attributes: [.backgroundColor: dynamicBackground]))
                   
                    attr.append(NSAttributedString(string: " ) ", attributes: [.foregroundColor: PlainSyntax]))
                   
                    code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
            
        } else {
          
            titleCell = TuplesTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? TuplesTitleTableViewCell
                                            
                                            titleCell?.textLabel?.text = "The Tuples are alike constant with the dictionaries, which prevents it from an accident. The Tuples do not allow you to use change, add, combine, remove, and order, too. It allows you to access the values by calling the key. The type annotation doesn't exist for tuples."
                                              
                                              titleCell?.textLabel?.numberOfLines = 0
                                              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                              titleCell?.textLabel?.textAlignment = .center
                                              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                              
                                              return titleCell!
            
        }
    }
    
    
    
}
