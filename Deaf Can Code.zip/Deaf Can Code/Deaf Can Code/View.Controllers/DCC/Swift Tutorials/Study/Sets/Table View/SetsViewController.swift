//
//  SetsViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class SetsViewController: UIViewController {
    
    @IBOutlet weak var SetsTableView: UITableView!
    @IBOutlet weak var SetVideos: WKWebView!
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        SetsTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Set"
        
        Label(IDCode: "CtqfKKV0RkM")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        SetVideos.load(URLRequest(url: url!))

    }

}


extension SetsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 23
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: SetsTitleTableViewCell!
        var code: SetsCodeTableViewCell!
        var answer: SetsAnswerTableViewCell!
        
        if indexPath.row == 22 {
            answer = SetsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SetsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            true
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 21 {
            code = SetsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SetsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
                
            // MARK: Nsattributedstring
                                                             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                             attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                             
                                                             attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                   
                                                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                                   
                                                    attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                                                             
                                                              attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                             
                                                              attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                             
                                                      attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                                                       
                                                             
                                                              attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                                             
                                                     attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                                   
                                                    attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                   
                                                   attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                   
                                                    attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                                   
                                                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                       
                                                                    
                                                                                          
                                                                               attr.append(NSAttributedString(string: "\"Geometry\"", attributes: [.foregroundColor: StringSyntax]))

                                                                                
                                                                                                
                                                                              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                                   attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                                             
                                                              attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                             
                                                             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                             
                                                              attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                                             
                                                             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                 
                                                                              
                                                                                                    
                                                                                         attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                                                          
                                                                                                          
                                                                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                                   
                                                   attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                                             
                                                              attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                             
                                                             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                             
                                                              attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                                             
                                                             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                 
                                                                              
                                                                                                    
                                                                                         attr.append(NSAttributedString(string: "\"Art\"", attributes: [.foregroundColor: StringSyntax]))

                                                                                          
                                                                                                          
                                                                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                         attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                                                        
                                                                         attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                                        
                                                                        attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                                        
                                                                         attr.append(NSAttributedString(string: "remove", attributes: [.foregroundColor: projectSyntax]))
                                                                        
                                                                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                            
                                                                                         
                                                                                                               
                                                                                                    attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                                                                     
                                                                                                                     
                                                                                                   attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                         attr.append(NSAttributedString(string: "7.\n", attributes: [.foregroundColor: counterSyntax]))
                              
                              
                                         attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                                              attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                        
                                                                        attr.append(NSAttributedString(string: "friendsClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                   attr.append(NSAttributedString(string: "Set", attributes: [.foregroundColor: projectSyntax]))
                                                                                             
                                                                                          
                                                                                             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                 
                                                                                                              attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                              
                                                                                                                                                                        
                                                                                                                                    
                                                                                                                         attr.append(NSAttributedString(string: "\"Algebra II\"", attributes: [.foregroundColor: StringSyntax]))

                               attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                          attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                              
                   attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                             attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))
                                                                                       
                                                                                attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                              
                              attr.append(NSAttributedString(string: "\"U.S History\"", attributes: [.foregroundColor: StringSyntax]))
                              
                              attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                                        
                                                                                                                                                                                  attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                              
                          
                          
                              attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                                                         attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                   
                                                                                   attr.append(NSAttributedString(string: "commonClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                              attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                                                                        
                                                                                                        attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                        
                                                                                                         attr.append(NSAttributedString(string: "union", attributes: [.foregroundColor: projectSyntax]))
                                                                                                        
                                                                                                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                            
                                                                                                                         
                                                                                                                                               
                                                                                                                                    attr.append(NSAttributedString(string: "friendsClasses", attributes: [.foregroundColor: projectSyntax]))

                                                                                                                                     
                                                                                                                                                     
                                                                                                                                   attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "9.\n", attributes: [.foregroundColor: counterSyntax]))
                   attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
                                                                         attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                   
                                                                                   attr.append(NSAttributedString(string: "roommatesClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                              attr.append(NSAttributedString(string: "Set", attributes: [.foregroundColor: projectSyntax]))
                                                                                                        
                                                                                                     
                                                                                                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                            
                                                                                                                         attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                                         
                                                                                                                                                                                   
                                                                                                                                               
                                                                                                                                    attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                          attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                     attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                                         
                              attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                        attr.append(NSAttributedString(string: "\"Foreign Languages\"", attributes: [.foregroundColor: StringSyntax]))
                                                                                                  
                                                                                           attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                         
                                         attr.append(NSAttributedString(string: "\"Music\"", attributes: [.foregroundColor: StringSyntax]))
                                         
                                         attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                                                   
                                                                                                                                                                                             attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                         
                                     
                                     
                                         attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
                                                                                    attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                              
                                                                                              attr.append(NSAttributedString(string: "commonClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                              attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                                         attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                                                                                   
                                                                                                                   attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                   
                                                                                                                    attr.append(NSAttributedString(string: "intersection", attributes: [.foregroundColor: projectSyntax]))
                                                                                                                   
                                                                                                                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                       
                                                                                                                                    
                                                                                                                                                          
                                                                                                                                               attr.append(NSAttributedString(string: "roommatesClasses", attributes: [.foregroundColor: projectSyntax]))

                                                                                                                                                
                                                                                                                                                                
                                                                                                                                              attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                   
               
            
            attr.append(NSAttributedString(string: "12.\n", attributes: [.foregroundColor: counterSyntax]))
                             attr.append(NSAttributedString(string: "13. ", attributes: [.foregroundColor: counterSyntax]))
                                                                                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                             
                                                                                             attr.append(NSAttributedString(string: "yourSecondClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                                        attr.append(NSAttributedString(string: "Set", attributes: [.foregroundColor: projectSyntax]))
                                                                                                                  
                                                                                                               
                                                                                                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                      
                                                                                                                                   attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                                                   
                                                                                                                                                                                             
                                                                                                                                                         
                                                                                                                                              attr.append(NSAttributedString(string: "\"Music\"", attributes: [.foregroundColor: StringSyntax]))

                                                    attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                               attr.append(NSAttributedString(string: "\"Graphic Design\"", attributes: [.foregroundColor: StringSyntax]))
                                     
                                                   
                                                   attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                                                             
                                                                                                                                                                                                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                                   
                                               
                                               
                                                   attr.append(NSAttributedString(string: "14. ", attributes: [.foregroundColor: counterSyntax]))
                                                                                              attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                                        
                                                                                                        attr.append(NSAttributedString(string: "roommatesSecondClass ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                                                   attr.append(NSAttributedString(string: "Set", attributes: [.foregroundColor: projectSyntax]))
                                                                                                                             
                                                                                                                                        
                                                                                  attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                    
                                                                                                                                                         attr.append(NSAttributedString(string: "\"Biology Speech\"", attributes: [.foregroundColor: projectSyntax]))

                                                                                                                                                          
                                                                                                                          attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "15. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "disjoint ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "yourSecondClasses", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "isDisjoint", attributes: [.foregroundColor: projectSyntax]))
              
            attr.append(NSAttributedString(string: "(with: ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "roommatesSecondClass", attributes: [.foregroundColor: projectSyntax]))
                                  
            attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))

                       
            
                         code?.textLabel?.attributedText = attr
            
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 20 {
            titleCell = SetsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SetsTitleTableViewCell
            
            titleCell?.textLabel?.text = "When you want to add a new classrooms in the schedule, but other best friend was preparing, too! That means you don't want to learn from his class. The isDisjoint is allowed you to check if both  schedules are different, then it'll result true otherwise, it'll result false if it was the same."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 19 {
            answer = SetsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SetsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            ["English", "Science"]
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 18 {
            code = SetsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SetsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
              // MARK: Nsattributedstring
                                                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                      
                                                      attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                            
                                             attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                            
                                             attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                                                      
                                                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                      
                                                       attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                      
                                               attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                                                
                                                      
                                                       attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                                      
                                              attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                            
                                             attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                            
                                            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                            
                                             attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                            
                                            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                
                                                             
                                                                                   
                                                                        attr.append(NSAttributedString(string: "\"Geometry\"", attributes: [.foregroundColor: StringSyntax]))

                                                                         
                                                                                         
                                                                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                                      
                                                       attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                      
                                                      attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                      
                                                       attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                                      
                                                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                          
                                                                       
                                                                                             
                                                                                  attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                                                   
                                                                                                   
                                                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                            
                                            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                                      
                                                       attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                      
                                                      attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                      
                                                       attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                                      
                                                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                          
                                                                       
                                                                                             
                                                                                  attr.append(NSAttributedString(string: "\"Art\"", attributes: [.foregroundColor: StringSyntax]))

                                                                                   
                                                                                                   
                                                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                  attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                                                 
                                                                  attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                                 
                                                                 attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                                 
                                                                  attr.append(NSAttributedString(string: "remove", attributes: [.foregroundColor: projectSyntax]))
                                                                 
                                                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                     
                                                                                  
                                                                                                        
                                                                                             attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                                                              
                                                                                                              
                                                                                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                  attr.append(NSAttributedString(string: "7.\n", attributes: [.foregroundColor: counterSyntax]))
                       
                       
                                  attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                 
                                                                 attr.append(NSAttributedString(string: "friendsClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                            attr.append(NSAttributedString(string: "Set", attributes: [.foregroundColor: projectSyntax]))
                                                                                      
                                                                                   
                                                                                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                          
                                                                                                       attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                       
                                                                                                                                                                 
                                                                                                                             
                                                                                                                  attr.append(NSAttributedString(string: "\"Algebra II\"", attributes: [.foregroundColor: StringSyntax]))

                        attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                   attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                       
            attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                      attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))
                                                                                
                                                                         attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "\"U.S History\"", attributes: [.foregroundColor: StringSyntax]))
                       
                       attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                                 
                                                                                                                                                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                       
                   
                   
                       attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                                                  attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                            
                                                                            attr.append(NSAttributedString(string: "commonClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                       attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                                                                 
                                                                                                 attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                 
                                                                                                  attr.append(NSAttributedString(string: "union", attributes: [.foregroundColor: projectSyntax]))
                                                                                                 
                                                                                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                     
                                                                                                                  
                                                                                                                                        
                                                                                                                             attr.append(NSAttributedString(string: "friendsClasses", attributes: [.foregroundColor: projectSyntax]))

                                                                                                                              
                                                                                                                                              
                                                                                                                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "9.\n", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
                                                                  attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                            
                                                                            attr.append(NSAttributedString(string: "roommatesClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                       attr.append(NSAttributedString(string: "Set", attributes: [.foregroundColor: projectSyntax]))
                                                                                                 
                                                                                              
                                                                                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                     
                                                                                                                  attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                                  
                                                                                                                                                                            
                                                                                                                                        
                                                                                                                             attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                   attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                              attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                                  
                       attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                 attr.append(NSAttributedString(string: "\"Foreign Languages\"", attributes: [.foregroundColor: StringSyntax]))
                                                                                           
                                                                                    attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "\"Music\"", attributes: [.foregroundColor: StringSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                                            
                                                                                                                                                                                      attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                  
                              
                              
                                  attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
                                                                             attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                                       
                                                                                       attr.append(NSAttributedString(string: "commonClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                                  attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                                                                            
                                                                                                            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                            
                                                                                                             attr.append(NSAttributedString(string: "intersection", attributes: [.foregroundColor: projectSyntax]))
                                                                                                            
                                                                                                            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                
                                                                                                                             
                                                                                                                                                   
                                                                                                                                        attr.append(NSAttributedString(string: "roommatesClasses", attributes: [.foregroundColor: projectSyntax]))

                                                                                                                                         
                                                                                                                                                         
                                                                                                                                       attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
        
                       
                  code?.textLabel?.attributedText = attr
                           
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 17 {
           titleCell = SetsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SetsTitleTableViewCell
            
            titleCell?.textLabel?.text = "Do you want to check if other best friend will be your classmate? The intersection will allow you to check his best friend's schedules that you will be his classmate."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 16 {
           answer = SetsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SetsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
                ["Science", "Geometry", "Art", "Algebra II", "English", "U.S History"]
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 15 {
            code = SetsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SetsCodeTableViewCell
                                        
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                           let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                           attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                 
                                  attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                  attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                    attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                                     
                                           
                                            attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                   attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                 
                                  attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                 
                                 attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                 
                                  attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                     
                                                  
                                                                        
                                                             attr.append(NSAttributedString(string: "\"Geometry\"", attributes: [.foregroundColor: StringSyntax]))

                                                              
                                                                              
                                                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                 attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                               
                                                            
                                                                                  
                                                                       attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                                        
                                                                                        
                                                                      attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                 
                                 attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                               
                                                            
                                                                                  
                                                                       attr.append(NSAttributedString(string: "\"Art\"", attributes: [.foregroundColor: StringSyntax]))

                                                                        
                                                                                        
                                                                      attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                       attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                                      
                                                       attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                      
                                                      attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                      
                                                       attr.append(NSAttributedString(string: "remove", attributes: [.foregroundColor: projectSyntax]))
                                                      
                                                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                          
                                                                       
                                                                                             
                                                                                  attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                                                   
                                                                                                   
                                                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                       attr.append(NSAttributedString(string: "7.\n", attributes: [.foregroundColor: counterSyntax]))
            
            
                       attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                      
                                                      attr.append(NSAttributedString(string: "friendsClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                 attr.append(NSAttributedString(string: "Set", attributes: [.foregroundColor: projectSyntax]))
                                                                           
                                                                        
                                                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                               
                                                                                            attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                            
                                                                                                                                                      
                                                                                                                  
                                                                                                       attr.append(NSAttributedString(string: "\"Algebra II\"", attributes: [.foregroundColor: StringSyntax]))

             attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                        attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
            
 attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                           attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))
                                                                     
                                                              attr.append(NSAttributedString(string: " , ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"U.S History\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                                                                                                      
                                                                                                                                                                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
        
        
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                 
                                                                 attr.append(NSAttributedString(string: "commonClasses ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                            attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                                                      
                                                                                      attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                                                      
                                                                                       attr.append(NSAttributedString(string: "union", attributes: [.foregroundColor: projectSyntax]))
                                                                                      
                                                                                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                                          
                                                                                                       
                                                                                                                             
                                                                                                                  attr.append(NSAttributedString(string: "friendsClasses", attributes: [.foregroundColor: projectSyntax]))

                                                                                                                   
                                                                                                                                   
                                                                                                                 attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
       code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 14 {
            titleCell = SetsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SetsTitleTableViewCell
                       
                       titleCell?.textLabel?.text = "Do you want to learn some of your best friend's schedules in your schedule? The union allows you to combine your classrooms and his classrooms."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 13 {
           answer = SetsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SetsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            false
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 12 {
            code = SetsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SetsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      
                       attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                                
                                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                
                         attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                          
                                
                                 attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                
                        attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      
                       attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                       
                                                             
                                                  attr.append(NSAttributedString(string: "\"Geometry\"", attributes: [.foregroundColor: StringSyntax]))

                                                   
                                                                   
                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                 attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                    
                                                 
                                                                       
                                                            attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                             
                                                                             
                                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                      
                      attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                 attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                    
                                                 
                                                                       
                                                            attr.append(NSAttributedString(string: "\"Art\"", attributes: [.foregroundColor: StringSyntax]))

                                                             
                                                                             
                                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "remove", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                               
                                                            
                                                                                  
                                                                       attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                                        
                                                                                        
                                                                      attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "7.\n", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "hadClass ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                                                
                                                                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                                
                                                                 attr.append(NSAttributedString(string: "contains", attributes: [.foregroundColor: projectSyntax]))
                                                                
                                                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                                                    
                                                                                 
                                                                                                       
                                                                                            attr.append(NSAttributedString(string: "\"Foreign Language\"", attributes: [.foregroundColor: StringSyntax]))

                                                                                             
                                                                                                             
                                                                                           attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                      
                                 code?.textLabel?.attributedText = attr
            
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 11 {
            titleCell = SetsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SetsTitleTableViewCell
            
            titleCell?.textLabel?.text = "Are you try to search for your favorite class to match the schedules? The contains will allows you to find one in the elements to match that element will result true otherwise false if they don't match it."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 10 {
            answer = SetsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SetsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            ["Geometry", "Art", "English"]
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 9 {
            code = SetsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SetsCodeTableViewCell
                                                   
            code?.textLabel?.font = setFont
                           
            // MARK: Nsattributedstring
                                let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                      
                       attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                                
                                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                
                         attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                          
                                
                                 attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                                
                        attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      
                       attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                       
                                                             
                                                  attr.append(NSAttributedString(string: "\"Geometry\"", attributes: [.foregroundColor: StringSyntax]))

                                                   
                                                                   
                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                 attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                    
                                                 
                                                                       
                                                            attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                             
                                                                             
                                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                      
                      attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                
                                 attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                
                                 attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                    
                                                 
                                                                       
                                                            attr.append(NSAttributedString(string: "\"Art\"", attributes: [.foregroundColor: StringSyntax]))

                                                             
                                                                             
                                                           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                            attr.append(NSAttributedString(string: "remove", attributes: [.foregroundColor: projectSyntax]))
                                           
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                                               
                                                            
                                                                                  
                                                                       attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                                        
                                                                                        
                                                                      attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))

                                 
                      
                      
                                 code?.textLabel?.attributedText = attr
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        } else if indexPath.row == 8 {
            titleCell = SetsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SetsTitleTableViewCell
            
            titleCell?.textLabel?.text = "If you want to remove a class on the schedule that you don't like? The remove will allow you to remove the element."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 7 {
            answer = SetsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SetsAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                         ["Science", "Geometry", "English", "Art"]
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 6 {
            code = SetsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SetsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
             attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                      
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                      
               attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                
                      
                       attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                      
              attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                
                             
                                                   
                                        attr.append(NSAttributedString(string: "\"Geometry\"", attributes: [.foregroundColor: StringSyntax]))

                                         
                                                         
                                       attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                      
                       attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                       
                                                             
                                                  attr.append(NSAttributedString(string: "\"Science\"", attributes: [.foregroundColor: StringSyntax]))

                                                   
                                                                   
                                                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                      
                       attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                      
                      attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                          
                                       
                                                             
                                                  attr.append(NSAttributedString(string: "\"Art\"", attributes: [.foregroundColor: StringSyntax]))

                                                   
                                                                   
                                                 attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))

            
            
                       code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 5 {
            titleCell = SetsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SetsTitleTableViewCell
            
            titleCell?.textLabel?.text = "If you want to add more classes to the schedule? The insert( ) allows you to add a new element."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 4 {
            answer = SetsTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? SetsAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            ["English"]
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 3 {
            code = SetsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SetsCodeTableViewCell
                                        
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                               let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                               attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "classrooms", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                     
                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                               
                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
                                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                               
                        attr.append(NSAttributedString(string: "\"English\"", attributes: [.foregroundColor: StringSyntax]))
                         
                               
                                attr.append(NSAttributedString(string: "] ", attributes: [.foregroundColor: PlainSyntax]))
                               
                                code?.textLabel?.attributedText = attr
                
                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                code?.textLabel?.numberOfLines = 0
                code?.textLabel?.lineBreakMode = .byWordWrapping
                code?.textLabel?.textAlignment = .left
                                      
                                        
                return code!
        } else if indexPath.row == 2 {
            titleCell = SetsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SetsTitleTableViewCell
            
            titleCell?.textLabel?.text = "Now, imagine that you are going to the office at school, and getting a schedule paper,  which class are you going in."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 1 {
            code = SetsTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? SetsCodeTableViewCell
                                                   
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "set", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
             attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                      
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       attr.append(NSAttributedString(string: "[ ", attributes: [.foregroundColor: PlainSyntax]))
                      

                      attr.append(NSAttributedString(string: " value1 ", attributes: [.backgroundColor: dynamicBackground]))
                      
                      attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: " value2 ", attributes: [.backgroundColor: dynamicBackground]))
                      
                       attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                      
                      attr.append(NSAttributedString(string: " value3 ", attributes: [.backgroundColor: dynamicBackground]))
                      
                       attr.append(NSAttributedString(string: " ] ", attributes: [.foregroundColor: PlainSyntax]))
                      
                       code?.textLabel?.attributedText = attr
                           
                           code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                           code?.textLabel?.numberOfLines = 0
                           code?.textLabel?.lineBreakMode = .byWordWrapping
                           code?.textLabel?.textAlignment = .left
                                                 
                                                   
                           return code!
        } else {
            titleCell = SetsTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? SetsTitleTableViewCell
                                 
                                 titleCell?.textLabel?.text = "The Array allows you to order these values when you store these values but does not have a key-values. The Dictionaries do have key-values, but it can't allow to order as Array does. The Set looks like constants which opposite to the Array but denied the key-values."
                                   
                                   titleCell?.textLabel?.numberOfLines = 0
                                   titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                   titleCell?.textLabel?.textAlignment = .center
                                   titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                   
                                   return titleCell!
        }
    }
    
    
    
}
