//
//  OperatorViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/26/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class OperatorViewController: UIViewController {
  
    @IBOutlet weak var Operator_Video: WKWebView!
    
    // MARK: Operator Title stored
    var OperatorTile = [
       
         // 0
         "You could see this operator sign = means the value has linked to the name values, or change the new values when you calling the name value.",
         "",
         "",
         // 1
         "You could see this operator sign == means to check if two value were equal. It means If two value matches, it will result in TRUE. If two value mismatches, it will result in FALSE.",
         "",
         "",
         // 2
         "You could see this operator sign != means to check if two values were not equal. It means If two value mismatches, it will result in TRUE. If two value matches, it will result in FALSE.",
         "",
         "",
         // 3
         "When you see this operator sign \"!\" it means not. For example, If you don't agree with the result, Then you can text this exclamation mark before the value to make this value as the opposite.",
         "",
         "",
         // 4
         " You could see this left angle bracket < mean the left value has less than the right value. For example, If right value has greater number than left value will result TRUE but number less than left value will result FALSE.",
         "",
         "",
         // 5
         "You could see this operator sign > mean the left value have greater than the right value. For example, if right value has greater number than left value will result FALSE but number less than left value will result TRUE.",
         "",
         "",
         // 6
         "You could see this operator sign <= mean less than and equal mean the left value is less than or equal to the right value.",
         "",
         "",
         // 7
         """
         You could see this operator sign >= mean greater than and equal mean the left value is greater than or equal to the right value.
         """,
         "",
         "",
         // 8
         """
         This concept shows you two things about logical operators. This double bar means "OR" in the logical operators. When you create two values in that if conditions with the logical operator to tell the condition is true otherwise if conditions is false, then it will result in else's statement.
         """,
         "",
         "",
         // 9
         "This two ampersand means \"AND\" in the logical operator.",
         "",
         "",
         // 10
         "This operator += means addition and assignment operators. For example, if you want to add that value to combine other value, or total to answer in the console.",
         "",
         "",
         // 11
         "This operator -= means subtraction and assignment operators. For example, if you want to a subtraction that value to other value to make a total answer in the console.",
         "",
         "",
         // 12
         "This operator *= means multiplication and assignment operators. For example, if you want to a multiplication that value to other value to make a total answer in the console.",
         "",
         "",
         // 13
         "This operator /= means division and assignment operators. For example, if you want to a division that value to other value to make a total answer in the console.",
         "",
         "",
         // 14
        "This operator %= means percent and assignment operators. For example, if you want to a percent that value to other value to make a total answer in the console.",
        "",
        "",
        
     ]
    
   
    @IBOutlet weak var OperatorTableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // automatic height cells which you don't need add height for each cells
        OperatorTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        // set a title
        self.navigationItem.title = "Operator"

         Label(IDCode: "yGZ_jtqfgcM")
        
        // This is allow nsattributedstring uses in the table view cells
        self.OperatorTableView.allowsSelectionDuringEditing = false
    }

    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
        
    }
    
    func Label(IDCode: String) {
        
        let url = URL(string: "https://www.youtube.com/embed/\(IDCode)")
        Operator_Video.load(URLRequest(url: url!))

    }
}

extension OperatorViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 45
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: OperatorTitleTableViewCell!
        
        var code: OperatorCodeTableViewCell!
        
        var answer: OperatorAnswerTableViewCell!
      
        // 14
        if indexPath.row == 44 {
                
           // MARK: Answer Cells
           answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                                        
           answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
           answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
           answer?.textLabel?.text = """
           2
           """
           answer?.textLabel?.numberOfLines = 0
           answer?.textLabel?.lineBreakMode = .byWordWrapping
           answer?.textLabel?.textAlignment = .center
           answer?.textLabel?.textColor = UIColor.white
           return answer!

        } else if indexPath.row == 43 {
                          
           // MARK: Code Cells
           code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                                     
         code?.textLabel?.font = setFont
                          
          
           // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                               
                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                         
                             attr.append(NSAttributedString(string: " number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                         
                                                         attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                             
                                attr.append(NSAttributedString(string: "2\n", attributes: [.foregroundColor: NumberSyntax]))
                                
                                attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                                attr.append(NSAttributedString(string: "numbers ", attributes: [.foregroundColor: projectSyntax]))
                                
                                attr.append(NSAttributedString(string: "%= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                
                                attr.append(NSAttributedString(string: "5", attributes: [.foregroundColor: NumberSyntax]))

                                                       code?.textLabel?.attributedText = attr
                                                                      
                                                       code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                       code?.textLabel?.numberOfLines = 0
                                                       code?.textLabel?.lineBreakMode = .byWordWrapping
                                                       code?.textLabel?.textAlignment = .left
                                                                      
                                                                         
                                                       return code!
            
        } else if indexPath.row == 42 {
                  
           // MARK: Title Cells
           titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
           titleCell?.textLabel?.numberOfLines = 0
           titleCell?.textLabel?.lineBreakMode = .byWordWrapping
           titleCell?.textLabel?.textAlignment = .center
           titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
           titleCell.textLabel?.text = OperatorTile[indexPath.row]
           return titleCell!
                          
        }
        // 13
       else if indexPath.row == 41 {
                          
           answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                                        
           answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
           answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
           answer?.textLabel?.text = """
           0
           """
           answer?.textLabel?.numberOfLines = 0
           answer?.textLabel?.lineBreakMode = .byWordWrapping
           answer?.textLabel?.textAlignment = .center
           answer?.textLabel?.textColor = UIColor.white
           return answer!

        } else if indexPath.row == 40{
                          
           code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                                     
    code?.textLabel?.font = setFont
                          
        
            
            
          // MARK: Nsattributedstring
           let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                    
           attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                              
                      attr.append(NSAttributedString(string: " number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                              
                                              attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                     attr.append(NSAttributedString(string: "2\n", attributes: [.foregroundColor: NumberSyntax]))
                     
                     attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                     attr.append(NSAttributedString(string: "numbers ", attributes: [.foregroundColor: projectSyntax]))
                     
                     attr.append(NSAttributedString(string: "/= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                     
                     attr.append(NSAttributedString(string: "5", attributes: [.foregroundColor: NumberSyntax]))

                                            code?.textLabel?.attributedText = attr
                                                           
                                            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                            code?.textLabel?.numberOfLines = 0
                                            code?.textLabel?.lineBreakMode = .byWordWrapping
                                            code?.textLabel?.textAlignment = .left
                                                           
                                                              
                                            return code!
            
       } else if indexPath.row == 39 {
                          
           titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
           titleCell?.textLabel?.numberOfLines = 0
           titleCell?.textLabel?.lineBreakMode = .byWordWrapping
           titleCell?.textLabel?.textAlignment = .center
           titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
           titleCell.textLabel?.text = OperatorTile[indexPath.row]
           return titleCell!
                          
                      }
            
       else if indexPath.row == 38 {
                          
       answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                                        
       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
       answer?.textLabel?.text = """
       10
       """
                          answer?.textLabel?.numberOfLines = 0
                          answer?.textLabel?.lineBreakMode = .byWordWrapping
                          answer?.textLabel?.textAlignment = .center
                          answer?.textLabel?.textColor = UIColor.white
                          return answer!

       } else if indexPath.row == 37 {
                          
                             code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                                     
             code?.textLabel?.font = setFont
                          
                          code?.textLabel?.text = """
                          1. var numbers = 2
                          2. numbers *= 5
                          """
            
            
                                    
                                   // MARK: Nsattributedstring
                                   let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                           
                                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                     
          attr.append(NSAttributedString(string: " number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                     
                                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                         
            attr.append(NSAttributedString(string: "2\n ", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            attr.append(NSAttributedString(string: "numbers ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "*= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "5", attributes: [.foregroundColor: NumberSyntax]))

                                   code?.textLabel?.attributedText = attr
                                                  
                                   code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                   code?.textLabel?.numberOfLines = 0
                                   code?.textLabel?.lineBreakMode = .byWordWrapping
                                   code?.textLabel?.textAlignment = .left
                                                  
                                                     
                                   return code!
       } else if indexPath.row == 36 {
                          
           titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
           titleCell?.textLabel?.numberOfLines = 0
           titleCell?.textLabel?.lineBreakMode = .byWordWrapping
           titleCell?.textLabel?.textAlignment = .center
           titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
           titleCell.textLabel?.text = OperatorTile[indexPath.row]
           return titleCell!
                          
                      }
        // 11
       else if indexPath.row == 35 {
                   
                   answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                                 
                   answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                   answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                   answer?.textLabel?.text = """
                   3
                   """
                   answer?.textLabel?.numberOfLines = 0
                   answer?.textLabel?.lineBreakMode = .byWordWrapping
                   answer?.textLabel?.textAlignment = .center
                   answer?.textLabel?.textColor = UIColor.white
                   return answer!

       } else if indexPath.row == 34 {
                   
                      code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                              
            code?.textLabel?.font = setFont
            
            
                   // MARK: Nsattributedstring
                   let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                           
                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                     
             attr.append(NSAttributedString(string: " number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                           
                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                           
            
            attr.append(NSAttributedString(string: "2\n", attributes: [.foregroundColor: NumberSyntax]))
            
             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "numbers ", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "-= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "5", attributes: [.foregroundColor: NumberSyntax]))
            
                   code?.textLabel?.attributedText = attr
                                  
                   code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                   code?.textLabel?.numberOfLines = 0
                   code?.textLabel?.lineBreakMode = .byWordWrapping
                   code?.textLabel?.textAlignment = .left
                                  
                                     
                   return code!
            
            
       } else if indexPath.row == 33 {
                   
           titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
           titleCell?.textLabel?.numberOfLines = 0
           titleCell?.textLabel?.lineBreakMode = .byWordWrapping
           titleCell?.textLabel?.textAlignment = .center
           titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
           titleCell.textLabel?.text = OperatorTile[indexPath.row]
       return titleCell!
                   
               }
        // 10
       if indexPath.row == 32 {
            
            answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                          
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            7

            Hello World
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!

       } else if indexPath.row == 31 {
            
               code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
       
                
            code?.textLabel?.font = setFont
        
             // MARK: Nsattributedstring
                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                      
                        attr.append(NSAttributedString(string: "// Number\n", attributes: [.foregroundColor: CommentSyntax]))
        
        attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
        
         attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                              
            attr.append(NSAttributedString(string: " number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                          
                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                          
        attr.append(NSAttributedString(string: " 2\n", attributes: [.foregroundColor: NumberSyntax]))
                        
        attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
        
        attr.append(NSAttributedString(string: "number ", attributes: [.foregroundColor: projectSyntax]))
        
        attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
        
        attr.append(NSAttributedString(string: "5\n", attributes: [.foregroundColor: NumberSyntax]))
        
         attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
        
         attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                          attr.append(NSAttributedString(string: "// String\n", attributes: [.foregroundColor: CommentSyntax]))
        
          attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
        
           attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                           attr.append(NSAttributedString(string: " str ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                        
                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                        
          
          attr.append(NSAttributedString(string: "\"Hello\"\n", attributes: [.foregroundColor: StringSyntax]))
        
         attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
        attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: projectSyntax]))
          
         attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
          attr.append(NSAttributedString(string: "\"World!\"", attributes: [.foregroundColor: StringSyntax]))
                          
                          
                        
                            code?.textLabel?.attributedText = attr
                       
                                               code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                               code?.textLabel?.numberOfLines = 0
                                               code?.textLabel?.lineBreakMode = .byWordWrapping
                                               code?.textLabel?.textAlignment = .left
                       
                          
                       return code!
       } else if indexPath.row == 30 {
            
           titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as?           OperatorTitleTableViewCell
           titleCell?.textLabel?.numberOfLines = 0
           titleCell?.textLabel?.lineBreakMode = .byWordWrapping
           titleCell?.textLabel?.textAlignment = .center
           titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
           titleCell.textLabel?.text = OperatorTile[indexPath.row]
           return titleCell!
            
       }
        // 9
        else if indexPath.row == 29 {
            
            answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                          
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            NO
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!

        } else if indexPath.row == 28 {
            
               code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                       
        
                
              code?.textLabel?.font = setFont
      
            
         
           // MARK: Nsattributedstring
                          let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                        
                          attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                           attr.append(NSAttributedString(string: " Bool ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                        
                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                        
                 
                 attr.append(NSAttributedString(string: "true\n", attributes: [.foregroundColor: KeyboardSyntax]))
                          
                          attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                          
                                 
                           attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                                                
                                          attr.append(NSAttributedString(string: " firstBool ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                        
                                                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                        
                                 attr.append(NSAttributedString(string: "false\n", attributes: [.foregroundColor: KeyboardSyntax]))
                        
                         
                         attr.append(NSAttributedString(string: "3.\n", attributes: [.foregroundColor: counterSyntax]))
                                
                 attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                       
                            attr.append(NSAttributedString(string: "if", attributes: [.foregroundColor: KeyboardSyntax]))
                                       
                                 attr.append(NSAttributedString(string: " Bool ", attributes: [.foregroundColor: projectSyntax]))
         attr.append(NSAttributedString(string: "&& ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
         attr.append(NSAttributedString(string: "firstBool ", attributes: [.foregroundColor: projectSyntax]))
                                 
                 attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                 
                 attr.append(NSAttributedString(string: "5.  ", attributes: [.foregroundColor: counterSyntax]))
                                    
                                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                           
                                     attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                 
                 attr.append(NSAttributedString(string: "\"YES\"", attributes: [.foregroundColor: StringSyntax]))
                    attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                       
                  attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                
                     attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                     
                 
                                          
                                      attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                 
                 attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                 
                         attr.append(NSAttributedString(string: "7.  ", attributes: [.foregroundColor: counterSyntax]))
                               
                                                                  attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                           attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "\"NO\"", attributes: [.foregroundColor: StringSyntax]))
                          attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                 
                  attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                           
                           attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                           
                                              
                              code?.textLabel?.attributedText = attr
                         
                                                 code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                 code?.textLabel?.numberOfLines = 0
                                                 code?.textLabel?.lineBreakMode = .byWordWrapping
                                                 code?.textLabel?.textAlignment = .left
                         
                                                 return code!
                 
            
        } else if indexPath.row == 27 {
            
            titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
            titleCell.textLabel?.text = OperatorTile[indexPath.row]
            return titleCell!
            
        }
        // 8
        else if indexPath.row == 26 {
            
            answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                          
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            YES
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!

        } else if indexPath.row == 25 {
            
               code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                       
 
                
             code?.textLabel?.font = setFont
            
       
              // MARK: Nsattributedstring
                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                               
                 attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                 attr.append(NSAttributedString(string: " Bool ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                               
                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
        attr.append(NSAttributedString(string: "true\n", attributes: [.foregroundColor: KeyboardSyntax]))
                 
                 attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                 
                        
                  attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                                       
                                attr.append(NSAttributedString(string: " firstBool ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                               
                                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                               
                        
                        attr.append(NSAttributedString(string: "false\n", attributes: [.foregroundColor: KeyboardSyntax]))
               
                
                attr.append(NSAttributedString(string: "3.\n", attributes: [.foregroundColor: counterSyntax]))
                       
        attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                              
                   attr.append(NSAttributedString(string: "if", attributes: [.foregroundColor: KeyboardSyntax]))
                              
                            attr.append(NSAttributedString(string: " Bool ", attributes: [.foregroundColor: projectSyntax]))
        
                        attr.append(NSAttributedString(string: "|| ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                        attr.append(NSAttributedString(string: "firstBool ", attributes: [.foregroundColor: projectSyntax]))
                        
        attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
        
        attr.append(NSAttributedString(string: "5.  ", attributes: [.foregroundColor: counterSyntax]))
                           
                       attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                  
                            attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
        
        attr.append(NSAttributedString(string: "\"YES\"", attributes: [.foregroundColor: StringSyntax]))
           attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
              
         attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
       
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
            
        
                                 
                             attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
                                        
        attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
        
                attr.append(NSAttributedString(string: "7.  ", attributes: [.foregroundColor: counterSyntax]))
                      
                                                         attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))
                                  attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
              
              attr.append(NSAttributedString(string: "\"NO\"", attributes: [.foregroundColor: StringSyntax]))
                 attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
        
         attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                  
                  attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                  
                                     
                     code?.textLabel?.attributedText = attr
                
                                        code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                        code?.textLabel?.numberOfLines = 0
                                        code?.textLabel?.lineBreakMode = .byWordWrapping
                                        code?.textLabel?.textAlignment = .left
                
                                        return code!
        
        } else if indexPath.row == 24 {
            
           titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
           titleCell?.textLabel?.numberOfLines = 0
           titleCell?.textLabel?.lineBreakMode = .byWordWrapping
           titleCell?.textLabel?.textAlignment = .center
           titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
           titleCell.textLabel?.text = OperatorTile[indexPath.row]
           return titleCell!
            
        }
        // 7
        else if indexPath.row == 23 {
                   
                   answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                                 
                   answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                   answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                   answer?.textLabel?.text = """
                   false

                   An example code result at below:
                   3 >= 4 means 3.01 and above are a false.
                   3 >= 3 means true.
                   3 >= 2 means 2.99 and below are a true.
                   """
                   answer?.textLabel?.numberOfLines = 0
                   answer?.textLabel?.lineBreakMode = .byWordWrapping
                   answer?.textLabel?.textAlignment = .center
                   answer?.textLabel?.textColor = UIColor.white
                   return answer!

               } else if indexPath.row == 22 {
                   
                      code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                              
                 
                       
                    code?.textLabel?.font = setFont
                
                 
                      // MARK: Nsattributedstring
                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                      
                        attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                              
                         attr.append(NSAttributedString(string: " low ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                      
                                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                      
                        
                        attr.append(NSAttributedString(string: "2\n", attributes: [.foregroundColor: NumberSyntax]))
                        
                               
                        attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                           
                       attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                                  
                            attr.append(NSAttributedString(string: " high ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                          
                                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                          
                            
                            attr.append(NSAttributedString(string: "3\n", attributes: [.foregroundColor: NumberSyntax]))
                                         
                       
                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                              
                          attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                                     
                               attr.append(NSAttributedString(string: " result ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                             
                                             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                             
                               
                               attr.append(NSAttributedString(string: "low ", attributes: [.foregroundColor: projectSyntax]))
                       attr.append(NSAttributedString(string: ">= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                       attr.append(NSAttributedString(string: "high ", attributes: [.foregroundColor: projectSyntax]))
                                            
                            code?.textLabel?.attributedText = attr
                       
                                               code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                               code?.textLabel?.numberOfLines = 0
                                               code?.textLabel?.lineBreakMode = .byWordWrapping
                                               code?.textLabel?.textAlignment = .left
                       
                                               return code!
        
               } else if indexPath.row == 21 {
                   
                   titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
                   titleCell?.textLabel?.numberOfLines = 0
                   titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                   titleCell?.textLabel?.textAlignment = .center
                   titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                   titleCell.textLabel?.text = OperatorTile[indexPath.row]
                   return titleCell!
                   
               }
        // 6
        else if indexPath.row == 20 {
            
            answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                          
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            true

            An example code result at below:
            3 <= 4 means 3.01 and above are a true.
            3 <= 3 means true.
            3 <= 2 means 2.99 and below are a false.
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!

        } else if indexPath.row == 19 {
            
               code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                       
       
               code?.textLabel?.font = setFont
          
            
           
        
        // MARK: Nsattributedstring
             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                           
             attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                   
             attr.append(NSAttributedString(string: " low ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                           
                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                           
             attr.append(NSAttributedString(string: "2\n", attributes: [.foregroundColor: NumberSyntax]))
             
                    
             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                
            attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                attr.append(NSAttributedString(string: " high ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                               
                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
                 attr.append(NSAttributedString(string: "3\n", attributes: [.foregroundColor: NumberSyntax]))
                              
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                   
               attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                          
                     attr.append(NSAttributedString(string: " result ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                    
                    attr.append(NSAttributedString(string: "low ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "<= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            attr.append(NSAttributedString(string: "high ", attributes: [.foregroundColor: projectSyntax]))
                                 
                 code?.textLabel?.attributedText = attr
            
                                    code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                    code?.textLabel?.numberOfLines = 0
                                    code?.textLabel?.lineBreakMode = .byWordWrapping
                                    code?.textLabel?.textAlignment = .left
            
               
            return code!
        
        } else if indexPath.row == 18 {
            
            titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
            titleCell.textLabel?.text = OperatorTile[indexPath.row]
            return titleCell!
            
        }
        
        // 5
        
       else  if indexPath.row == 17 {
            
            answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                          
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            false
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!

        } else if indexPath.row == 16 {
            
               code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
       
              code?.textLabel?.font = setFont
         
        
        // MARK: Nsattributedstring
             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                           
             attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                   
            attr.append(NSAttributedString(string: " low ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                           
                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                           
             attr.append(NSAttributedString(string: "2\n", attributes: [.foregroundColor: NumberSyntax]))
             
                    
             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                
            attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                       
             attr.append(NSAttributedString(string: " high ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                               
                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
                 attr.append(NSAttributedString(string: "3\n", attributes: [.foregroundColor: NumberSyntax]))
                              
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                   
               attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                          
                    attr.append(NSAttributedString(string: " result ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                    
                    attr.append(NSAttributedString(string: "low ", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "> ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            attr.append(NSAttributedString(string: "high ", attributes: [.foregroundColor: projectSyntax]))
                                 
                 code?.textLabel?.attributedText = attr
            
                                    code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                    code?.textLabel?.numberOfLines = 0
                                    code?.textLabel?.lineBreakMode = .byWordWrapping
                                    code?.textLabel?.textAlignment = .left
            
                                    return code!
        
        } else if indexPath.row == 15 {
            
            titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
            titleCell.textLabel?.text = OperatorTile[indexPath.row]
            return titleCell!
            
        }
        // 4
        
        else if indexPath.row == 14 {
                                
                                answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                                              
                                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                answer?.textLabel?.text = """
                                true
                                """
                                answer?.textLabel?.numberOfLines = 0
                                answer?.textLabel?.lineBreakMode = .byWordWrapping
                                answer?.textLabel?.textAlignment = .center
                                answer?.textLabel?.textColor = UIColor.white
                                return answer!

            } else if indexPath.row == 13 {
                                
                                   code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                                           
                                    
                              code?.textLabel?.font = setFont
        
          // MARK: Nsattributedstring
         let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                       
         attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
               
          attr.append(NSAttributedString(string: " low ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
         attr.append(NSAttributedString(string: "2\n", attributes: [.foregroundColor: NumberSyntax]))
         
                
         attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
        attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                   
              attr.append(NSAttributedString(string: " high ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                           
                           attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                           
             attr.append(NSAttributedString(string: "3\n", attributes: [.foregroundColor: NumberSyntax]))
                          
        
        attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
               
           attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                      
             
        attr.append(NSAttributedString(string: " result ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
               
               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
               
        
                attr.append(NSAttributedString(string: "low ", attributes: [.foregroundColor: projectSyntax]))
        attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
        attr.append(NSAttributedString(string: "high ", attributes: [.foregroundColor: projectSyntax]))
                             
             code?.textLabel?.attributedText = attr
        
                                code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                code?.textLabel?.numberOfLines = 0
                                code?.textLabel?.lineBreakMode = .byWordWrapping
                                code?.textLabel?.textAlignment = .left
        
                                return code!
                            } else if indexPath.row == 12 {
                                
                                titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
                                titleCell?.textLabel?.numberOfLines = 0
                                titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                titleCell?.textLabel?.textAlignment = .center
                                titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                titleCell.textLabel?.text = OperatorTile[indexPath.row]
                                return titleCell!
                                
                            }
        // 3
        
        else if indexPath.row == 11 {
                         
                         answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                                       
                         answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                         answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                         answer?.textLabel?.text = """
                         false

                         true
                         """
                         answer?.textLabel?.numberOfLines = 0
                         answer?.textLabel?.lineBreakMode = .byWordWrapping
                         answer?.textLabel?.textAlignment = .center
                         answer?.textLabel?.textColor = UIColor.white
                         return answer!

                     } else if indexPath.row == 10 {
                         
                            code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                                    
                    code?.textLabel?.font = setFont
        
         // MARK: Nsattributedstring
        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                      
        attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
              
         attr.append(NSAttributedString(string: " isBreak ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
               
               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
               
        attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: OtherDecluarationSyntax]))
        
        attr.append(NSAttributedString(string: "true\n", attributes: [.foregroundColor: KeyboardSyntax]))
                                        
        attr.append(NSAttributedString(string: "2.\n", attributes: [.foregroundColor: counterSyntax]))
           
        attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
        
       attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                  
             attr.append(NSAttributedString(string: " isRepair ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                   
                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                   
            attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "false\n", attributes: [.foregroundColor: KeyboardSyntax]))
                         
            code?.textLabel?.attributedText = attr
    
                                        
        code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
        code?.textLabel?.numberOfLines = 0
        code?.textLabel?.lineBreakMode = .byWordWrapping
        code?.textLabel?.textAlignment = .left
                                                              
        return code!
        
        
                     } else if indexPath.row == 9 {
                         
                         titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         titleCell.textLabel?.text = OperatorTile[indexPath.row]
                         return titleCell!
                         
                     }
        // 2
        
       else  if indexPath.row == 8 {
                   
                   answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                                 
                   answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                   answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                   answer?.textLabel?.text = "true"
                   answer?.textLabel?.numberOfLines = 0
                   answer?.textLabel?.lineBreakMode = .byWordWrapping
                   answer?.textLabel?.textAlignment = .center
                   answer?.textLabel?.textColor = UIColor.white
                   return answer!

               } else if indexPath.row == 7 {
                   
                      code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                              
           
                   code?.textLabel?.font = setFont
        
        
                    // MARK: Nsattributedstring
                   let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                 
                   attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                         
                    attr.append(NSAttributedString(string: " str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                          
                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                          
                   attr.append(NSAttributedString(string: "\"Hello World!\"\n", attributes: [.foregroundColor: StringSyntax]))
                   
                   attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                                   
                   attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
                         
                    attr.append(NSAttributedString(string: " str1 ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                          
                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                          
                   
                   attr.append(NSAttributedString(string: "\"Hello Playground!\"\n", attributes: [.foregroundColor: StringSyntax]))
                   
                   attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                                   
                   attr.append(NSAttributedString(string: "let", attributes: [.foregroundColor: KeyboardSyntax]))
                         
                    attr.append(NSAttributedString(string: " check ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                          
                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                          
                   
                   attr.append(NSAttributedString(string: "str", attributes: [.foregroundColor: projectSyntax]))
                   
                    attr.append(NSAttributedString(string: " != ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                   
                   attr.append(NSAttributedString(string: "str1", attributes: [.foregroundColor: projectSyntax]))
                                                   
                   code?.textLabel?.attributedText = attr
                                                   
                   code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                   code?.textLabel?.numberOfLines = 0
                   code?.textLabel?.lineBreakMode = .byWordWrapping
                   code?.textLabel?.textAlignment = .left
                                                                         
                   return code!
               } else if indexPath.row == 6 {
                   
                   titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
                   titleCell?.textLabel?.numberOfLines = 0
                   titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                   titleCell?.textLabel?.textAlignment = .center
                   titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                   titleCell.textLabel?.text = OperatorTile[indexPath.row]
                   return titleCell!
                   
               }
        // 1
         else if indexPath.row == 5 {
            
            answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                          
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = "true"
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!

        } else if indexPath.row == 4 {
            
               code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                       
             code?.textLabel?.font = setFont
        
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
        
        // MARK: Nsattributedstring
        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                      
        attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
              
        attr.append(NSAttributedString(string: " str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
        
        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
        
        
        attr.append(NSAttributedString(string: "\"Hello World!\"\n", attributes: [.foregroundColor: StringSyntax]))
        
        attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                                        
        attr.append(NSAttributedString(string: "var", attributes: [.foregroundColor: KeyboardSyntax]))
              
        attr.append(NSAttributedString(string: " str1 ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
        
        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
        
        attr.append(NSAttributedString(string: "\"Hello World!\"\n", attributes: [.foregroundColor: StringSyntax]))
        
        attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                        
        attr.append(NSAttributedString(string: "let", attributes: [.foregroundColor: KeyboardSyntax]))
              
        attr.append(NSAttributedString(string: " check ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
        
        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
        
        attr.append(NSAttributedString(string: "str", attributes: [.foregroundColor: projectSyntax]))
        
         attr.append(NSAttributedString(string: " == ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
        
        attr.append(NSAttributedString(string: "str1", attributes: [.foregroundColor: projectSyntax]))
                                        
        code?.textLabel?.attributedText = attr
                                        
        code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
        code?.textLabel?.numberOfLines = 0
        code?.textLabel?.lineBreakMode = .byWordWrapping
        code?.textLabel?.textAlignment = .left
                                                              
        return code!
        
        } else if indexPath.row == 3 {
            
            titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
            titleCell.textLabel?.text = OperatorTile[indexPath.row]
            return titleCell!
            
        }
        
        // 0
        else if indexPath.row == 2 {
            
            answer = OperatorTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? OperatorAnswerTableViewCell
                                          
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = "Hello World"
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!

        } else if indexPath.row == 1 {
            
               code = OperatorTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? OperatorCodeTableViewCell
                       
          code?.textLabel?.font = setFont
        
        // MARK: Nsattributedstring
        
        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
      
        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
        attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
         attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
        attr.append(NSAttributedString(string: "\"Hello World!\"", attributes: [.foregroundColor: StringSyntax]))
        
        code?.textLabel?.attributedText = attr
       
        code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
        code?.textLabel?.numberOfLines = 0
        code?.textLabel?.lineBreakMode = .byWordWrapping
        code?.textLabel?.textAlignment = .left
        
            return code!
        
        } else {
            
            titleCell = OperatorTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? OperatorTitleTableViewCell
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
            titleCell.textLabel?.text = OperatorTile[indexPath.row]
        
            return titleCell!
            
        }
        
    }
    
    
}
