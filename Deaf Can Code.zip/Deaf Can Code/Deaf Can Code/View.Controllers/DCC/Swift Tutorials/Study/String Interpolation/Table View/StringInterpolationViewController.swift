//
//  StringInterpolationViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/1/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class StringInterpolationViewController: UIViewController {

    @IBOutlet weak var SIVideos: WKWebView!
    @IBOutlet weak var SITableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        SITableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "String Interpolation"
        
        Label(IDCode: "Aw4G-JuQ7AE")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        SIVideos.load(URLRequest(url: url!))

    }

}


extension StringInterpolationViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 12
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: StringInterpolationTitleTableViewCell!
        var code: StringInterpolationCodeTableViewCell!
        var answer: StringInterpolationAnswerTableViewCell!
        
        if indexPath.row == 11 {
            answer = SITableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StringInterpolationAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Welcome, Daniel!
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 10 {
            code = SITableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StringInterpolationCodeTableViewCell
                                               
                                               if #available(iOS 13.0, *) {
                                               
                                                  // MARK: SF Mono for iOS 13
                                                  let sfMonoDescriptor = UIFont.systemFont(ofSize: 15).fontDescriptor.withDesign(.monospaced)
                                                  let sfMonoFont = UIFont(descriptor: sfMonoDescriptor!, size: 15)
                                                  code?.textLabel?.font = sfMonoFont
                                                  code?.textLabel?.textColor = UIColor.white
                                                                  
                                               } else {
                                                
                                                  //MARK:  menlo for older iOS
                                                  let menlo = UIFont(name: "Menlo", size: 15)
                                                  code?.textLabel?.textColor = UIColor.white
                                                  code?.textLabel?.font = menlo
                                                                  
                                               }
                                               
                                               code?.textLabel?.text = """
            1. let namePersonal = "Daniel"
            2. let peronalizedGreeting = "Welcome, \\(namePersonal)!"
            """
            
            // MARK: Nsattributedstring
                                           let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                           attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
             attr.append(NSAttributedString(string: "namePersonal ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "\"Daniel\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                               
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                      attr.append(NSAttributedString(string: "peronalizedGreeting ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                     
                      attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                     
                      attr.append(NSAttributedString(string: "\"Welcome,", attributes: [.foregroundColor: StringSyntax]))
            
             attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "namePersonal", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "!\"", attributes: [.foregroundColor: StringSyntax]))
            
                code?.textLabel?.attributedText = attr
            
                                                         code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                         code?.textLabel?.numberOfLines = 0
                                                         code?.textLabel?.lineBreakMode = .byWordWrapping
                                                         code?.textLabel?.textAlignment = .left
                                             
                                               
                                               return code!
        } else if indexPath.row == 9 {
            titleCell = SITableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StringInterpolationTitleTableViewCell
                       
                         titleCell?.textLabel?.text = "Tips: If you forgot to add something in the first code's value, then you can create string interpolation to allows you to call the first code to put that value include in the new strings."
                         
                         titleCell?.textLabel?.numberOfLines = 0
                         titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                         titleCell?.textLabel?.textAlignment = .center
                         titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
                         return titleCell!
        } else if indexPath.row == 8 {
            answer = SITableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StringInterpolationAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            8 dounts cost: $8
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 7 {
            code = SITableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StringInterpolationCodeTableViewCell
                                                          
                    code?.textLabel?.font = setFont
            
            
               // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                                 attr.append(NSAttributedString(string: "price ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "1\n", attributes: [.foregroundColor: NumberSyntax]))
            
             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
                      attr.append(NSAttributedString(string: "countDounts ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "2017\n", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
                       attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                                 attr.append(NSAttributedString(string: "priceDounts ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
              attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "countDounts", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            
                                  attr.append(NSAttributedString(string: " dounts cost: $", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                   
                    attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                     attr.append(NSAttributedString(string: "countDounts", attributes: [.foregroundColor: projectSyntax]))
                   
                    attr.append(NSAttributedString(string: " * ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                   
            
              attr.append(NSAttributedString(string: "price", attributes: [.foregroundColor: projectSyntax]))
           
                   
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                              
            code?.textLabel?.attributedText = attr
                                                                    code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                                    code?.textLabel?.numberOfLines = 0
                                                                    code?.textLabel?.lineBreakMode = .byWordWrapping
                                                                    code?.textLabel?.textAlignment = .left
                                                        
                                                          
                                                          return code!
        } else if indexPath.row == 6 {
            titleCell = SITableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StringInterpolationTitleTableViewCell
            
              titleCell?.textLabel?.text = "When you buy a donut at the Wal-Mart, Each donut costs one dollar. The string interpolation allows you to use a math operator to answer the total numbers."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 5 {
            answer = SITableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StringInterpolationAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            I graduated from Great Bend High School in 2017.
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 4 {
            code = SITableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StringInterpolationCodeTableViewCell
                                               
                code?.textLabel?.font = setFont
            
               // MARK: Nsattributedstring
                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                  attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                                 attr.append(NSAttributedString(string: "schoolName ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "\"Great Bend High School\"\n", attributes: [.foregroundColor: StringSyntax]))
            
             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
                      attr.append(NSAttributedString(string: "graduateYear ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "2017\n", attributes: [.foregroundColor: NumberSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
                       attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                       
                                 attr.append(NSAttributedString(string: "Degree ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                                  attr.append(NSAttributedString(string: "\"I graduated from ", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                   
                    attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                     attr.append(NSAttributedString(string: "schoolName", attributes: [.foregroundColor: projectSyntax]))
                   
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
            
              attr.append(NSAttributedString(string: " in ", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                   
                    attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                   
                     attr.append(NSAttributedString(string: "graduateYear", attributes: [.foregroundColor: projectSyntax]))
                   
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                              
            code?.textLabel?.attributedText = attr
                                                         code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                         code?.textLabel?.numberOfLines = 0
                                                         code?.textLabel?.lineBreakMode = .byWordWrapping
                                                         code?.textLabel?.textAlignment = .left
                                             
                                               
                                               return code!
        } else if indexPath.row == 3 {
            titleCell = SITableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StringInterpolationTitleTableViewCell
            
              titleCell?.textLabel?.text = "You can use the number in the string interpolation because it allowed to use any type include in the string."
              
              titleCell?.textLabel?.numberOfLines = 0
              titleCell?.textLabel?.lineBreakMode = .byWordWrapping
              titleCell?.textLabel?.textAlignment = .center
              titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
              
              return titleCell!
        } else if indexPath.row == 2 {
            answer = SITableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StringInterpolationAnswerTableViewCell
                                    answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                    answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            This app was created by Antonio
            """
                                    answer?.textLabel?.numberOfLines = 0
                                    answer?.textLabel?.lineBreakMode = .byWordWrapping
                                    answer?.textLabel?.textAlignment = .center
                                    answer?.textLabel?.textColor = UIColor.white
                                    return answer!
        } else if indexPath.row == 1{
            code = SITableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StringInterpolationCodeTableViewCell
                                    
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
            let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
 
           attr.append(NSAttributedString(string: "developer_Name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Antonio\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
            
                      attr.append(NSAttributedString(string: "owner_App ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                       
                       attr.append(NSAttributedString(string: "\"This app was created by ", attributes: [.foregroundColor: StringSyntax]))
                   
             attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
              attr.append(NSAttributedString(string: "developer_Name", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                 attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            code?.textLabel?.attributedText = attr
            
                                              code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                              code?.textLabel?.numberOfLines = 0
                                              code?.textLabel?.lineBreakMode = .byWordWrapping
                                              code?.textLabel?.textAlignment = .left
                                  
                                    
                                    return code!
        } else {
            
            titleCell = SITableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StringInterpolationTitleTableViewCell
                      
                        titleCell?.textLabel?.text = "You could see backslash with parenthesis is called Strings Interpolation. This Strings Interpolation looking like involve in the another string. When you create a string in the variable or constant's value to make a string interpolation to calling the first value include the new value."
                        
                        titleCell?.textLabel?.numberOfLines = 0
                        titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                        titleCell?.textLabel?.textAlignment = .center
                        titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                        
                        return titleCell!
        }
    }
    
    
    
}
