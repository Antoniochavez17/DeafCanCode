//
//  EnumerationsViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/14/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class EnumerationsViewController: UIViewController {

    @IBOutlet weak var EnumTableView: UITableView!
    @IBOutlet weak var EnumerationsVideo: WKWebView!
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        EnumTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Enumerations"
        
        Label(IDCode: "swog8FZJysU")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        EnumerationsVideo.load(URLRequest(url: url!))

    }

}


extension EnumerationsViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 22
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: EnumTitleTableViewCell!
        var code: EnumCodeTableViewCell!
        var answer: EnumAnswerTableViewCell!
        
       if indexPath.row == 21 {
            answer = EnumTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? EnumAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            50
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 20 {
            code = EnumTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? EnumCodeTableViewCell
                                                              
            code?.textLabel?.font = setFont
        
        // MARK: Nsattributedstring
                                                                         let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                                         attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                         
                                                                         attr.append(NSAttributedString(string: "textAlignment", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                         
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                    
        attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))

        attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                                                               attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                                                               
                                                               attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                               attr.append(NSAttributedString(string: "left ", attributes: [.foregroundColor: OtherDecluarationSyntax]))

        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
        attr.append(NSAttributedString(string: "20 \n", attributes: [.foregroundColor: NumberSyntax]))

                                                               attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                                                                         
                                                                         attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                                         attr.append(NSAttributedString(string: "center ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
        
                                                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                                 attr.append(NSAttributedString(string: "30 \n", attributes: [.foregroundColor: NumberSyntax]))
                                                               
                                                               attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                                                         
                                                                         attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                                         attr.append(NSAttributedString(string: "right ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                                               
        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
               attr.append(NSAttributedString(string: "40 \n", attributes: [.foregroundColor: NumberSyntax]))
                             attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                                                                                 
                                                                                 attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                                                 attr.append(NSAttributedString(string: "justify ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                             
                                                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                                                      attr.append(NSAttributedString(string: "50 \n", attributes: [.foregroundColor: NumberSyntax]))
        attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))

                                                                    
                                                                         attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                                                    
                                                     attr.append(NSAttributedString(string: "7.\n", attributes: [.foregroundColor: counterSyntax]))
                                                     attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                                    
                                                    attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                    
                                                    attr.append(NSAttributedString(string: "alignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                                     attr.append(NSAttributedString(string: "textAlignment", attributes: [.foregroundColor: projectSyntax]))
                                                    attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                                    attr.append(NSAttributedString(string: "justify\n", attributes: [.foregroundColor: projectSyntax]))
                    
                    attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                                                   
                    attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                         
                                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                    
                     attr.append(NSAttributedString(string: "alignment", attributes: [.foregroundColor: projectSyntax]))
                     attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "rawValue", attributes: [.foregroundColor: projectSyntax]))
                    
                     attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                    
                             
                                 code?.textLabel?.attributedText = attr
                    
                                      
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 19 {
            titleCell = EnumTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? EnumTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "Then, you can create assignments operator to change the values to executing if the variable has chosen one of these values."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 18 {
            answer = EnumTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? EnumAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            3
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 17 {
            code = EnumTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? EnumCodeTableViewCell
                                                              
           code?.textLabel?.font = setFont
                                        
            
                     // MARK: Nsattributedstring
                                                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                                 
                                                                 attr.append(NSAttributedString(string: "textAlignment", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                                 
            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
attr.append(NSAttributedString(string: "Int ", attributes: [.foregroundColor: projectSyntax]))

attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                                                       attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                                                       
                                                       attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                       attr.append(NSAttributedString(string: "left\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                                                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                                                                 
                                                                 attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                                 attr.append(NSAttributedString(string: "center\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                                  
                                                       
                                                       attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                                                 
                                                                 attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                                 attr.append(NSAttributedString(string: "right\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                                       
                     attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                                                                         
                                                                         attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                                         attr.append(NSAttributedString(string: "justify\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                     
                                                       attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))

                                                            
                                                                 attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                                            
                                             attr.append(NSAttributedString(string: "7.\n", attributes: [.foregroundColor: counterSyntax]))
                                             attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                            
                                            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                            
                                            attr.append(NSAttributedString(string: "alignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                             attr.append(NSAttributedString(string: "textAlignment", attributes: [.foregroundColor: projectSyntax]))
                                            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                            attr.append(NSAttributedString(string: "justify\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                                           
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "alignment", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
             attr.append(NSAttributedString(string: "rawValue", attributes: [.foregroundColor: projectSyntax]))
            
             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
                     
                         code?.textLabel?.attributedText = attr
            
                     
                                      
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
        } else if indexPath.row == 16 {
            titleCell = EnumTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? EnumTitleTableViewCell
                                                        
                                  titleCell?.textLabel?.text = "The rawValue does seem very familiar to count, which allow checking how much values do they have stored those values. The rawValue is requested to work with numbers only. It always start at 0 for the first case's value."
                                                          
                                  titleCell?.textLabel?.numberOfLines = 0
                                                          titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                                          titleCell?.textLabel?.textAlignment = .center
                                                          titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                                          
                                                          return titleCell!
        } else if indexPath.row == 15 {
            answer = EnumTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? EnumAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            justify
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!

        } else if indexPath.row == 14 {
            
            code = EnumTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? EnumCodeTableViewCell
                                                              
          code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                        
                                                        attr.append(NSAttributedString(string: "textAlignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                        attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                                              attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                                              
                                              attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                              attr.append(NSAttributedString(string: "left\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                                              attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                                                        
                                                        attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                        attr.append(NSAttributedString(string: "center\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                         
                                              
                                              attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                                        
                                                        attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                        attr.append(NSAttributedString(string: "right\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                              
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                                                                
                                                                attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                                attr.append(NSAttributedString(string: "justify\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
                                              attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))

                                                   
                                                        attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                                   
                                    attr.append(NSAttributedString(string: "7.\n", attributes: [.foregroundColor: counterSyntax]))
                                    attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                   
                                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                   
                                   attr.append(NSAttributedString(string: "alignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                                    attr.append(NSAttributedString(string: "textAlignment", attributes: [.foregroundColor: projectSyntax]))
                                   attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                                   attr.append(NSAttributedString(string: "justify", attributes: [.foregroundColor: projectSyntax]))
            
                code?.textLabel?.attributedText = attr
                                      
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
                                                              
            return code!
            
        } else if indexPath.row == 13 {
            
            titleCell = EnumTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? EnumTitleTableViewCell
                                             
            titleCell?.textLabel?.text = "If you need an update/add in the enumeration, then you can create a new case inside of the enumeration's statements."
                                               
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                               
            return titleCell!
            
        } else if indexPath.row == 12 {
            
            answer = EnumTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? EnumAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            I could use right hand to draw.
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            
            return answer!
            
        } else if indexPath.row == 11 {
            
            code = EnumTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? EnumCodeTableViewCell
                                                              
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                                  let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                                  attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                                  
                                                  attr.append(NSAttributedString(string: "textAlignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                  attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                                        attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                                        
                                        attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                        attr.append(NSAttributedString(string: "left\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                                        attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                                                  
                                                  attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                  attr.append(NSAttributedString(string: "center\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                   
                                        
                                        attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                                  
                                                  attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                                  attr.append(NSAttributedString(string: "right\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                                        
                                        attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                                             
                                                  attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                             
                              attr.append(NSAttributedString(string: "6.\n", attributes: [.foregroundColor: counterSyntax]))
                              attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                             
                             attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                             
                             attr.append(NSAttributedString(string: "alignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                              attr.append(NSAttributedString(string: "textAlignment", attributes: [.foregroundColor: projectSyntax]))
                             attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                             attr.append(NSAttributedString(string: "right\n", attributes: [.foregroundColor: projectSyntax]))
                                         
                      attr.append(NSAttributedString(string: "8. \n", attributes: [.foregroundColor: counterSyntax]))
              attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
              attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                              attr.append(NSAttributedString(string: "alignment ", attributes: [.foregroundColor: projectSyntax]))
                              attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
              attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                              attr.append(NSAttributedString(string: "right ", attributes: [.foregroundColor: projectSyntax]))
             attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"I could use right hand to draw.\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
                      
            attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                      

                                                   code?.textLabel?.attributedText = attr
                      
        
                                      
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
                                                            
                                                              
            return code!
            
        } else if indexPath.row == 10 {
            
            titleCell = EnumTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? EnumTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "You can use enumeration in the Switches, If, Else If, Else to check which the conditions have a match to the variable that calling."
                                    
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
            return titleCell!
            
        } else if indexPath.row == 9 {
            
            answer = EnumTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? EnumAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            right
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
            
        }  else if indexPath.row == 8 {
            
            code = EnumTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? EnumCodeTableViewCell
                                                              
            code?.textLabel?.font = setFont
                                        
            
            // MARK: Nsattributedstring
                                        let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                        attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                        
                                        attr.append(NSAttributedString(string: "textAlignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                        attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                              attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                              
                              attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                              attr.append(NSAttributedString(string: "left\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                              attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                                        
                                        attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                        attr.append(NSAttributedString(string: "center\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                         
                              
                              attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                        
                                        attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                        attr.append(NSAttributedString(string: "right\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                              
                              attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                                   
                                        attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                   
                    attr.append(NSAttributedString(string: "6.\n", attributes: [.foregroundColor: counterSyntax]))
                    attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                   
                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                   attr.append(NSAttributedString(string: "alignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

                    attr.append(NSAttributedString(string: "textAlignment", attributes: [.foregroundColor: projectSyntax]))
                   attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                   attr.append(NSAttributedString(string: "left\n", attributes: [.foregroundColor: projectSyntax]))
                               
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                    attr.append(NSAttributedString(string: "alignment ", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: "= .", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "right ", attributes: [.foregroundColor: projectSyntax]))
                                         code?.textLabel?.attributedText = attr
            
                          
                                      code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                      code?.textLabel?.numberOfLines = 0
                                      code?.textLabel?.lineBreakMode = .byWordWrapping
                                      code?.textLabel?.textAlignment = .left
                                                            
                                                              
                                      return code!
            
        } else if indexPath.row == 7 {
            
            titleCell = EnumTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? EnumTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "If you want to change the value that you don't like, then use assignments operator like variable does."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
            
        } else if indexPath.row == 6 {
            
            answer = EnumTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? EnumAnswerTableViewCell
                                answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                                answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                                answer?.textLabel?.text = """
                                left
                                """
                                answer?.textLabel?.numberOfLines = 0
                                answer?.textLabel?.lineBreakMode = .byWordWrapping
                                answer?.textLabel?.textAlignment = .center
                                answer?.textLabel?.textColor = UIColor.white
                                return answer!
            
        } else if indexPath.row == 5 {
            
            code = EnumTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? EnumCodeTableViewCell
                                                              
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                 let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                 
                                 attr.append(NSAttributedString(string: "textAlignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                 attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                       attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

                       
                       attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                       attr.append(NSAttributedString(string: "left\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))

                       attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                                 
                                 attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                 attr.append(NSAttributedString(string: "center\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                  
                       
                       attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                                 
                                 attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                                 attr.append(NSAttributedString(string: "right\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                       
                       attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                            
                                 attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "6.\n", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "alignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "textAlignment", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "left ", attributes: [.foregroundColor: projectSyntax]))
                       
                                  code?.textLabel?.attributedText = attr
                       
                                      
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
                                                              
            return code!
            
        } else if indexPath.row == 4 {
            
            titleCell = EnumTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? EnumTitleTableViewCell
                       
            titleCell?.textLabel?.text = "When you create a new variable called alignment to make a calling the name value to choose one of these cases to execute."
                         
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                         
            return titleCell!
            
        } else if indexPath.row == 3 {
            
            code = EnumTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? EnumCodeTableViewCell
                                                              
           code?.textLabel?.font = setFont
                                      
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "textAlignment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))

            
            attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

            attr.append(NSAttributedString(string: "left\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))

            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))

                      
                      attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                      attr.append(NSAttributedString(string: "center\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
       
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))

                      
                      attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))

                      attr.append(NSAttributedString(string: "right\n", attributes: [.foregroundColor: OtherDecluarationSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))

                 
                      attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
                       code?.textLabel?.attributedText = attr
            
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
                                                              
            return code!
            
        } else if indexPath.row == 2 {
            
            titleCell = EnumTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? EnumTitleTableViewCell
                                                        
            titleCell?.textLabel?.text = "The name value has created called textAlignment. The alignment means what does this label do right, center, or left? Now, Let create the case's value that name-value is pointing about what."
                                                          
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                                          
            return titleCell!
            
        } else if indexPath.row == 1 {
            
            code = EnumTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? EnumCodeTableViewCell
                                                                         
           code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                           let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                               
                                           attr.append(NSAttributedString(string: "enum ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
                                
                                attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: PlainSyntax]))
                       
                        attr.append(NSAttributedString(string: "2.   ", attributes: [.foregroundColor: counterSyntax]))
        
           attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                                 attr.append(NSAttributedString(string: " value ", attributes: [.backgroundColor: dynamicBackground]))
                        attr.append(NSAttributedString(string: " {\n", attributes: [.foregroundColor: CodeBackground]))
                                           attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                       
                       attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                           
                                                            
                                                 code?.textLabel?.attributedText = attr
                                                 
                                                 
        
            code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
            code?.textLabel?.numberOfLines = 0
            code?.textLabel?.lineBreakMode = .byWordWrapping
            code?.textLabel?.textAlignment = .left
                                                                       
            return code!
            
        } else  {
            
            titleCell = EnumTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? EnumTitleTableViewCell
                                             
            titleCell?.textLabel?.text = "The enumeration is very familiar to closure includes a switch. The colon is for the switch only, but it's a part of the freedom to choose those values in which means you don't have to set a limit in the statement."
                                               
            titleCell?.textLabel?.numberOfLines = 0
            titleCell?.textLabel?.lineBreakMode = .byWordWrapping
            titleCell?.textLabel?.textAlignment = .center
            titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                               
            return titleCell!
        }
    }
    
    
    
}



