//
//  StructuresViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/7/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import WebKit

class StructuresViewController: UIViewController {

    @IBOutlet weak var StructVideos: WKWebView!
    @IBOutlet weak var StructTableView: UITableView!
    
        override func viewDidLoad() {
        super.viewDidLoad()

        // automatic height cells which you don't need add height for each cells
        StructTableView.rowHeight = UITableView.automaticDimension
        
        // Remove large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = false
        
        self.navigationItem.title = "Structures"
        
        Label(IDCode: "C1LaVPhDZ5k")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // When you return back to previous will be appear large title on the navigation bar
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // Videos
    func Label(IDCode: String) {
        let url = URL(string:
            "https://www.youtube.com/embed/\(IDCode)")
        StructVideos.load(URLRequest(url: url!))

    }

}

extension StructuresViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 22
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var titleCell: StructTitleTableViewCell!
        var code: StructCodeTableViewCell!
        var answer: StructAnswerTableViewCell!
        
        if indexPath.row == 21 {
            code = StructTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StructCodeTableViewCell
                                                                                  
            code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                      attr.append(NSAttributedString(string: "struct ", attributes: [.foregroundColor: KeyboardSyntax]))
                                      
                                      attr.append(NSAttributedString(string: "User ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                      attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))

                             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                            
                            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                            
                            attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                            attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                                        
            attr.append(NSAttributedString(string: "init ", attributes: [.foregroundColor: KeyboardSyntax]))
                                       attr.append(NSAttributedString(string: "( name:", attributes: [.foregroundColor: PlainSyntax]))
                                      attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))

                                      attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))

                                  
            
                 attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "self ", attributes: [.foregroundColor: KeyboardSyntax]))
                                               attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
            
            
            attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                                               attr.append(NSAttributedString(string: "= name \n", attributes: [.foregroundColor: PlainSyntax]))
            
            
            
                 attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: " } \n", attributes: [.foregroundColor: PlainSyntax]))
                      
                      
                 attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
            
            code?.textLabel?.attributedText = attr
                                                          code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                          code?.textLabel?.numberOfLines = 0
                                                          code?.textLabel?.lineBreakMode = .byWordWrapping
                                                          code?.textLabel?.textAlignment = .left
                                                                                
                                                                                  
                                                          return code!
        } else if indexPath.row == 20 {
            titleCell = StructTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StructTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "Now, it's simple as the last concept. The initialization will have more examples in the class course."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 19 {
            answer = StructTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StructAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Creating a new username*
            @twostraws
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 18 {
            code = StructTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StructCodeTableViewCell
                                                                                  
            code?.textLabel?.font = setFont
                                                            
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "struct ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "User ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))

             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "userName", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
               attr.append(NSAttributedString(string: "init", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "() {\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: "\"Creating a new username*\"", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                            attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "username ", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
                       attr.append(NSAttributedString(string: "\"@twostraws2421\"\n", attributes: [.foregroundColor: StringSyntax]))
                       
                      
                         
            
            attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
             
             attr.append(NSAttributedString(string: "userPerson ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

             attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "User", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: "()\n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "userPerson", attributes: [.foregroundColor: projectSyntax]))

            
                       attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
           
            attr.append(NSAttributedString(string: "userName ", attributes: [.foregroundColor: projectSyntax]))

                       attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
               attr.append(NSAttributedString(string: "\"@twostraws\" ", attributes: [.foregroundColor: StringSyntax]))
            
                       code?.textLabel?.attributedText = attr
            
            
                                                          
                                                          code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                          code?.textLabel?.numberOfLines = 0
                                                          code?.textLabel?.lineBreakMode = .byWordWrapping
                                                          code?.textLabel?.textAlignment = .left
                                                                                
                                                                                  
                                                          return code!
        } else if indexPath.row == 17 {
           titleCell = StructTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StructTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "You can create an init keyboard, which it's called initialization that means the statements will refer to the properties. Make convinced you have to set the type annotations in the property, which means it's an empty value. However, you could see the empty parameters means don't accept any of the parameters, which means you could be free to make your own code in the properties."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 16 {
            answer = StructTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StructAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            @twostraws2421
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 15 {
            code = StructTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StructCodeTableViewCell
                                                                                  
             code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                                      attr.append(NSAttributedString(string: "struct ", attributes: [.foregroundColor: KeyboardSyntax]))
                                      
                                      attr.append(NSAttributedString(string: "User ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                      attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))

                             attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                            
                            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                            
                            attr.append(NSAttributedString(string: "userName", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                            attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                                       
                                       attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4. \n", attributes: [.foregroundColor: counterSyntax]))
                           
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                                       
                                       attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
                            
                                                          
                                                          attr.append(NSAttributedString(string: "userName ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                                                          attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))

            
            
            attr.append(NSAttributedString(string: "User", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"@twostraws2421\" ", attributes: [.foregroundColor: StringSyntax]))

            attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))


                      code?.textLabel?.attributedText = attr
            
                                                          code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                                          code?.textLabel?.numberOfLines = 0
                                                          code?.textLabel?.lineBreakMode = .byWordWrapping
                                                          code?.textLabel?.textAlignment = .left
                                                                                
                                                                                  
                                                          return code!
        } else if indexPath.row == 14 {
            titleCell = StructTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StructTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "Let's start basic of structures. If you don't like that username."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 13 {
          answer = StructTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StructAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Person(name: "Anonymous")
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 12 {
            code = StructTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StructCodeTableViewCell
                                                                       
          code?.textLabel?.font = setFont
            
            // MARK: Nsattributedstring
                             let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                             attr.append(NSAttributedString(string: "struct ", attributes: [.foregroundColor: KeyboardSyntax]))
                             
                             attr.append(NSAttributedString(string: "Person ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                             attr.append(NSAttributedString(string: "{ \n", attributes: [.foregroundColor: PlainSyntax]))

                    attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                   
                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                   attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                   attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))

                   attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
                   
                   attr.append(NSAttributedString(string: "3. \n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                           
                   
                      attr.append(NSAttributedString(string: "mutating func ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "makeAnonymous", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                           
                   
                   attr.append(NSAttributedString(string: "() {\n", attributes: [.foregroundColor: PlainSyntax]))

                   attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                   
                
                   attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: projectSyntax]))

                                        
                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                   
                              attr.append(NSAttributedString(string: "\"Annoymous\"\n", attributes: [.foregroundColor: StringSyntax]))
                              
                             
                                
                   
                   attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                   
                    attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))
                   attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                    attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))
                   attr.append(NSAttributedString(string: "8. \n", attributes: [.foregroundColor: counterSyntax]))
            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                   
                   attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                    
                    attr.append(NSAttributedString(string: "person ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                   
                   attr.append(NSAttributedString(string: "Person", attributes: [.foregroundColor: projectSyntax]))
                   attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
               
                   attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))

             attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "\"Paul\" ", attributes: [.foregroundColor: StringSyntax]))
                    attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
             attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))
                              attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                  
                   attr.append(NSAttributedString(string: "makeAnonymous", attributes: [.foregroundColor: projectSyntax]))

                              attr.append(NSAttributedString(string: "()\n", attributes: [.foregroundColor: PlainSyntax]))
                             
     
                   
              attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "person", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
        
            
            
            
                              code?.textLabel?.attributedText = attr
                                               
                                               code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                               code?.textLabel?.numberOfLines = 0
                                               code?.textLabel?.lineBreakMode = .byWordWrapping
                                               code?.textLabel?.textAlignment = .left
                                                                     
                                                                       
                                               return code!
        } else if indexPath.row == 11 {
            titleCell = StructTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StructTitleTableViewCell
                                                        
                                  titleCell?.textLabel?.text = "The structures are very familiar to a constant, which it's opposite to class. The structures will confuse if you're used variables or constants in the properties. If you want to change something inside of the property, then create a mutating keyboard."
                                                          
                                  titleCell?.textLabel?.numberOfLines = 0
                                                          titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                                          titleCell?.textLabel?.textAlignment = .center
                                                          titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                                          
                                                          return titleCell!
        } else if indexPath.row == 10 {
            answer = StructTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StructAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Tennis is an Olympic sport.
            Football is not an Olympic sport.
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 9 {
            code = StructTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StructCodeTableViewCell
                                                                       
          code?.textLabel?.font = setFont
                                                 
                                       
            // MARK: Nsattributedstring
                               let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                               attr.append(NSAttributedString(string: "struct ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "hobby ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                               attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                       attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                               
                     attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: "sport", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                     attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                     

                     attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
                            
                     
                     attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
                attr.append(NSAttributedString(string: "OlympicSport ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                              

                              attr.append(NSAttributedString(string: "Bool\n", attributes: [.foregroundColor: projectSyntax]))
                                     
                     
                       attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
               
                     
                     attr.append(NSAttributedString(string: "5.", attributes: [.foregroundColor: counterSyntax]))
                     
     attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            
                 attr.append(NSAttributedString(string: "OlympicStatus", attributes: [.foregroundColor: projectSyntax]))
            
            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                     
            
            attr.append(NSAttributedString(string: "String ", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                     
            
                     attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                     
            attr.append(NSAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax]))
                    
                    
                         attr.append(NSAttributedString(string: "OlympicSport", attributes: [.foregroundColor: projectSyntax]))
                    
            
                 attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "7. ", attributes: [.foregroundColor: counterSyntax]))
                             
              attr.append(NSAttributedString(string: "return ", attributes: [.foregroundColor: KeyboardSyntax]))
     
            attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
              attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                         
              attr.append(NSAttributedString(string: "sport", attributes: [.foregroundColor: projectSyntax]))

                     attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: " is an Olympic sport.\"\n", attributes: [.foregroundColor: StringSyntax]))
            
            attr.append(NSAttributedString(string: "8. ", attributes: [.foregroundColor: counterSyntax]))
                                              
          attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                            
        
            attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
                          
                        
                  
                       attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "9. ", attributes: [.foregroundColor: counterSyntax]))
                                        
                         attr.append(NSAttributedString(string: "return ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                       attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                       
                       attr.append(NSAttributedString(string: "\\", attributes: [.foregroundColor: PlainSyntax]))
                         attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                                    
                         attr.append(NSAttributedString(string: "sport", attributes: [.foregroundColor: projectSyntax]))

                                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                       attr.append(NSAttributedString(string: " is an Olympic sport.\"\n", attributes: [.foregroundColor: StringSyntax]))
                   
            attr.append(NSAttributedString(string: "10. ", attributes: [.foregroundColor: counterSyntax]))
                                              
            attr.append(NSAttributedString(string: " } \n", attributes: [.foregroundColor: PlainSyntax]))
            attr.append(NSAttributedString(string: "11. ", attributes: [.foregroundColor: counterSyntax]))
                                              
            attr.append(NSAttributedString(string: " }\n", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "12. ", attributes: [.foregroundColor: counterSyntax]))
                                              
            attr.append(NSAttributedString(string: "} \n", attributes: [.foregroundColor: PlainSyntax]))

                                              
              attr.append(NSAttributedString(string: "13. \n", attributes: [.foregroundColor: counterSyntax]))
             attr.append(NSAttributedString(string: "14. ", attributes: [.foregroundColor: counterSyntax]))
                     attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: "favoriteHobby ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))


                     attr.append(NSAttributedString(string: "hobby", attributes: [.foregroundColor: projectSyntax]))

                                          
                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                     
                     
                     attr.append(NSAttributedString(string: "sport: ", attributes: [.foregroundColor: PlainSyntax]))

                              
                               

                               attr.append(NSAttributedString(string: "\"Tennis\"", attributes: [.foregroundColor: StringSyntax]))
                                      
                      attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "OlympicSport: ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "true", attributes: [.foregroundColor: KeyboardSyntax]))

                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
            
                 attr.append(NSAttributedString(string: "15. ", attributes: [.foregroundColor: counterSyntax]))
            
                     attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: "favoriteSecondHobby ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))


                     attr.append(NSAttributedString(string: "hobby", attributes: [.foregroundColor: projectSyntax]))

                                          
                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                     
                     
                     attr.append(NSAttributedString(string: "sport: ", attributes: [.foregroundColor: PlainSyntax]))

                              
                               

                               attr.append(NSAttributedString(string: "\"Football\"", attributes: [.foregroundColor: StringSyntax]))
                                      
                      attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "OlympicSport: ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "false", attributes: [.foregroundColor: KeyboardSyntax]))

                                        attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))

                                code?.textLabel?.attributedText = attr
            
                                               code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                               code?.textLabel?.numberOfLines = 0
                                               code?.textLabel?.lineBreakMode = .byWordWrapping
                                               code?.textLabel?.textAlignment = .left
                                                                     
                                                                       
                                               return code!
        } else if indexPath.row == 8 {
            titleCell = StructTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StructTitleTableViewCell
                                             
                       titleCell?.textLabel?.text = "Let's create a new variable called OlympicSport to set a boolean in the type annotations to check if the sport is Olympic or not."
                                               
                       titleCell?.textLabel?.numberOfLines = 0
                                               titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                               titleCell?.textLabel?.textAlignment = .center
                                               titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                               
                                               return titleCell!
        } else if indexPath.row == 7 {
            answer = StructTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StructAnswerTableViewCell
                       answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
                       answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
                       answer?.textLabel?.text = """
                       Football
                       """
                       answer?.textLabel?.numberOfLines = 0
                       answer?.textLabel?.lineBreakMode = .byWordWrapping
                       answer?.textLabel?.textAlignment = .center
                       answer?.textLabel?.textColor = UIColor.white
                       return answer!
        } else if indexPath.row == 6 {
           code = StructTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StructCodeTableViewCell
                                                                       
           code?.textLabel?.font = setFont
                              
            // MARK: Nsattributedstring
                               let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                               attr.append(NSAttributedString(string: "struct ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "hobby ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                               attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

                       attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                               
                     attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: "sport", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                     attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                     

                     attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
                            
                     
                     attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                     
                     
                      attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                     
                     attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
                     
                     attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
                     
                     attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                     
                     attr.append(NSAttributedString(string: "favoriteHobby ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                     attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))


                     attr.append(NSAttributedString(string: "hobby", attributes: [.foregroundColor: projectSyntax]))

                                          
                                 attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                     
                     
                     attr.append(NSAttributedString(string: "sport", attributes: [.foregroundColor: PlainSyntax]))

                               attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                               

                               attr.append(NSAttributedString(string: "\"Tennis\"", attributes: [.foregroundColor: StringSyntax]))
                                      
                      attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
                     
            attr.append(NSAttributedString(string: "favoriteHobby", attributes: [.foregroundColor: projectSyntax]))
            attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))

            attr.append(NSAttributedString(string: "sport ", attributes: [.foregroundColor: projectSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "\"Football\"", attributes: [.foregroundColor: StringSyntax]))



                                code?.textLabel?.attributedText = attr

            
            
                                               code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                               code?.textLabel?.numberOfLines = 0
                                               code?.textLabel?.lineBreakMode = .byWordWrapping
                                               code?.textLabel?.textAlignment = .left
                                                                     
                                                                       
                                               return code!
        } else if indexPath.row == 5 {
            titleCell = StructTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StructTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "If you don't like Tennis, then you can change by use assignment operator like variables does."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 4 {
            answer = StructTableView.dequeueReusableCell(withIdentifier: "AnswerCells") as? StructAnswerTableViewCell
            answer?.textLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
            answer?.backgroundColor =  #colorLiteral(red: 0.1561646461, green: 0.1638575494, blue: 0.2159330845, alpha: 1)
            answer?.textLabel?.text = """
            Tennis
            """
            answer?.textLabel?.numberOfLines = 0
            answer?.textLabel?.lineBreakMode = .byWordWrapping
            answer?.textLabel?.textAlignment = .center
            answer?.textLabel?.textColor = UIColor.white
            return answer!
        } else if indexPath.row == 3 {
            code = StructTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StructCodeTableViewCell
                                                                       
            code?.textLabel?.font = setFont
                                  
            
            // MARK: Nsattributedstring
                      let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])

                      attr.append(NSAttributedString(string: "struct ", attributes: [.foregroundColor: KeyboardSyntax]))
                      
                      attr.append(NSAttributedString(string: "hobby ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                      attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))

              attr.append(NSAttributedString(string: "2. ", attributes: [.foregroundColor: counterSyntax]))
                      
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "sport", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
            

            attr.append(NSAttributedString(string: "String\n", attributes: [.foregroundColor: projectSyntax]))
                   
            
            attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
            
            
             attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
            
            attr.append(NSAttributedString(string: "4.\n", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "5. ", attributes: [.foregroundColor: counterSyntax]))
            
            attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
            
            attr.append(NSAttributedString(string: "favoriteHobby ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

            attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))


            attr.append(NSAttributedString(string: "hobby", attributes: [.foregroundColor: projectSyntax]))

                                 
                        attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
            
            
            attr.append(NSAttributedString(string: "sport", attributes: [.foregroundColor: PlainSyntax]))

                      attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                      

                      attr.append(NSAttributedString(string: "\"Tennis\"", attributes: [.foregroundColor: StringSyntax]))
                             
             attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
            
        
                       code?.textLabel?.attributedText = attr

            
            
                                               code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                               code?.textLabel?.numberOfLines = 0
                                               code?.textLabel?.lineBreakMode = .byWordWrapping
                                               code?.textLabel?.textAlignment = .left
                                                                     
                                                                       
                                               return code!
        } else if indexPath.row == 2 {
            titleCell = StructTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StructTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "Let create a new variable called sport with the type annotation in the properties. You can call the structures which seem familiar to functions does."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        } else if indexPath.row == 1 {
            code = StructTableView.dequeueReusableCell(withIdentifier: "CodeCells") as? StructCodeTableViewCell
                                                                       
         code?.textLabel?.font = setFont
            
            
            // MARK: Nsattributedstring
                                               let attr = NSMutableAttributedString(string: "1. ", attributes: [.foregroundColor: counterSyntax])
                                                                                                                                   
                                               attr.append(NSAttributedString(string: "struct ", attributes: [.foregroundColor: KeyboardSyntax]))
                                    
                                    attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
                                   
                                    attr.append(NSAttributedString(string: " { \n", attributes: [.foregroundColor: PlainSyntax]))
                      
                     
                            attr.append(NSAttributedString(string: "2.    ", attributes: [.foregroundColor: counterSyntax]))
                                    
                                     attr.append(NSAttributedString(string: " properties ", attributes: [.backgroundColor: dynamicBackground]))
                            
                    attr.append(NSAttributedString(string: "d\n", attributes: [.foregroundColor: CodeBackground]))
            
                                               attr.append(NSAttributedString(string: "3. ", attributes: [.foregroundColor: counterSyntax]))
                           
            attr.append(NSAttributedString(string: "init ", attributes: [.foregroundColor: KeyboardSyntax]))
                                            
                           attr.append(NSAttributedString(string: "( ", attributes: [.foregroundColor: PlainSyntax]))
            
            
                                       attr.append(NSAttributedString(string: " parameter ", attributes: [.backgroundColor: dynamicBackground]))
            
            attr.append(NSAttributedString(string: ") {\n", attributes: [.foregroundColor: PlainSyntax]))
                   
            
                                               attr.append(NSAttributedString(string: "4. ", attributes: [.foregroundColor: counterSyntax]))
                                          
               attr.append(NSAttributedString(string: " statements ", attributes: [.backgroundColor: dynamicBackground]))
                                                             
                     attr.append(NSAttributedString(string: "d\n", attributes: [.foregroundColor: CodeBackground]))
            
                        attr.append(NSAttributedString(string: "5.    ", attributes: [.foregroundColor: counterSyntax]))
            
             attr.append(NSAttributedString(string: "}\n", attributes: [.foregroundColor: PlainSyntax]))
                        attr.append(NSAttributedString(string: "6. ", attributes: [.foregroundColor: counterSyntax]))
            
                attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
            
                                    code?.textLabel?.attributedText = attr
                         
                                               
                                               code?.backgroundColor =  #colorLiteral(red: 0.1307941079, green: 0.1277202666, blue: 0.1972439587, alpha: 1)
                                               code?.textLabel?.numberOfLines = 0
                                               code?.textLabel?.lineBreakMode = .byWordWrapping
                                               code?.textLabel?.textAlignment = .left
                                                                     
                                                                       
                                               return code!
        } else  {
            titleCell = StructTableView.dequeueReusableCell(withIdentifier: "TitleCells") as? StructTitleTableViewCell
                                  
            titleCell?.textLabel?.text = "The structures use properties like stored the object, values, and more things. The initialization does have a parameter, which distinguishes the property between parameters. The statements use the self keyboard that allows referring to value from the property."
                                    
            titleCell?.textLabel?.numberOfLines = 0
                                    titleCell?.textLabel?.lineBreakMode = .byWordWrapping
                                    titleCell?.textLabel?.textAlignment = .center
                                    titleCell?.textLabel?.textColor =  #colorLiteral(red: 0.4341666102, green: 0.4427772462, blue: 0.4775785804, alpha: 1)
                                    
                                    return titleCell!
        }
    }
    
    

    
    
}
