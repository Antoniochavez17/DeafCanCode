//
//  QuizViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 9/24/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class QuizViewController: UIViewController {

    // Question Counter
    @IBOutlet weak var QuestionCounter: UILabel!
    
    // Score Numbers 0 - 100
    @IBOutlet weak var ScoreCounter: UILabel!
    
    // Processing view
    @IBOutlet weak var ProcessingView: UIView!

    
    // question Label
    @IBOutlet weak var QuestionLabel: UILabel!
    
    // Answer  Button
    @IBOutlet weak var Button_One: UIButton!
    @IBOutlet weak var Button_Two: UIButton!
    @IBOutlet weak var Button_Three: UIButton!
    @IBOutlet weak var Button_Four: UIButton!
    

    let allQuestion = questionStored()
    var questionNumber: Int = 0
    var score: Int = 0
    var selectedAnswer: Int = 0
    
    
    override func viewDidAppear(_ animated: Bool) {
      
    }
    // function allows new question
    

    override func viewDidLoad() {
        super.viewDidLoad()
     updateQuestion()
     updateUI()
       
    }
    
    @IBAction func AnswerPressed(_ sender: UIButton) {
        /*
        if sender.tag == 1 {
            print("Remove a new value")
        } else if sender.tag == 2 {
            print("Change a new value")
        } else if sender.tag == 3 {
            print("Create a new value")
        } else {
            print("Add a new values")
        }
        */
        
        
        if sender.tag == selectedAnswer {
            
      let alert = UIAlertController(title: "Correct Answer!" , message: "Bingo! 1 increases your score!", preferredStyle: .alert)
          
            
            present(alert, animated: true) {
                sleep(3)
                alert.dismiss(animated: true)
            }
            
            
        print("Correct")
        score += 1
            
            
           
        } else {
        
            let alert = UIAlertController(title: "Incorrect Answer!" , message: "Your score will not increase.", preferredStyle: .alert)
            
              
              present(alert, animated: true) {
                  sleep(3)
                  alert.dismiss(animated: true)
              }
            
             print("Incorrect")
            
        }
        questionNumber += 1
        updateQuestion()
    }
    
    func updateQuestion() {
        
        if questionNumber <= allQuestion.questionList.count - 1 {
            QuestionLabel.text = allQuestion.questionList[questionNumber].question
        Button_One.setTitle(allQuestion.questionList[questionNumber].buttonOne, for: UIControl.State.normal)
        Button_Two.setTitle(allQuestion.questionList[questionNumber].buttonTwo, for: UIControl.State.normal)
        Button_Three.setTitle(allQuestion.questionList[questionNumber].buttonThree, for: UIControl.State.normal)
        Button_Four.setTitle(allQuestion.questionList[questionNumber].buttonFour, for: UIControl.State.normal)
            
            selectedAnswer = allQuestion.questionList[questionNumber].correctAnswer
            
        } else {
            let alert = UIAlertController(title: "Quiz Over" , message: "Your score was \(score) out of \(allQuestion.questionList.count) scores! Do you want to start over?", preferredStyle: .alert)
            let restartAction = UIAlertAction(title: "Restart", style: .default, handler: {action in self.restartQuiz()})
            alert.addAction(restartAction)
            present(alert, animated: true, completion: nil)
            
            
        }
        updateUI()
        
    }
    
    func updateUI() {
        ScoreCounter.text = "Score:\(score)"
        QuestionCounter.text = "\(questionNumber + 1)/\(allQuestion.questionList.count)"
        ProcessingView.frame.size.width = (view.frame.size.width / CGFloat(allQuestion.questionList.count)) * CGFloat(questionNumber + 1)
        
        
    }
    
    func restartQuiz() {
         score = 0
        questionNumber = 0
        updateQuestion()
       
    }
    
    

}
