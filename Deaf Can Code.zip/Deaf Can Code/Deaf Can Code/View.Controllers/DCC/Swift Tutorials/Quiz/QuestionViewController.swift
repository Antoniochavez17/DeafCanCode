//
//  QuestionViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 9/25/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import Foundation

class Question {
    
    
    // lesson 1
    
    let question: String
    let buttonOne: String
    let buttonTwo: String
    let buttonThree: String
    let buttonFour: String
    
    let correctAnswer: Int
    
    
    init(questionText: String, ChoiceA: String, ChoiceB: String, ChoiceC: String, ChoiceD: String, Answer: Int) {
       // Question Label
        question = questionText
        // Button
         buttonOne = ChoiceA
         buttonTwo = ChoiceB
         buttonThree = ChoiceC
         buttonFour = ChoiceD
        
        correctAnswer = Answer
        
    }
    

}

