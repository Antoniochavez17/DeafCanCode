//
//  questionStored.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 9/25/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import Foundation


class questionStored {
    
    var questionList = [Question]()
    
    init() {
        
        // Quiz exampled
        /*
         questionText stand for question label
         choiceA,B,C,D is for button to choose answer
         Answer is choose one UIbutton
         
        */
        // MARK: Quiz 1
        questionList.append(Question(questionText: "What is the definition of == operator?", ChoiceA: "Change", ChoiceB: "Combine", ChoiceC: "Equal", ChoiceD: "Remove", Answer: 2))
            
        
        // MARK: Quiz 2
        questionList.append(Question(questionText: "What is the definition of = operator?", ChoiceA: "Remove", ChoiceB: "Assignment", ChoiceC: "Additon", ChoiceD: "Combine", Answer: 4))
        
        
        // MARK: Quiz 3
        questionList.append(Question(questionText: "What is the definition of ! operator? ", ChoiceA: "Accept", ChoiceB: "Remove", ChoiceC: "Stop", ChoiceD: "Not", Answer: 1))
        
        
        // MARK: Quiz 4
        questionList.append(Question(questionText: "What is the definition of string interpolation?", ChoiceA: "Remove", ChoiceB: "Include", ChoiceC: "Even", ChoiceD: "Text", Answer: 4))
      
        
        // MARK: Quiz 5
        questionList.append(Question(questionText: "What is the definition of if?", ChoiceA: "False condition", ChoiceB: "Combine condition", ChoiceC: "True condition", ChoiceD: "Change condition", Answer: 2))
      
        
        // MARK: Quiz 6
        questionList.append(Question(questionText: "What is the definition of Int?", ChoiceA: "Number without colon", ChoiceB: "Number without asterisk", ChoiceC: "Number without period", ChoiceD: "Number without degree", Answer: 2))
        
        
        // MARK: Quiz 7
        questionList.append(Question(questionText: "What is the definition of constant?", ChoiceA: "Change" , ChoiceB: "Not of above", ChoiceC: "Check", ChoiceD: "Combine", Answer: 4))

        
        // MARK: Quiz 8
        questionList.append(Question(questionText: "What is the definition of boolean?", ChoiceA: "Addition and subtraction", ChoiceB: "Combine and remove", ChoiceC: "True and false", ChoiceD: "Allow and disallow", Answer: 2))

        
        // MARK: Quiz 9
        questionList.append(Question(questionText: "What is the definition of loop?", ChoiceA: "Stop", ChoiceB: "None of Above", ChoiceC: "Quit", ChoiceD: "repeat", Answer: 1))
       
        
        // MARK: Quiz 10
        questionList.append(Question(questionText: "What is the definition of string?", ChoiceA: "Text number", ChoiceB: "All of Above", ChoiceC: "Text symbol", ChoiceD: "Text sentence", Answer: 4))
       
        
        // MARK: Quiz 11
        questionList.append(Question(questionText: "What is the definition of variable?", ChoiceA: "Change" , ChoiceB: "All of above", ChoiceC: "Check", ChoiceD: "Combine", Answer: 4))
        
        
        // MARK: Quiz 12
        questionList.append(Question(questionText: "What does answer Aliex in the variable?", ChoiceA: "var name = \"Aliex\"", ChoiceB: "var name = Aliex", ChoiceC: "var name = \"(Aliex)\"", ChoiceD: "var name = \'Aliex\'", Answer: 3))
           
        // MARK: Quiz 13
        questionList.append(Question(questionText: "What is the definition of appends?", ChoiceA: "Add", ChoiceB: "Combine", ChoiceC: "Change", ChoiceD: "Remove", Answer: 3))
        
        // MARK: Quiz 14
        questionList.append(Question(questionText: "What is the definition of printing?", ChoiceA: "Execute on console", ChoiceB: "Execute on playground editor panel", ChoiceC: "Execute on debug", ChoiceD: "All of above", Answer: 3))
        
        // MARK: Quiz 15
               questionList.append(Question(questionText: "What is the definition of sorted?", ChoiceA: "Alphabetical change", ChoiceB: "Alphabetical order", ChoiceC: "Alphabetical remove", ChoiceD: "Alphabetical combine", Answer: 4))
        
        // MARK: Quiz 16
        questionList.append(Question(questionText: "What is number to call first item in Array?", ChoiceA: "3", ChoiceB: "0", ChoiceC: "1", ChoiceD: "4", Answer: 4))
        
        // MARK: Quiz 17
        questionList.append(Question(questionText: "Which code create a dictionaries?", ChoiceA: "var name = [1.\"Aliex\", 2.\"ALan\"]", ChoiceB: "var name = (1.\"Aliex\", 2.\"ALan\")", ChoiceC: "var name = ([1.\"Aliex\", 2.\"ALan\"])", ChoiceD: "var name = [\"Aliex\", \"ALan\"]", Answer: 3))
        
        // MARK: Quiz 18
       questionList.append(Question(questionText: "Which code creates a type annotation?", ChoiceA: "var name = \"Alan\"", ChoiceB: "var name: \"Alan\"", ChoiceC: "var name = String()", ChoiceD: "var name: String = \"Alan\"", Answer: 1))
        
        // MARK: Quiz 19
        questionList.append(Question(questionText: "What does switch allow you use in Swift?", ChoiceA: "Colon", ChoiceB: "All of above", ChoiceC: "Thrice period", ChoiceD: "Comma", Answer: 4))
        
        // MARK: Quiz 20
       questionList.append(Question(questionText: "What is the definition of tuples?", ChoiceA: "Change", ChoiceB: "None of above", ChoiceC: "Remove", ChoiceD: "Combine", Answer: 4))
        
        // MARK: Quiz 21
       questionList.append(Question(questionText: "What is the definition of else?", ChoiceA: "False condition", ChoiceB: "Combine condition", ChoiceC: "True condition", ChoiceD: "Catch condition", Answer: 3))
        
        // MARK: Quiz 22
        questionList.append(Question(questionText: "What is the definition of else if?", ChoiceA: "Second condition", ChoiceB: "Fake condition", ChoiceC: "True Condition", ChoiceD: "Combine Condition", Answer: 3))
        
        // MARK: Quiz 23
       questionList.append(Question(questionText: "Which code create a comment?", ChoiceA: "\\", ChoiceB: "All of above", ChoiceC: "//", ChoiceD: "/*", Answer: 2))
        
        // MARK: Quiz 24
        questionList.append(Question(questionText: "What is the definition of <?", ChoiceA: "Greater than", ChoiceB: "Less than", ChoiceC: "Equal", ChoiceD: "Not equal", Answer: 4))
        
        // MARK: Quiz 25
       questionList.append(Question(questionText: "What is the definition of >=?", ChoiceA: "Less than and equal", ChoiceB: "Equal", ChoiceC: "Greater than and equal", ChoiceD: "Not equal", Answer: 2))
        
        // MARK: Quiz 26
        questionList.append(Question(questionText: "What is the definition of &&?", ChoiceA: "And", ChoiceB: "Not", ChoiceC: "Combine", ChoiceD: "Change", Answer: 3))
        
        // MARK: Quiz 27
        questionList.append(Question(questionText: "What is the definition of +=?", ChoiceA: "Addition and assignment", ChoiceB: "Subtraction and assignment", ChoiceC: "Division and assignment", ChoiceD: "Multiplication and assignment", Answer: 3))
        
        // MARK: Quiz 28
        questionList.append(Question(questionText: "What is the definition of !=?", ChoiceA: "Not Equal", ChoiceB: "Equal", ChoiceC: "Change", ChoiceD: "Remove", Answer: 3))
        
        // MARK: Quiz 29
       questionList.append(Question(questionText: "Which numbers that based on the Int8.max?", ChoiceA: "127", ChoiceB: "294", ChoiceC: "-127", ChoiceD: "-943", Answer: 3))
        
        // MARK: Quiz 30
        questionList.append(Question(questionText: "What is the definition of Double?", ChoiceA: "Number with colon", ChoiceB: "Number with asterisk", ChoiceC: "Number with period", ChoiceD: "Number with degree", Answer: 2))
        
        // MARK: Quiz 31
        questionList.append(Question(questionText: "What is the definition of /*?", ChoiceA: "multi-lines comments", ChoiceB: "multi-lines string", ChoiceC: "multi-lines number", ChoiceD: "multi-lines booleans", Answer: 3))
        
        // MARK: Quiz 32
        questionList.append(Question(questionText: "Which code create a Array?", ChoiceA: "var drink = [\"sola\", \"water\"]", ChoiceB: "var drink = ([\"sola\", \"water\"])", ChoiceC: "var drink = (\"sola\", \"water\")", ChoiceD: "var drink = [1:\"sola\", 2:\"water\"]", Answer: 3))
        
        // MARK: Quiz 33
        questionList.append(Question(questionText: "Which code create a Tuples?", ChoiceA: "var drink = [\"sola\", \"water\"]", ChoiceB: "var drink = [1:\"sola\", 2:\"water\"]", ChoiceC: "var drink = (\"sola\", \"water\")", ChoiceD: "var drink = (1:\"sola\", 2:\"water\")", Answer: 1))
        
        // MARK: Quiz 34
        questionList.append(Question(questionText: "What is the definition of ??", ChoiceA: "nil", ChoiceB: "true", ChoiceC: "crash", ChoiceD: "warning", Answer: 3))
        
        // MARK: Quiz 35
        questionList.append(Question(questionText: "What is the definition of !?", ChoiceA: "throw", ChoiceB: "unwrapped", ChoiceC: "sleep", ChoiceD: "alert", Answer: 4))
        
        // MARK: Quiz 36
        questionList.append(Question(questionText: "What is the definition of default?", ChoiceA: "Not exist", ChoiceB: "remove", ChoiceC: "check", ChoiceD: "combine", Answer: 3))
        
  
        
    }
    
}
