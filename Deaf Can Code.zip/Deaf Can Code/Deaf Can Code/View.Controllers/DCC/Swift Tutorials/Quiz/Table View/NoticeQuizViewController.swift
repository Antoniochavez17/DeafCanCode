//
//  NoticeQuizViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/24/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class NoticeQuizViewController: UIViewController {

    var titleLBL = ["These 28 Swift Tutorials will introduce Swift in a fun and interesting way. Share your results on Twitter by tagging @DeafCanCode", "GO!"]
    
    
     var StoryboardID = [String]()
    
    
    @IBOutlet weak var noticeTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         StoryboardID = ["", "SwiftQuiz"]
        
        self.navigationItem.title = "Quiz"
        
        
 self.noticeTV.backgroundColor = #colorLiteral(red: 0.0941023156, green: 0.09412650019, blue: 0.09410078079, alpha: 1)
     
    }
    

   

}

extension NoticeQuizViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    
        if indexPath.row == 1 {
            
            return 55
            
        } else {
    
            return 150
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleLBL.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         
        let sectionCells = noticeTV.dequeueReusableCell(withIdentifier: "section")
        
        if indexPath.row == 1 {
            
            sectionCells?.textLabel?.text = titleLBL[indexPath.row]
            
             sectionCells?.textLabel!.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
      
            sectionCells?.textLabel!.textAlignment = .center
           
            sectionCells?.contentView.backgroundColor = #colorLiteral(red: 0.1564497352, green: 0.1637369096, blue: 0.2134993672, alpha: 1)
        
        sectionCells?.isUserInteractionEnabled = true
            return sectionCells!
        } else {
            sectionCells?.textLabel?.text = titleLBL[indexPath.row]
            
            sectionCells?.contentView.backgroundColor = #colorLiteral(red: 0.0941023156, green: 0.09412650019, blue: 0.09410078079, alpha: 1)
            sectionCells?.textLabel!.textColor = #colorLiteral(red: 0.4588235294, green: 0.462745098, blue: 0.4901960784, alpha: 1)
                       sectionCells?.textLabel!.numberOfLines = 0
                       sectionCells?.textLabel!.lineBreakMode = .byWordWrapping
                       sectionCells?.textLabel!.textAlignment = .center
                       
                       sectionCells?.isUserInteractionEnabled = false
            return sectionCells!
        }
        
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                   
                      
           let vcName = StoryboardID[indexPath.row]
                      
           let Swift = storyboard?.instantiateViewController(withIdentifier: vcName)
                     
                   
           self.navigationController?.pushViewController(Swift!, animated: true)
                      
           }

    
}
