//
//  ObjectiveCViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 2/8/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class ObjectiveCViewController: UIViewController {

    @IBOutlet weak var ObjectiveCTableView: UITableView!
    
    let optionalTitle = ["", "Study", "Quiz"]
    let optionImage = ["", "Untitled 6-13", "Untitled 6-6"]
    let avaiableIcon = ["", "Untitled 7", "Untitled 7"]
    
    override func viewWillAppear(_ animated: Bool) {
          super.viewWillAppear(animated)
      
      
         let app = UINavigationBarAppearance()
                app.configureWithTransparentBackground()
               
              app.shadowImage = UIImage()
              self.navigationController?.navigationBar.standardAppearance = app
                self.navigationController?.navigationBar.scrollEdgeAppearance = app
                self.navigationController?.navigationBar.compactAppearance = app
                 
          
      }

      override func viewWillDisappear(_ animated: Bool) {
          super.viewWillDisappear(animated)
          
              
    
     let app = UINavigationBarAppearance()
           
           let navigationBar = self.navigationController?.navigationBar
            
      app.backgroundColor = .clear
                app.configureWithOpaqueBackground()
                
                
            
            app.configureWithOpaqueBackground()
                app.titleTextAttributes = [.foregroundColor: UIColor.white]
                app.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
                app.backgroundColor = #colorLiteral(red: 0.1603881121, green: 0.1677560508, blue: 0.2133775949, alpha: 1)
       self.navigationController?.navigationBar.scrollEdgeAppearance = app
                
              
                navigationBar!.standardAppearance = app
                navigationBar!.scrollEdgeAppearance = app
      
      }
    

        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "Objective C"
        ObjectiveCTableView.rowHeight = UITableView.automaticDimension
        let headerView = UIView()
           let footerView = UIView()
               
               headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
               footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
               
               let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 3.5)
               
               headerView.frame = sizeView
               footerView.frame = sizeView
               ObjectiveCTableView.tableHeaderView = headerView
               ObjectiveCTableView.tableFooterView = footerView
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension ObjectiveCViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let title: ObjectiveCTitleTableViewCell!
        let Cells: ObjectiveCTableViewCell!
        
        if indexPath.row == 2 {
            Cells = ObjectiveCTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? ObjectiveCTableViewCell
                                   
                              
                   Cells?.IconsCells.image = UIImage(named: optionImage[indexPath.row])
                   
                   
                                   Cells?.TitleCells.text =  optionalTitle[indexPath.row]
                                 
                                   Cells?.AvaiableCells.image = UIImage(named: avaiableIcon[indexPath.row])
                               
                                   
                                   return Cells!
        } else if indexPath.row == 1 {
           
           Cells = ObjectiveCTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? ObjectiveCTableViewCell
                            
                       
            Cells?.IconsCells.image = UIImage(named: optionImage[indexPath.row])
            
            
                            Cells?.TitleCells.text =  optionalTitle[indexPath.row]
                          
                            Cells?.AvaiableCells.image = UIImage(named: avaiableIcon[indexPath.row])
                        
                            
                            return Cells!
            
        } else {
            
            title = ObjectiveCTableView.dequeueReusableCell(withIdentifier: "TitleCells", for: indexPath) as? ObjectiveCTitleTableViewCell
            
                     // MARK: Nsattributedstring
                    let attr = NSMutableAttributedString(string: "Welcome to Objective C Tutorials! Objective-C 2.0 has released in 2006. However, It's the end of releasing a new version for the Objective-C after Objective-C 2.0. ", attributes: [.foregroundColor: titleText])

            attr.append(NSAttributedString(string: "Sadly, There's no playground for Objective-C supported. ", attributes: [.foregroundColor: titleText]))
                                              
                    attr.append(NSAttributedString(string: "You can learn Objective C in the Xcode in which it requested to have macOS devices as well. If you don't have macOS devices, then no worries! It had an answer under the code concept that may help to understand the code! ", attributes: [.foregroundColor: titleText]))

            attr.append(NSAttributedString(string: "Objective C is coming soon!", attributes: [.foregroundColor: titleText]))
                     
                     
                     title?.textLabel?.attributedText = attr
                     title.isUserInteractionEnabled = false
                     title?.textLabel?.numberOfLines = 0
                     title?.textLabel?.lineBreakMode = .byWordWrapping
                     title?.textLabel?.textAlignment = .justified
                  
                     
                     return title!
            
        }
    }
    
    
    
}
