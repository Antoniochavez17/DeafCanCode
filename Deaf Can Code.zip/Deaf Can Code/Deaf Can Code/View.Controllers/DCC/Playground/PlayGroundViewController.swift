//
//  PlayGroundViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 2/8/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class PlayGroundViewController: UIViewController {

    @IBOutlet weak var PlaygroundTableView: UITableView!
    
 var cellTitle = ["", "Blank", "Xcode Playground", "Camera", "AR Create", "Shapes", "Graphing", "Answers", "Puzzle World", "Sonic Create"]
    
  var cellImage = ["", "Untitled 31-3", "Xcode-1", "Untitled 31-4", "Untitled 6-14", "Untitled 31-5", "Untitled 31-6", "Untitled 31-7", "Untitled 31-8", "Untitled 31-9"]
    
    var forwardCell = ["", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7"]
    
    override func viewWillAppear(_ animated: Bool) {
          super.viewWillAppear(animated)
      
      
         let app = UINavigationBarAppearance()
                app.configureWithTransparentBackground()
               
              app.shadowImage = UIImage()
              self.navigationController?.navigationBar.standardAppearance = app
                self.navigationController?.navigationBar.scrollEdgeAppearance = app
                self.navigationController?.navigationBar.compactAppearance = app
                 
          
      }

      override func viewWillDisappear(_ animated: Bool) {
          super.viewWillDisappear(animated)
          
              
    
     let app = UINavigationBarAppearance()
           
           let navigationBar = self.navigationController?.navigationBar
            
      app.backgroundColor = .clear
                app.configureWithOpaqueBackground()
                
                
            
            app.configureWithOpaqueBackground()
                app.titleTextAttributes = [.foregroundColor: UIColor.white]
                app.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
                app.backgroundColor = #colorLiteral(red: 0.1603881121, green: 0.1677560508, blue: 0.2133775949, alpha: 1)
       self.navigationController?.navigationBar.scrollEdgeAppearance = app
                
              
                navigationBar!.standardAppearance = app
                navigationBar!.scrollEdgeAppearance = app
      
      }
    

        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "Playground"
        PlaygroundTableView.rowHeight = UITableView.automaticDimension
        let headerView = UIView()
           let footerView = UIView()
               
               headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
               footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
               
               let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 3.5)
               
               headerView.frame = sizeView
               footerView.frame = sizeView
               PlaygroundTableView.tableHeaderView = headerView
               PlaygroundTableView.tableFooterView = footerView
        
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension PlayGroundViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let title: PlaygroundTitleTableViewCell!
        let Cells: PlaygroundTableViewCell!
        
        if indexPath.row == 9 {
            
             Cells = PlaygroundTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? PlaygroundTableViewCell
                                           
                                      
            Cells?.IconsCells.image = UIImage(named: cellImage[indexPath.row])
                           
                           
            Cells?.TitleCells.text =  cellTitle[indexPath.row]
                                         
            Cells?.AvaiableIcon.image = UIImage(named: forwardCell[indexPath.row])
                                       
                                           
            return Cells!
            
        }   else if indexPath.row == 8 {
                        
                 Cells = PlaygroundTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? PlaygroundTableViewCell
                                                
                                           
                 Cells?.IconsCells.image = UIImage(named: cellImage[indexPath.row])
                                
                                
                 Cells?.TitleCells.text =  cellTitle[indexPath.row]
                                              
                 Cells?.AvaiableIcon.image = UIImage(named: forwardCell[indexPath.row])
                                            
                                                
                 return Cells!
                 
        }   else if indexPath.row == 7 {
                             
                      Cells = PlaygroundTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? PlaygroundTableViewCell
                                                     
                                                
                      Cells?.IconsCells.image = UIImage(named: cellImage[indexPath.row])
                                     
                                     
                      Cells?.TitleCells.text =  cellTitle[indexPath.row]
                                                   
                      Cells?.AvaiableIcon.image = UIImage(named: forwardCell[indexPath.row])
                                                 
                                                     
                      return Cells!
                      
        }   else if indexPath.row == 6 {
                   
            Cells = PlaygroundTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? PlaygroundTableViewCell
                                           
                                      
            Cells?.IconsCells.image = UIImage(named: cellImage[indexPath.row])
                           
                           
            Cells?.TitleCells.text =  cellTitle[indexPath.row]
                                         
            Cells?.AvaiableIcon.image = UIImage(named: forwardCell[indexPath.row])
                                       
                                           
            return Cells!
            
        } else if indexPath.row == 5 {
                
            Cells = PlaygroundTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? PlaygroundTableViewCell
                                           
                                      
            Cells?.IconsCells.image = UIImage(named: cellImage[indexPath.row])
                           
                           
            Cells?.TitleCells.text =  cellTitle[indexPath.row]
                                         
            Cells?.AvaiableIcon.image = UIImage(named: forwardCell[indexPath.row])
                                       
                                           
            return Cells!
            
        } else if indexPath.row == 4 {
               
            Cells = PlaygroundTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? PlaygroundTableViewCell
                                           
                                      
            Cells?.IconsCells.image = UIImage(named: cellImage[indexPath.row])
                           
                           
            Cells?.TitleCells.text =  cellTitle[indexPath.row]
                                         
            Cells?.AvaiableIcon.image = UIImage(named: forwardCell[indexPath.row])
                                       
                                           
            return Cells!
            
        } else if indexPath.row == 3 {
                   
            Cells = PlaygroundTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? PlaygroundTableViewCell
                                           
                                      
            Cells?.IconsCells.image = UIImage(named: cellImage[indexPath.row])
                           
                           
            Cells?.TitleCells.text =  cellTitle[indexPath.row]
                                         
            Cells?.AvaiableIcon.image = UIImage(named: forwardCell[indexPath.row])
                                       
                                           
            return Cells!
            
        }  else if indexPath.row == 2 {
                   
              Cells = PlaygroundTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? PlaygroundTableViewCell
                                           
                                      
            Cells?.IconsCells.image = UIImage(named: cellImage[indexPath.row])
                           
                           
            Cells?.TitleCells.text =  cellTitle[indexPath.row]
                                         
            Cells?.AvaiableIcon.image = UIImage(named: forwardCell[indexPath.row])
                                       
                                           
            return Cells!
             
        } else if indexPath.row == 1 {
            
            Cells = PlaygroundTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? PlaygroundTableViewCell
                                           
                                      
            Cells?.IconsCells.image = UIImage(named: cellImage[indexPath.row])
                           
                           
            Cells?.TitleCells.text =  cellTitle[indexPath.row]
                                         
            Cells?.AvaiableIcon.image = UIImage(named: forwardCell[indexPath.row])
                                       
                                           
            return Cells!
       
        } else {
            
            title = PlaygroundTableView.dequeueReusableCell(withIdentifier: "TitleCells", for: indexPath) as? PlaygroundTitleTableViewCell
            
                     // MARK: Nsattributedstring
                    let attr = NSMutableAttributedString(string: "Welcome to Playground Tutorials! The Playground is requested to have iPadOS and macOS devices as well. Remember, Playground doesn't have a storyboard in which it means only code to make a concept. The WWDC has offered a scholarship for everyone to make a playground to have your idea to make a concept to chance a win the scholarship includes free one year of Apple Developer programs and free tickets to WWDC in San Jose, CA! Playground is coming soon!", attributes: [.foregroundColor: titleText])


                     
                     
                     title?.textLabel?.attributedText = attr
                     title.isUserInteractionEnabled = false
                     title?.textLabel?.numberOfLines = 0
                     title?.textLabel?.lineBreakMode = .byWordWrapping
                     title?.textLabel?.textAlignment = .justified
                  
                     
                     return title!
            
        }
    }
    
    
    
}
