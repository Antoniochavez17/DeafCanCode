//
//  DeafCanCodeHomeViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/18/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class DeafCanCodeHomeViewController: UIViewController {

       var seactionName = ["Code Tutorials", "", "", "Xcode Tutorials", "", "", "Dictionary", ""]
    

    var seactionImage = ["Untitled 31-1", "", "", "Xcode-1", "", "", "Untitled 8", ""]
    
       var seactionObjection = ["", "Swift", "Objective C", "", "Xcode", "Playground", "", "Dictionary"]
       var iconImageCells = ["", "Untitled 6-9", "ObjC", "","Xcode-1", "Untitled 6-18", "", "Untitled 6-13"]
      
   var available = ["", "Untitled 6", "Untitled 6", "", "Untitled 6", "Untitled 6","", "Untitled 6"]

    // Setting Storyboard ID
    var StoryboardID = [String]()
     
    
    @IBOutlet weak var HomeTableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
         let headerView = UIView()
        headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
        
        let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 4)
        headerView.frame = sizeView
        HomeTableView.tableHeaderView = headerView
        
         self.navigationItem.title = "Deaf Can Code"
        
        StoryboardID = ["", "Swift", "ObjC", "", "Xcode", "Playground", "", "Dictionary"]
        
        
   
                  
                let navBarAppearance = UINavigationBarAppearance()
                let navigationBar = self.navigationController?.navigationBar
                navBarAppearance.configureWithOpaqueBackground()
                navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
                navBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
                navBarAppearance.backgroundColor = #colorLiteral(red: 0.1603881121, green: 0.1677560508, blue: 0.2133775949, alpha: 1)
                navigationBar!.standardAppearance = navBarAppearance
                navigationBar!.scrollEdgeAppearance = navBarAppearance
                              
   
        
    
        
            
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension DeafCanCodeHomeViewController: UITableViewDataSource, UITableViewDelegate {
    
   
    
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == 7 {
            return 60
        } else if indexPath.row == 6 {
            return 45
        } else if indexPath.row == 5 {
            return 60
        } else if indexPath.row == 4 {
            return 60
        } else if indexPath.row == 3 {
            return 45
        } else if indexPath.row == 2 {
            return 60
        } else if indexPath.row == 1 {
            return 60
        } else  {
            return 45
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return seactionObjection.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cells: HomeTableViewCell!
        var titleCell: GroupTitleTableViewCell!
        
        
        if indexPath.row == 7 {
            
         cells = HomeTableView.dequeueReusableCell(withIdentifier: "Home") as? HomeTableViewCell
        
        cells?.AvaiableImage?.image = UIImage(named: available[indexPath.row])
         cells?.IconCells?.image = UIImage(named:iconImageCells[indexPath.row])
        cells?.TitleCells?.text = seactionObjection[indexPath.row]
        
        return cells!
            
        }  else if indexPath.row == 6 {
                   
              titleCell = HomeTableView.dequeueReusableCell(withIdentifier: "Header") as? GroupTitleTableViewCell
                     
              
                        titleCell?.TitleLabel?.text = seactionName[indexPath.row]
                                  
                        titleCell?.ImageIcon?.image = UIImage(named: seactionImage[indexPath.row])
                                  
                                 titleCell.isUserInteractionEnabled = false
                                
                     
                     return titleCell!
                   
               } else if indexPath.row == 5 {
            
         cells = HomeTableView.dequeueReusableCell(withIdentifier: "Home") as? HomeTableViewCell
        
        cells?.AvaiableImage?.image = UIImage(named: available[indexPath.row])
         cells?.IconCells?.image = UIImage(named:iconImageCells[indexPath.row])
        cells?.TitleCells?.text = seactionObjection[indexPath.row]
        cells.isUserInteractionEnabled = true
        return cells!
            
        } else if indexPath.row == 4 {
            
         cells = HomeTableView.dequeueReusableCell(withIdentifier: "Home") as? HomeTableViewCell
        
        cells?.AvaiableImage?.image = UIImage(named: available[indexPath.row])
         cells?.IconCells?.image = UIImage(named:iconImageCells[indexPath.row])
        cells?.TitleCells?.text = seactionObjection[indexPath.row]
        
        return cells!
            
        } else if indexPath.row == 3 {
            
         titleCell = HomeTableView.dequeueReusableCell(withIdentifier: "Header") as? GroupTitleTableViewCell
                
         
                   titleCell?.TitleLabel?.text = seactionName[indexPath.row]
                             
                   titleCell?.ImageIcon?.image = UIImage(named: seactionImage[indexPath.row])
                             
                            titleCell.isUserInteractionEnabled = false
                
                return titleCell!
            
        } else if indexPath.row == 2 {
            
         cells = HomeTableView.dequeueReusableCell(withIdentifier: "Home") as? HomeTableViewCell
                
                cells?.AvaiableImage?.image = UIImage(named: available[indexPath.row])
                 cells?.IconCells?.image = UIImage(named:iconImageCells[indexPath.row])
                cells?.TitleCells?.text = seactionObjection[indexPath.row]
              
            
                return cells!
            
        } else if indexPath.row == 1 {
            
         cells = HomeTableView.dequeueReusableCell(withIdentifier: "Home") as? HomeTableViewCell
        
        cells?.AvaiableImage?.image = UIImage(named: available[indexPath.row])
         cells?.IconCells?.image = UIImage(named:iconImageCells[indexPath.row])
        cells?.TitleCells?.text = seactionObjection[indexPath.row]
        
        return cells!
            
        } else  {
            
        titleCell = HomeTableView.dequeueReusableCell(withIdentifier: "Header") as? GroupTitleTableViewCell
         
  
            titleCell?.TitleLabel?.text = seactionName[indexPath.row]
                      
            titleCell?.ImageIcon?.image = UIImage(named: seactionImage[indexPath.row])
                      
       titleCell.isUserInteractionEnabled = false
         
         return titleCell!
            
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
               
    let vcName = StoryboardID[indexPath.row]
               
    let Swift = storyboard?.instantiateViewController(withIdentifier: vcName)
              
            
    self.navigationController?.pushViewController(Swift!, animated: true)
               
    }
    
    
}
