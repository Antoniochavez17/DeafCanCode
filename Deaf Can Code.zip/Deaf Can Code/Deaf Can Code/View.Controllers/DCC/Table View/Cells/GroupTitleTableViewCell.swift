//
//  GroupTitleTableViewCell.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 1/31/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class GroupTitleTableViewCell: UITableViewCell {

    
    @IBOutlet weak var ImageIcon: UIImageView!
    @IBOutlet weak var TitleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
