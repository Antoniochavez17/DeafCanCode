//
//  DesignVSCodeViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/24/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class DesignVSCodeViewController: UIViewController {

    var cellTitle = ["Design", "Code"]
    var cellImage = ["Icon-2", "Icon-1"]
    
    @IBOutlet weak var DVCTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
 self.navigationItem.title = "UIKit"
        
        let headerView = UIView()
                      let footerView = UIView()
                           
                      headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
                      footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
                           
                      let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 3.5)
                           
                      headerView.frame = sizeView
                      footerView.frame = sizeView
                      DVCTableView.tableHeaderView = headerView
                      DVCTableView.tableFooterView = footerView
    }

    

}

extension DesignVSCodeViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cellTitle.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
         var cells: DesignVsCodeTableViewCell!
        
        cells = DVCTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DesignVsCodeTableViewCell
        
        cells?.CellTitle.text = cellTitle[indexPath.row]
        cells?.cellIcon.image = UIImage(named: cellImage[indexPath.row])
        
        return cells!
        
    }
    
    
    
    
}
