//
//  XcodeTableViewCell.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/24/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class XcodeTableViewCell: UITableViewCell {

    @IBOutlet weak var iconimg: UIImageView!
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
