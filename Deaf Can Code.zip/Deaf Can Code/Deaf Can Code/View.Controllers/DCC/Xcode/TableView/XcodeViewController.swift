//
//  XcodeViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/24/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class XcodeViewController: UIViewController {

    var cellTitle = ["UIKit", "SwiftUI", "ARKit", "Core ML", "SpriteKit", "SceneKit", "Cocoa"]
    
    var cellImage = ["Untitled 6-9", "Untitled 6-10", "Untitled 6-14", "Untitled 6-16", "Icon-4", "Icon-5", "Icon-3"]
    
    var forwardCell = ["Untitled 6", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7"]
    
    var StoryboardID = [String]()
    
    
    @IBOutlet weak var XcodeTableView: UITableView!
    
    
    override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
        
        
           let app = UINavigationBarAppearance()
                  app.configureWithTransparentBackground()
                 
                app.shadowImage = UIImage()
                self.navigationController?.navigationBar.standardAppearance = app
                  self.navigationController?.navigationBar.scrollEdgeAppearance = app
                  self.navigationController?.navigationBar.compactAppearance = app
                   
            
        }

        override func viewWillDisappear(_ animated: Bool) {
            super.viewWillDisappear(animated)
            
                
      
       let app = UINavigationBarAppearance()
             
             let navigationBar = self.navigationController?.navigationBar
              
        app.backgroundColor = .clear
                  app.configureWithOpaqueBackground()
                  
                  
              
              app.configureWithOpaqueBackground()
                  app.titleTextAttributes = [.foregroundColor: UIColor.white]
                  app.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
                  app.backgroundColor = #colorLiteral(red: 0.1603881121, green: 0.1677560508, blue: 0.2133775949, alpha: 1)
         self.navigationController?.navigationBar.scrollEdgeAppearance = app
                  
                
                  navigationBar!.standardAppearance = app
                  navigationBar!.scrollEdgeAppearance = app
        
        }
    
    override func viewDidLoad() {
       super.viewDidLoad()

         StoryboardID = ["DVC", "", "", "", "", "", ""]
        
       
        self.navigationItem.title = "Xcode"
        
        let headerView = UIView()
               let footerView = UIView()
                    
               headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
               footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
                    
               let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 3.5)
                    
               headerView.frame = sizeView
               footerView.frame = sizeView
               XcodeTableView.tableHeaderView = headerView
               XcodeTableView.tableFooterView = footerView
    }
    


}

extension XcodeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 59
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cellTitle.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cells: XcodeTableViewCell!

        
        if indexPath.row == 6 {
            cells = XcodeTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? XcodeTableViewCell
        cells?.lbl.text = cellTitle[indexPath.row]
               cells?.img.image = UIImage(named: forwardCell[indexPath.row])
               cells?.iconimg.image = UIImage(named: cellImage[indexPath.row])
                              
                               cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 5 {
            cells = XcodeTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? XcodeTableViewCell
             cells?.lbl.text = cellTitle[indexPath.row]
                   cells?.img.image = UIImage(named: forwardCell[indexPath.row])
                   cells?.iconimg.image = UIImage(named: cellImage[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 4 {
            cells = XcodeTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? XcodeTableViewCell
            cells?.lbl.text = cellTitle[indexPath.row]
                   cells?.img.image = UIImage(named: forwardCell[indexPath.row])
                   cells?.iconimg.image = UIImage(named: cellImage[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 3 {
            cells = XcodeTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? XcodeTableViewCell
             cells?.lbl.text = cellTitle[indexPath.row]
                   cells?.img.image = UIImage(named: forwardCell[indexPath.row])
                   cells?.iconimg.image = UIImage(named: cellImage[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 2 {
            cells = XcodeTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? XcodeTableViewCell
           
            cells?.lbl.text = cellTitle[indexPath.row]
                   cells?.img.image = UIImage(named: forwardCell[indexPath.row])
                   cells?.iconimg.image = UIImage(named: cellImage[indexPath.row])
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 1 {
            cells = XcodeTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? XcodeTableViewCell
           cells?.lbl.text = cellTitle[indexPath.row]
                   cells?.img.image = UIImage(named: forwardCell[indexPath.row])
                   cells?.iconimg.image = UIImage(named: cellImage[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else {
            cells = XcodeTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? XcodeTableViewCell
              cells?.lbl.text = cellTitle[indexPath.row]
                    cells?.img.image = UIImage(named: forwardCell[indexPath.row])
                    cells?.iconimg.image = UIImage(named: cellImage[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = true
            return cells!
        }
        
      
            
    }

func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                 
                    
         let vcName = StoryboardID[indexPath.row]
                    
         let Swift = storyboard?.instantiateViewController(withIdentifier: vcName)
                   
                 
         self.navigationController?.pushViewController(Swift!, animated: true)
                    
         }

}
