//
//  DictionaryViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/23/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class DictionaryViewController: UIViewController {

    
    let imageIcon = ["Untitled 6-9", "Untitled 6-9", "Untitled 6-18", "Untitled 6-10", "Untitled 6-14", "Untitled 6-16", "Icon-4", "Icon-5", "Icon-3"]
    
    let ForwardIcon = ["Untitled 6", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7", "Untitled 7"]
    
    let DictName = ["Swift", "UIKit", "Playground", "SwiftUI", "ARKit", "SpriteKit", "SenceKit", "Core ML", "Cocoa"]
    
     var StoryboardID = [String]()
    @IBOutlet weak var dictionaryTableView: UITableView!
    
    
    override func viewWillAppear(_ animated: Bool) {
             super.viewWillAppear(animated)
         
         
            let app = UINavigationBarAppearance()
                   app.configureWithTransparentBackground()
                  
                 app.shadowImage = UIImage()
                 self.navigationController?.navigationBar.standardAppearance = app
                   self.navigationController?.navigationBar.scrollEdgeAppearance = app
                   self.navigationController?.navigationBar.compactAppearance = app
                    
             
         }

         override func viewWillDisappear(_ animated: Bool) {
             super.viewWillDisappear(animated)
             
                 
       
        let app = UINavigationBarAppearance()
              
              let navigationBar = self.navigationController?.navigationBar
               
         app.backgroundColor = .clear
                   app.configureWithOpaqueBackground()
                   
                   
               
               app.configureWithOpaqueBackground()
                   app.titleTextAttributes = [.foregroundColor: UIColor.white]
                   app.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
                   app.backgroundColor = #colorLiteral(red: 0.1603881121, green: 0.1677560508, blue: 0.2133775949, alpha: 1)
          self.navigationController?.navigationBar.scrollEdgeAppearance = app
                   
                 
                   navigationBar!.standardAppearance = app
                   navigationBar!.scrollEdgeAppearance = app
         
         }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

         StoryboardID = ["SwiftDict" , "", "", "", "", "", "", "", ""]
        
        let headerView = UIView()
        let footerView = UIView()
             
        headerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
        footerView.backgroundColor = #colorLiteral(red: 0.09410236031, green: 0.09412645549, blue: 0.09410081059, alpha: 1)
             
        let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 3.5)
             
        headerView.frame = sizeView
        footerView.frame = sizeView
        dictionaryTableView.tableHeaderView = headerView
        dictionaryTableView.tableFooterView = footerView
    }
    

}



extension DictionaryViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
           
           return 59
           
       }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DictName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cells: DictionaryTableViewCell!

        
        if indexPath.row == 9 {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
                   cells?.DicTitle.text = DictName[indexPath.row]
                   cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
                   cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
                       
                        cells.isUserInteractionEnabled = false
            return cells!
        }  else if indexPath.row == 8 {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
        cells?.DicTitle.text = DictName[indexPath.row]
        cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
        cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
            
             cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 7 {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
            cells?.DicTitle.text = DictName[indexPath.row]
                   cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
                   cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
                       
                        cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 6 {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
        cells?.DicTitle.text = DictName[indexPath.row]
                          cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
                          cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
                              
                               cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 5 {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
            cells?.DicTitle.text = DictName[indexPath.row]
                              cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
                              cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 4 {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
            cells?.DicTitle.text = DictName[indexPath.row]
                              cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
                              cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 3 {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
            cells?.DicTitle.text = DictName[indexPath.row]
                              cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
                              cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 2 {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
            cells?.DicTitle.text = DictName[indexPath.row]
                              cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
                              cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else if indexPath.row == 1 {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
            cells?.DicTitle.text = DictName[indexPath.row]
                              cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
                              cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = false
            return cells!
        } else {
            cells = dictionaryTableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? DictionaryTableViewCell
             cells?.DicTitle.text = DictName[indexPath.row]
                              cells?.ForwIcon.image = UIImage(named: ForwardIcon[indexPath.row])
                              cells?.DicImg.image = UIImage(named: imageIcon[indexPath.row])
                                  
                                   cells.isUserInteractionEnabled = true
            return cells!
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
               
    let vcName = StoryboardID[indexPath.row]
               
    let Swift = storyboard?.instantiateViewController(withIdentifier: vcName)
              
            
    self.navigationController?.pushViewController(Swift!, animated: true)
               
    }

    
}
