//
//  DictionaryTableViewCell.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/23/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class DictionaryTableViewCell: UITableViewCell {

    @IBOutlet weak var DicImg: UIImageView!
    @IBOutlet weak var ForwIcon: UIImageView!
    @IBOutlet weak var DicTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
