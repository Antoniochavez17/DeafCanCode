//
//  SwiftDictonaryViewController.swift
//  Deaf Can Code
//
//  Created by Antonio Adrian Chavez on 12/7/19.
//  Copyright © 2019 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class SwiftDictonaryViewController: UIViewController {

    
    var seactionName = [
        
        // MARK: A
        "Addition operator",
        "",
        "",
        "Addition and assignment operator",
        "",
        "",
        "And operator",
        "",
        "",
        "Append",
        "",
        "",
        "Array",
        "",
        "",
        "Assignment Operator",
        "",
        "",
        // MARK: B
        "Backslash escape",
        "",
        "",
        // MARK: C
        "Class",
        "",
        "",
        "Closures",
        "",
        "",
        "Comment",
        "",
        "",
        "Constants",
        "",
        "",
        "contains",
        "",
        "",
        "Count",
        "",
        "",

        // MARK: D
        "Dictionaries",
        "",
        "",
        "Dictionaries default value",
        "",
        "",
        "Division operator",
        "",
        "",
        "Division and assignment operator",
        "",
        "",
        "Double",
        "",
        "",

        // MARK: E
        "Else",
        "",
        "",
        "Else if",
        "",
        "",
        "Enumeration",
        "",
        "",
        "Equals operator",
        "",
        "",
        
        // MARK: F
        "False",
        "",
        "",
        "Fallthrough",
        "",
        "",
        "Function",
        "",
        "",
        
        // MARK: G
        "Greater than operator",
        "",
        "",
        "Greater than and equal operator",
        "",
        "",
        
        // MARK: H
        
        // MARK: I
        "If",
        "",
        "",
        "Implicitly unwrapping optional",
        "",
        "",
        "Integer",
        "",
        "",
        "Insert",
        "",
        "",
        "Intersection",
        "",
        "",
        "IsDisjoint",
        "",
        "",
        
        // MARK: J
        
        // MARK: K
        
        // MARK: L
        "Less than operator",
        "",
        "",
        "Less than and equal operator",
        "",
        "",
        
         // MARK: M
        "Max",
        "",
        "",
        "Min",
        "",
        "",
        "Minimap comment",
        "",
        "",
        "Multi-line comment",
        "",
        "",
        "Multi-line string",
        "",
        "",
        "Multiplication operator",
        "",
        "",
        "Multiplication and assignment operator",
        "",
        "",
        
         // MARK: N
        "Not equal operator",
        "",
        "",
        "Not false",
        "",
        "",
        "Not operator",
        "",
        "",
        "Not true",
        "",
        "",
        
        // MARK: O
        "Or operator",
        "",
        "",
        "Optional",
        "",
        "",
        
        // MARK: P
        "Precent operator",
        "",
        "",
        "Precent and assignment operator",
        "",
        "",
        "Print",
        "",
        "",
        
        // MARK: R
        "Remove",
        "",
        "",
        "RemoveValue",
        "",
        "",
        
        // MARK: S
        "Separator",
        "",
        "",
        "Set",
        "",
        "",
        "Sorted",
        "",
        "",
        "String",
        "",
        "",
        "String interpolation",
        "",
        "",
        "Structure",
        "",
        "",
        "Subtraction operator",
        "",
        "",
        "Subtraction and assignment operator",
        "",
        "",
        "Switch",
        "",
        "",
        
        // MARK: T
        "Terminator",
        "",
        "",
        "True",
        "",
        "",
        "Tuples",
        "",
        "",
        "Type annotations",
        "",
        "",
        
        // MARK: U
        "Union",
        "",
        "",
        "updateValue",
        "",
        "",
        
        // MARK: V
        "Variable",
        "",
        "",
        
        // MARK: W
        
        // MARK: X
        
        // MARK: Y
        
        // MARK: Z
        
    ]
    var seactionObjection = [
        
        // MARK: A
        "",
        "",
        "",
        "",
        "",
        "",
        // MARK: B
        "",
        // MARK: C
        "",
        "",
        "",
        "",
        "",
        "",

        // MARK: D
        "",
        "",
        "",
        "",
        "",
        // MARK: E
        "",
        "",
        "",
        "",
        // MARK: F
        "",
        "",
        "",
        // MARK: G
        "",
        "",

        // MARK: H
        
        // MARK: I
        "",
        "",
        "",
        "",
        "",
        "",
        
        // MARK: J
        
        // MARK: K
        
        // MARK: L
        "",
        "",
        
         // MARK: M
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        
         // MARK: N
        "",
        "",
        "",
        "",
        
        // MARK: O
        "",
        "",
        
        // MARK: P
        "",
        "",
        "",
        
        // MARK: R
        "",
        "",
        
        // MARK: S
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        
        // MARK: T
        "",
        "",
        "",
        "",
        
        // MARK: U
        "",
        "",
        
        // MARK: V
        ""
        
        // MARK: W
        
        // MARK: X
        
        // MARK: Y
        
        // MARK: Z
        
    ]
    var sectionFooter = [
        
        // MARK: A
        "",
        "",
        
        "The + symbols mean to add or combine the new value without calling the name value.",
        
        "",
        "",
        
        "The += symbols mean to calling for name value's value to add or combine and assignment to the new value.",
        
        "",
        "",
        
        "The || symbols means and operators, which means this values and another values, and only it'll executing true in the conditions.",
        
        "",
        "",
        
        "The append( ) allows you to add a new anythings.",
        
        "",
        "",
        
        "You can store the elements using comma in the curly bracket. It allows adding the elements, alphabetical order, remove, calling the first element by using the curly bracket with start at 0.",
        
        "",
        "",
        
        "The = symbols means the value has linked to the name values, or change the new values.",
        
        // MARK: B
        
        "",
        "",
        
        "Backslash has to interpret that string in which it'll tell the compiler to ignore that backslash to the next character.",
        
        // MARK: C
        "",
        "",
        "You can create your own idea to write in the name and create everything will be inducted in the body called properties, but it's allow you to control properties.",
        
        "",
        "",
        
        "The closures are familiar to if and function, but you can control the statements.",
        
        "",
        "",
        "The comments do to remind, to do list, or important notes. It'll not execute when you add the comments.",
        
        "",
        "",
        "The constants don't allows you to control the value; For example: Change, Add, Remove, Check if two value is equal.",
        
        "",
        "",
        "The contains is only compatible with set to check if value is avaiable, or not.",
        
        "",
        "",
        "The count is counting how many characters have in the stored from the value.",

        // MARK: D
        "",
        "",
        "You can store the key and elements using comma in the curly bracket. It allows adding the elements, remove, calling the first element by using the curly bracket with start at 0, otherwise it's can't use alphabetical order.",
        
        "",
        "",
        "It'll be an error if you try to execute the element in which does not exist in one of those the key's elements. It's simple to add a default to execute the element that the key has.",
        
        "",
        "",
        "The / symbols mean only for numbers, which means this value to division to new values to answer final numbers without calling name value.",
        
        "",
        "",
        "The /= symbols mean to calling for name value's value to division and assignment to the new value to answer final numbers.",
        
        "",
        "",
        "The number have a decimal point.",
        
        // MARK: E
        "",
        "",
        "Add else's statements at end of the if's statements for executing if this if's condition is false.",
        "",
        "",
        "Add the second if conditions called else if to allow executing else if's statements if one of group in the conditions is true.",
        "",
        "",
        "The enumeration means you can create a case like familiar to switch but in the group, then you can choose one or more cases at outside statements.",
        "",
        "",
        "The == symbols mean to check if two values have equal values otherwise, false if it's unequal.",
    
        // MARK: F
        "",
        "",
        "The false in the Swift means like incorrect, mismatch, not execute the coding.",
        
        "",
        "",
        "The fallthrough is only compatible with switch. The fallthrough is allowed you to combine the case's statement with default's statements.",
        "",
        "",
        "The function creates an argument for giving an implementation by when you were calling arguments in the parameter.",
        
        // MARK: G
        "",
        "",
        "The > symbols mean the left value has greater than the right value.",
        "",
        "",
        """
        The >= symbols mean the left value has greater than and equal to the right value.
                   
        An example code result at below:
        3 >= 4 means 3.01 and above are a false.
        3 >= 3 means true.
        3 >= 2 means 2.99 and below are a true.
        """,
        
        // MARK: H
        
        // MARK: I
        "",
        "",
        "If is only condition is true, then executing the statements, otherwise it'll not execute if condition is false.",
        "",
        "",
        "The ! symbols mean it'll crash if the value has nil, otherwise it'll not crash if the value is avaiable.",
        "",
        "",
        "The number don't have a decimal point.",
        "",
        "",
        "The insert is only compatible with set to add a new element.",
        "",
        "",
        "The intersection is only compatible with set to check if elements are the same as new elements.",
        "",
        "",
        "The isDisjoint is only compatible with set to check if elements are not same as new elements, otherwise false if it's same.",
        
        // MARK: J
        
        // MARK: K
        
        // MARK: L
        "",
        "",
        "The < symbols mean the left value has less than the right value.",
        "",
        "",
        """
        The >= symbols mean the left value has less than and equal to the right value.
                       
        An example code result at below:
        3 <= 4 means 3.01 and above are a true.
        3 <= 3 means true.
        3 <= 2 means 2.99 and below are a false.
        """,
        
         // MARK: M
        "",
        "",
        "The max stands for maximum numbers, but the maximum is only compatible with bit integers.",
        "",
        "",
        "The min stands for mimimum numbers, but the mimimum is only compatible with bit integers.",
        "",
        "",
        "The minimap comment will be bold highlight, but it'll appear large titles on the right side of the code editor area is called Minimap is only available in the Xcode 11 and above.",
        "",
        "",
        "The multi-line comments allow you to add a sentence within new lines, which it's familiar to multi-line string does.",
        "",
        "",
        "The multi-line string allow you to add a sentence within new lines, which it's familiar to multi-line comment does.",
        "",
        "",
        "The * symbols mean only for numbers, which means this value to multiplication to new values to answer final numbers without calling name value.",
        "",
        "",
        "The *= symbols mean to calling for name value's value to multiplication and assignment to the new value to answer final numbers.",
        "",
        "",
        
        // MARK: N
        "The != symbols mean to check if two values have unequal values otherwise, false if it's equal.",
        "",
        "",
        "If you disagree with this false, then it'll convert to true.",
        "",
        "",
        "The ! symbols mean not, and it'll make an opposite the booleans.",
        "",
        "",
        "If you disagree with this true, then it'll convert to false.",
        "",
        "",
        
        // MARK: O
        "The && operator means or operators, which means this values or another values, and only it'll executing false in the conditions.",
        "",
        "",
        "The ? symbols mean to check if the value has available, or nil.",
        "",
        "",
        
        // MARK: P
        "The / symbols mean only for numbers, which means this value to precent to new values to answer final numbers without calling name value.",
        "",
        "",
        "The %= symbols mean to calling for name value's value to precent and assignment to the new value to answer final numbers.",
        "",
        "",
        "The printing allows display in the console; For example, You want to test that inside of the statements in the coding to see if it succeeds or not.",
        "",
        "",
        
        // MARK: R
        "The remove is only compatible with set to remove a new element.",
        "",
        "",
        "The removeValues is only compatible with dictionaries to remove the element when you were calling the key.",
        "",
        "",
        
        
        // MARK: S
        "The separator means it'll add in the space each of the items.",
        "",
        "",
        "The set is not allows you to control the elements, which means it's opposite of the array which allows to control it.",
        "",
        "",
        "The sorted( ) allows alphabetical order values.",
        "",
        "",
        "The string is using straight quotes to allow you to text the sentence in between two quotes.",
        "",
        "",
        "The \\( ) symbol means allows you to put the values inducted in the strings.",
        "",
        "",
        "You can create your own idea to write in the name and create everything will be inducted in the body called properties, but it's not allow you to control properties.",
        "",
        "",
        "The - symbols mean only for numbers, which means this value to subtraction to new values to answer final numbers without calling name value.",
        "",
        "",
        "The -= symbols mean to calling for name value's value to subtraction and assignment to the new value to answer final numbers.",
        "",
        "",
        "The switch has two methods called case and default. The inside case's statements respond to value, which it's matched it otherwise, execute default's statements if statement mismatch those case's value.",
        "",
        "",
        
        // MARK: T
        "The terminator is given you to add a new string at the end items.",
        "",
        "",
        "The true in the Swift means like correct, match, execute the coding.",
        "",
        "",
        "The tuple is not allows you to control the key and elements, which means it's opposite of the dictionaries which allows to control it, but it's allow you to access the elements.",
        "",
        "",
        "The type is to allow the value to focus on what type supposed to be; For example, Int is request to create number without decimal point otherwise error if mismatched to Int request.",
        "",
        "",
        
        // MARK: U
        "The union is only compatible with set to create an element to combine to the first element, but it'll not show if elements have existed from first stored.",
        "",
        "",
        "The updateValue is only compatible with dictionaries to add the element when you were calling the key.",
        
        // MARK: V
        "",
        "",
        "The variables allows you to control the value; For example: Change, Add, Remove, Check if two value is equal."
        // MARK: W
        
        // MARK: X
        
        // MARK: Y
        
        // MARK: Z
        
    ]
    
    var searchNames = [String()]

       
    @IBOutlet weak var SwiftTableView: UITableView!
  
        
        
        override func viewDidLoad() {
            super.viewDidLoad()

 
           self.navigationController?.navigationBar.prefersLargeTitles = true
           self.navigationController?.navigationItem.largeTitleDisplayMode = .never
            
//            let search = UISearchController(searchResultsController: nil)
//            search.searchBar.delegate = self
//            search.searchResultsUpdater = self as? UISearchResultsUpdating
//            search.searchBar.placeholder = "Search code..."
//            search.searchBar.searchTextField.tintColor = .white
//            search.searchBar.setImage(UIImage(named: "magnifyingglass"), for: .search, state: .normal)
//           
//          self.navigationItem.searchController = search
//      
//          (UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]) ).defaultTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
//        
//            let textField = search.searchBar.value(forKey: "searchField") as! UITextField
//
//            // Glass Icon On The Search Bar
//            let glassIconView = textField.leftView as! UIImageView
//            glassIconView.image = glassIconView.image?.withRenderingMode(.alwaysTemplate)
//            glassIconView.tintColor = UIColor.white
//
//            let clearButton = textField.value(forKey: "clearButton") as! UIButton
//       clearButton.setImage(clearButton.imageView?.image?.withRenderingMode(.alwaysTemplate), for: .normal)
//        
//            clearButton.tintColor = UIColor.white
           
        }
       
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            
        }
        
        
       
    }

    extension SwiftDictonaryViewController: UISearchBarDelegate {

              
        
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        print(searchText)
    }
    
}

extension SwiftDictonaryViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 207
    }
    
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            
            if indexPath.row == 206 {
                
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
                
            } else if indexPath.row == 205 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
                    attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: " value ", attributes: [.backgroundColor: dynamicBackground]))
                   
                
                cell?.textLabel?.textColor = .white
                
                cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 204 {
                
               // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 203 {
                
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
                
            } else if indexPath.row == 202 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                 let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                                              
                    attr.append(NSAttributedString(string: "dict ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                             
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                              
                                          
                    attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                            
                    attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                                                              
                                                          
                    attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                           
                    attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                                                          
                    attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                       
                    attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                                                                
                                                           
                    attr.append(NSAttributedString(string: "]\n \n", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "dict", attributes: [.foregroundColor: projectSyntax]))
                
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "updateValue", attributes: [.foregroundColor: projectSyntax]))
                
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "\"element3\"", attributes: [.foregroundColor: StringSyntax]))
                
                attr.append(NSAttributedString(string: ", forKey: ", attributes: [.foregroundColor: PlainSyntax]))
            
                attr.append(NSAttributedString(string: "3", attributes: [.foregroundColor: NumberSyntax]))
                
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 201 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 200 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 199 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                 let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                 attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                   
                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                               
                attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                              
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
                           
                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                             
                attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                                               
                                           
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                            
                attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                                           
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                        
                attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                                                 
                                            
                attr.append(NSAttributedString(string: "]\n \n", attributes: [.foregroundColor: PlainSyntax]))
                                               
                                
                               
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                                
                              attr.append(NSAttributedString(string: "name2 ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                                 
                              attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                                             
                              attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                                            
                              attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                                             
                                         
                              attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                           
                              attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                                                             
                                                         
                              attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                          
                              attr.append(NSAttributedString(string: "\"element8\"", attributes: [.foregroundColor: StringSyntax]))
                                                         
                              attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                      
                              attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                                                               
                                                          
                              attr.append(NSAttributedString(string: "]\n \n", attributes: [.foregroundColor: PlainSyntax]))
                               
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                
                attr.append(NSAttributedString(string: "commonname ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                
                 attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "union", attributes: [.foregroundColor: projectSyntax]))
                
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "name2", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 198 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 197 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 196 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: " type ", attributes: [.backgroundColor: dynamicBackground]))
                
                   attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: " value ", attributes: [.backgroundColor: dynamicBackground]))
                   
              
                cell?.textLabel?.textColor = .white
        
        
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 195 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 194 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 193 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                    
                        attr.append(NSAttributedString(string: "tuple ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                    attr.append(NSAttributedString(string: "= (", attributes: [.foregroundColor: PlainSyntax]))
                    
                     attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                    
                     attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                    
                    attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                    
                    attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                                   
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                    attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                     attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                      
                    attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                
                cell?.textLabel?.attributedText = attr
                
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 192 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 191 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 190 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "isBreak ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 189 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 188 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 187 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax])
                
                   
                attr.append(NSAttributedString(string: "(terminator: ", attributes: [.foregroundColor: PlainSyntax]))
                 
                attr.append(NSAttributedString(string: "\" \"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))

                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 186 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 185 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 184 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "switch ", attributes: [.foregroundColor: KeyboardSyntax])
                
                  attr.append(NSAttributedString(string: " consider ", attributes: [.backgroundColor: dynamicBackground]))
                    
                    attr.append(NSAttributedString(string: " {\n ", attributes: [.foregroundColor: PlainSyntax]))
                    attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                  attr.append(NSAttributedString(string: "value: \n ", attributes: [.foregroundColor: PlainSyntax]))
                   
                attr.append(NSAttributedString(string: "// respond to value \n ", attributes: [.foregroundColor: CommentSyntax]))
                
                attr.append(NSAttributedString(string: "default", attributes: [.foregroundColor: KeyboardSyntax]))
                
                  attr.append(NSAttributedString(string: ": \n ", attributes: [.foregroundColor: PlainSyntax]))
                   
                attr.append(NSAttributedString(string: "// respond to default, which means it's false statements like else does \n ", attributes: [.foregroundColor: CommentSyntax]))
                
                attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                
                 cell?.textLabel?.textColor = UIColor.white
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 183 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 182 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 181 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "4 ", attributes: [.foregroundColor: NumberSyntax]))
                  
                  attr.append(NSAttributedString(string: "+=  ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                  
                  attr.append(NSAttributedString(string: "9 ", attributes: [.foregroundColor: NumberSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 180 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
            } else if indexPath.row == 179 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 178 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "4 ", attributes: [.foregroundColor: NumberSyntax]))
                
                attr.append(NSAttributedString(string: "+  ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                attr.append(NSAttributedString(string: "9 ", attributes: [.foregroundColor: NumberSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 177 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 176 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 175 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "struct ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "{\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "// proerties", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 174 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 173 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 172 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                  
                attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                   
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "\"This is a ", attributes: [.foregroundColor: StringSyntax]))
                  
                attr.append(NSAttributedString(string: "\\(", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "\\ string interpolation", attributes: [.foregroundColor: CommentSyntax]))
                
                attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "\"", attributes: [.foregroundColor: StringSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 171 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 170 {
                
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
                
            } else if indexPath.row == 169 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                  
                attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                   
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "\"This is a String\" ", attributes: [.foregroundColor: StringSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 168 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 167 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 166 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                                
                attr.append(NSAttributedString(string: "arr ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                              
                          
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                          
                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                        
                attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                               
                          
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                             
                attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                            
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                          
                attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                         
                attr.append(NSAttributedString(string: "]\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "arr", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "sorted", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "()", attributes: [.foregroundColor: PlainSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                 
                  cell?.backgroundColor =  CodeBackground
                  cell?.textLabel!.numberOfLines = 0
                  cell?.textLabel!.lineBreakMode = .byWordWrapping
                  cell?.textLabel?.textAlignment = .left

                                               
                  return cell!
                
            } else if indexPath.row == 165 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 164 {
                
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
                
            } else if indexPath.row == 163 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                                
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                              
                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                               
                           
                attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                          
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                          
                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                        
                attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                               
                          
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                             
                attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                            
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                          
                attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                         
                attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                
                cell?.textLabel?.attributedText = attr
                 
                  cell?.backgroundColor =  CodeBackground
                  cell?.textLabel!.numberOfLines = 0
                  cell?.textLabel!.lineBreakMode = .byWordWrapping
                  cell?.textLabel?.textAlignment = .left

                                               
                  return cell!
                
            } else if indexPath.row == 162 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 161 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 160 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax])
                  
                   
                  attr.append(NSAttributedString(string: "(separator: ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "\" \"", attributes: [.foregroundColor: StringSyntax]))
                    
                  attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                  
                    
                     
                  
                   cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 159 {
                
                // MARK: Header
                      let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                    
                       
                      cell?.textLabel?.text = seactionName[indexPath.row]
                      cell?.textLabel!.textColor = UIColor.white
                      cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                      cell?.textLabel?.textAlignment = .left
                      cell?.backgroundColor = titleBackground
                                                 
                      return cell!
                    
                } else if indexPath.row == 158 {
                    // MARK: Footer
                    let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                    
                       
                    cell?.textLabel?.text = sectionFooter[indexPath.row]
                    cell?.textLabel!.textColor = UIColor.white
                    cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                    cell?.textLabel?.textAlignment = .left
                    cell?.textLabel?.textColor = titleText
                    cell?.backgroundColor = titleBackground
                    cell?.textLabel!.numberOfLines = 0
                    cell?.textLabel!.lineBreakMode = .byWordWrapping
                                                 
                    return cell!
            } else if indexPath.row == 157 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                                
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                              
                
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                          
                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                        
                 attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
                 attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                               
                          
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                         
                attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                            
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                          
                attr.append(NSAttributedString(string: "3", attributes: [.foregroundColor: NumberSyntax]))
                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                         
                attr.append(NSAttributedString(string: "]\n \n", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "removeValue", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "(forKey: ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "3", attributes: [.foregroundColor: NumberSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 156 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 155 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 154 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                                
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                              
                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                               
                           
                attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                          
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                          
                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                        
                attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                               
                          
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                             
                attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                            
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                          
                attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                         
                attr.append(NSAttributedString(string: "]\n \n", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "remove", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"element3\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 153 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 152 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 151 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax])
                
                 
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
              
                attr.append(NSAttributedString(string: "5", attributes: [.foregroundColor: NumberSyntax]))
                  
                attr.append(NSAttributedString(string: ") ", attributes: [.foregroundColor: PlainSyntax]))
                
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 150 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 149 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 148 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "4 ", attributes: [.foregroundColor: NumberSyntax]))
                  attr.append(NSAttributedString(string: "%= ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                  attr.append(NSAttributedString(string: "9 ", attributes: [.foregroundColor: NumberSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 147 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 146 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 145 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "4 ", attributes: [.foregroundColor: NumberSyntax]))
                  attr.append(NSAttributedString(string: "% ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                  attr.append(NSAttributedString(string: "9 ", attributes: [.foregroundColor: NumberSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 144 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 143 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 142 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                
                attr.append(NSAttributedString(string: "? ", attributes: [.foregroundColor: PlainSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 141 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 140 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 139 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                                               
                               cell?.textLabel?.font = setFont
                               
                               let attr = NSMutableAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax])
                                             
                               attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))
                               attr.append(NSAttributedString(string: "&& ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                          
                                attr.append(NSAttributedString(string: "false ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                                attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                               
                               attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                    
                               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "\"true\"", attributes: [.foregroundColor: StringSyntax]))
                                          
                                         
                               attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                               
                                attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
                                attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                
                               attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                                    
                               attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "\"false\"", attributes: [.foregroundColor: StringSyntax]))
                                          
                                         
                               attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                               
                               attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                               
                               cell?.textLabel?.attributedText = attr
                                            
                                             cell?.backgroundColor =  CodeBackground
                                             cell?.textLabel!.numberOfLines = 0
                                             cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             cell?.textLabel?.textAlignment = .left
                                            
                                             cell?.textLabel?.font = setFont

                                             return cell!
                
            } else if indexPath.row == 138 {
               
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 137 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 136 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "catchBall ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                  attr.append(NSAttributedString(string: "true", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 135 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
                
            } else if indexPath.row == 134 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 133 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "isFlying ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                  attr.append(NSAttributedString(string: "true", attributes: [.foregroundColor: KeyboardSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 132 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 131 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 130 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "catchBall ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "true", attributes: [.foregroundColor: KeyboardSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                 return cell!
                
                
            } else if indexPath.row == 129 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 128 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 127 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                  
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"Hello\" \n", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                attr.append(NSAttributedString(string: "secondName ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"World\"\n", attributes: [.foregroundColor: StringSyntax]))
                
                attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                attr.append(NSAttributedString(string: "check_Name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: projectSyntax]))
                
                attr.append(NSAttributedString(string: "!= ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                attr.append(NSAttributedString(string: "secondName ", attributes: [.foregroundColor: projectSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 126 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 125 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 124 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
                attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                              
                attr.append(NSAttributedString(string: "*= ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                              
                attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                                  
                               
                cell?.textLabel?.attributedText = attr
                               
                cell?.backgroundColor =  CodeBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                cell?.textLabel?.textAlignment = .left

                                                             
                return cell!
                
                
            } else if indexPath.row == 123 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 122 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 121 {
                
                 let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                                
                cell?.textLabel?.font = setFont
                               
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
                attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                              
                attr.append(NSAttributedString(string: "* ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                              
                attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                                  
                               
                cell?.textLabel?.attributedText = attr
                               
                cell?.backgroundColor =  CodeBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                cell?.textLabel?.textAlignment = .left

                                                             
                return cell!
                
                
            } else if indexPath.row == 120 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 119 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 118 {
               
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: """
                  \"\"\"
                    This is
                    multi-line
                    strings
                  \"\"\"
                  """, attributes: [.foregroundColor: StringSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 117 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 116 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 115 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: """
                /*
                  This is
                  multi-line
                  comments
                */
                """, attributes: [.foregroundColor: CommentSyntax])
                
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 114 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 113 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 112 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                   
                let nameString = "Title"
                let string = "// MARK: \(nameString)"

                let attributes = [NSAttributedString.Key.font: setFont, NSAttributedString.Key.foregroundColor: CommentSyntax]
                let boldAttribute = [NSAttributedString.Key.font: BoldFont, NSAttributedString.Key.foregroundColor: MarksSyntax]

                let attributedString = NSMutableAttributedString(string: string, attributes: attributes)

                let nsString = NSString(string: string)
                let range = nsString.range(of: nameString)

                if range.length > 0 { attributedString.setAttributes(boldAttribute, range: range) }

            
                
                  cell?.textLabel?.attributedText = attributedString
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 111 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 110 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 109 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "bitNum ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                  attr.append(NSAttributedString(string: "min", attributes: [.foregroundColor: projectSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 108 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 107 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 106 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "bitNum ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "Int", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                  attr.append(NSAttributedString(string: "max", attributes: [.foregroundColor: projectSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 105 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 104 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 103 {
                
                 let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                                
                                cell?.textLabel?.font = setFont
                               
                               let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                                   attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
                                 attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                               attr.append(NSAttributedString(string: "<= ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                               attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                                  
                               
                                cell?.textLabel?.attributedText = attr
                               
                                cell?.backgroundColor =  CodeBackground
                                cell?.textLabel!.numberOfLines = 0
                                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                cell?.textLabel?.textAlignment = .left

                                                             
                                return cell!
            } else if indexPath.row == 102 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 101 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 100 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                attr.append(NSAttributedString(string: "< ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 99 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 98 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 97 {
                
                 let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                                
                                cell?.textLabel?.font = setFont
                               
                               let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                                   attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                   attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                               
                               attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                               
                               attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                               attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                                 
                               attr.append(NSAttributedString(string: "]\n \n", attributes: [.foregroundColor: PlainSyntax]))
                               
                
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                attr.append(NSAttributedString(string: "roommate_name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                               attr.append(NSAttributedString(string: "\"element3\"", attributes: [.foregroundColor: StringSyntax]))
                                              
                                              attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                               attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                                              attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                               attr.append(NSAttributedString(string: "\"element7\"", attributes: [.foregroundColor: StringSyntax]))
                                                
                                              attr.append(NSAttributedString(string: "]\n \n", attributes: [.foregroundColor: PlainSyntax]))
                
                               attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                               
                               attr.append(NSAttributedString(string: "check_element ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                               
                                 attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                                 attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "isDisjoint", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: "(with: ", attributes: [.foregroundColor: PlainSyntax]))
                               attr.append(NSAttributedString(string: "roommate_name", attributes: [.foregroundColor: projectSyntax]))
                               attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                                  
                               
                                cell?.textLabel?.attributedText = attr
                               
                                cell?.backgroundColor =  CodeBackground
                                cell?.textLabel!.numberOfLines = 0
                                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                cell?.textLabel?.textAlignment = .left

                                                             
                                return cell!
            } else if indexPath.row == 96 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 95 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 94 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                 attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                                
                                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                 attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                 attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                                  
                                attr.append(NSAttributedString(string: "]\n \n", attributes: [.foregroundColor: PlainSyntax]))
                                
                 
                 attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                 
                 attr.append(NSAttributedString(string: "roommate_name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                 
                 attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                 
                 attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                                                attr.append(NSAttributedString(string: "\"element3\"", attributes: [.foregroundColor: StringSyntax]))
                                               
                                               attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                                               attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                                                attr.append(NSAttributedString(string: "\"element7\"", attributes: [.foregroundColor: StringSyntax]))
                                                 
                                               attr.append(NSAttributedString(string: "]\n \n", attributes: [.foregroundColor: PlainSyntax]))
                
                
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                attr.append(NSAttributedString(string: "check_element ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                                   attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                  attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "intersection", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "roommate_name", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 93 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 92 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 91 {
                
               let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                  
                attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                
    
                
              
                  attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                  attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "insert", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"element3\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 90 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 89 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 88 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                attr.append(NSAttributedString(string: "score ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
               
                attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 87 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 86 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 85 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "errorString ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                
                    attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                     attr.append(NSAttributedString(string: "!", attributes: [.foregroundColor: PlainSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 84 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 83 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 82 {
               
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                 let attr = NSMutableAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax])
                 
                attr.append(NSAttributedString(string: " true condition ", attributes: [.backgroundColor: dynamicBackground]))
                
                attr.append(NSAttributedString(string: " {\n ", attributes: [.foregroundColor: PlainSyntax]))
                               
                                   attr.append(NSAttributedString(string: "// Execute\n", attributes: [.foregroundColor: CommentSyntax]))
                               
                                attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 81 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 80 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 79 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                attr.append(NSAttributedString(string: ">= ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "2 ", attributes: [.foregroundColor: NumberSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 78 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 77 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 76 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "5 ", attributes: [.foregroundColor: NumberSyntax]))
                attr.append(NSAttributedString(string: "> ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "2 ", attributes: [.foregroundColor: NumberSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 75 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
                
            } else if indexPath.row == 74 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 73 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "func ", attributes: [.foregroundColor: KeyboardSyntax])
                
                attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: " argument ", attributes: [.backgroundColor: dynamicBackground]))
                
                attr.append(NSAttributedString(string: ") {\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                    attr.append(NSAttributedString(string: "// implemntation\n", attributes: [.foregroundColor: CommentSyntax]))
                attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                  
                   
                 cell?.textLabel?.textColor = .white
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 72 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 71 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 70 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "switch ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: " consider ", attributes: [.backgroundColor: dynamicBackground]))
                    
                    attr.append(NSAttributedString(string: " {\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                 attr.append(NSAttributedString(string: "value ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: ":\n ", attributes: [.foregroundColor: PlainSyntax]))
                    
                attr.append(NSAttributedString(string: "// respond to value\n ", attributes: [.foregroundColor: CommentSyntax]))
                
                 attr.append(NSAttributedString(string: "\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                     attr.append(NSAttributedString(string: "fallthrough\n ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                attr.append(NSAttributedString(string: "\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "default ", attributes: [.foregroundColor: KeyboardSyntax]))
                 attr.append(NSAttributedString(string: ":\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "// respond to default, which means it's false statements like else does\n ", attributes: [.foregroundColor: CommentSyntax]))
                
                 attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                
                 cell?.textLabel?.textColor = .white
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 69 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 68 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 67 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "friendly ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "false ", attributes: [.foregroundColor: KeyboardSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 66 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 65 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 64 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                  
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"Hello\" \n", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                attr.append(NSAttributedString(string: "secondName ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"World\"\n", attributes: [.foregroundColor: StringSyntax]))
                
                attr.append(NSAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax]))
                attr.append(NSAttributedString(string: "check_Name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                      
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: projectSyntax]))
                
                attr.append(NSAttributedString(string: "== ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                attr.append(NSAttributedString(string: "secondName ", attributes: [.foregroundColor: projectSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 63 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 62 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 61 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "enum ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "textAligment ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "{ \n ", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                 attr.append(NSAttributedString(string: "left\n ", attributes: [.foregroundColor: projectSyntax]))
                
                attr.append(NSAttributedString(string: "case ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                 attr.append(NSAttributedString(string: "right\n", attributes: [.foregroundColor: projectSyntax]))
                
                 attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 60 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 59 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 58 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax])
                
                attr.append(NSAttributedString(string: " first condition ", attributes: [.backgroundColor: dynamicBackground]))
                 
                 attr.append(NSAttributedString(string: " {\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                    attr.append(NSAttributedString(string: "// Not execute\n", attributes: [.foregroundColor: CommentSyntax]))
                
                 attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                
                    attr.append(NSAttributedString(string: "else if ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                attr.append(NSAttributedString(string: " second condition ", attributes: [.backgroundColor: dynamicBackground]))
                
                attr.append(NSAttributedString(string: " {\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                   attr.append(NSAttributedString(string: "// Execute\n", attributes: [.foregroundColor: CommentSyntax]))
                   
                 attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                 
                     attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
                 
                  attr.append(NSAttributedString(string: "{\n ", attributes: [.foregroundColor: PlainSyntax]))
                 
                    attr.append(NSAttributedString(string: "// No execute\n", attributes: [.foregroundColor: CommentSyntax]))
                    
                  attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                
                cell?.textLabel?.textColor = UIColor.white
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 57 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 56 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 55 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax])
                 
                
                attr.append(NSAttributedString(string: " false condition ", attributes: [.backgroundColor: dynamicBackground]))
                
                attr.append(NSAttributedString(string: " {\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                    attr.append(NSAttributedString(string: "// Not execute\n", attributes: [.foregroundColor: CommentSyntax]))
                
                 attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                
                    attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                 attr.append(NSAttributedString(string: "{\n ", attributes: [.foregroundColor: PlainSyntax]))
                
                   attr.append(NSAttributedString(string: "// Execute\n", attributes: [.foregroundColor: CommentSyntax]))
                   
                 attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 54 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 53 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 52 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                   attr.append(NSAttributedString(string: "5.5", attributes: [.foregroundColor: NumberSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 51 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 50 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 49 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "4 ", attributes: [.foregroundColor: NumberSyntax]))
                
                  attr.append(NSAttributedString(string: "/= ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                  attr.append(NSAttributedString(string: "9 ", attributes: [.foregroundColor: NumberSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 48 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 47 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 46 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "num ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "4 ", attributes: [.foregroundColor: NumberSyntax]))
                
                  attr.append(NSAttributedString(string: "/ ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                
                  attr.append(NSAttributedString(string: "9 ", attributes: [.foregroundColor: NumberSyntax]))
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 45 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 44 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 43 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                     
                     
                attr.append(NSAttributedString(string: "dict ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                 
                   
                attr.append(NSAttributedString(string: "= [", attributes: [.foregroundColor: PlainSyntax]))
                     
                   
                attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
                   
                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                     
                    
                attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                     
                    
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                     
                   
                attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                                    
                  
                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                   
                attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                   
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                    
                attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                       
                  
                attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\n", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "dict", attributes: [.foregroundColor: projectSyntax]))
                      attr.append(NSAttributedString(string: "[", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
                 attr.append(NSAttributedString(string: ", default: ", attributes: [.foregroundColor: PlainSyntax]))
                    
                attr.append(NSAttributedString(string: "\"element4\"", attributes: [.foregroundColor: StringSyntax]))
                
                attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                
                cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 42 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 41 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 40 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "dict ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
            
                attr.append(NSAttributedString(string: "= [", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "1", attributes: [.foregroundColor: NumberSyntax]))
                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "2", attributes: [.foregroundColor: NumberSyntax]))
                               
                attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                  
                attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
           
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 39 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 38 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
                
            } else if indexPath.row == 37 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "\"Hello World!\"\n", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: "str", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "count", attributes: [.foregroundColor: projectSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 36 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 35 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 34 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: ": ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "Set ", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                  
                attr.append(NSAttributedString(string: "]\n", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: "name", attributes: [.foregroundColor: projectSyntax]))
                  attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "contains", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "( ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"element4\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 33 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 32 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 31 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: " name ", attributes: [.backgroundColor: dynamicBackground]))
                    attr.append(NSAttributedString(string: " = ", attributes: [.foregroundColor: PlainSyntax]))
                
                  attr.append(NSAttributedString(string: " value ", attributes: [.backgroundColor: dynamicBackground]))
                   
                
                cell?.textLabel?.textColor = .white
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 30 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 29 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 28 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "// This is Comments ", attributes: [.foregroundColor: CommentSyntax])
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 27 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 26 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 25 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "let ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "students ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= {\n", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "// statements\n", attributes: [.foregroundColor: CommentSyntax]))
                
                 attr.append(NSAttributedString(string: "}", attributes: [.foregroundColor: PlainSyntax]))
                
                  
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
            } else if indexPath.row == 24 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 23 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 22 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                
                let attr = NSMutableAttributedString(string: "class ", attributes: [.foregroundColor: KeyboardSyntax])
                               
                 
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "{\n ", attributes: [.foregroundColor: PlainSyntax]))
                               
                attr.append(NSAttributedString(string: "// proerties\n", attributes: [.foregroundColor: CommentSyntax]))
                               
                attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                                  
                               
                cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
                
            } else if indexPath.row == 21 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
                
            } else if indexPath.row == 20 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 19 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                    attr.append(NSAttributedString(string: "\"\\\"Hello World\\\\\"", attributes: [.foregroundColor: StringSyntax]))
                  
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 18 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 17 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 16 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                   
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                  
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                 
                attr.append(NSAttributedString(string: "\"Noah\"\n", attributes: [.foregroundColor: StringSyntax]))
                   
                attr.append(NSAttributedString(string: "name ", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "\"Conor\"\n", attributes: [.foregroundColor: StringSyntax]))
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
            } else if indexPath.row == 15 {
                
                // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 14 {
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
            } else if indexPath.row == 13 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "array ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= [", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "\"element\"", attributes: [.foregroundColor: StringSyntax]))
                
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "\"element1\"", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: ", ", attributes: [.foregroundColor: PlainSyntax]))
                 attr.append(NSAttributedString(string: "\"element2\"", attributes: [.foregroundColor: StringSyntax]))
                  
                attr.append(NSAttributedString(string: "]", attributes: [.foregroundColor: PlainSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                
                
            } else if indexPath.row == 12 {

              // MARK: Header
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
              
                 
                cell?.textLabel?.text = seactionName[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                cell?.textLabel?.textAlignment = .left
                cell?.backgroundColor = titleBackground
                                           
                return cell!
                
            } else if indexPath.row == 11 {
                
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
                
            } else if indexPath.row == 10 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                                
                cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
             
                attr.append(NSAttributedString(string: "friend ", attributes: [.foregroundColor: TypeDeclarationSyntax]))

                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "String", attributes: [.foregroundColor: projectSyntax]))
                
                attr.append(NSAttributedString(string: "()\n", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "friend", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "append", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "\"Aliex\"", attributes: [.foregroundColor: StringSyntax]))
                           
                          
                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "friend", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: ".", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "append", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "\"Alan\"", attributes: [.foregroundColor: StringSyntax]))
                           
                          
                attr.append(NSAttributedString(string: ")", attributes: [.foregroundColor: PlainSyntax]))
                
                
                cell?.textLabel?.attributedText = attr
                             
                cell?.backgroundColor =  CodeBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                cell?.textLabel?.textAlignment = .left
                             
                cell?.textLabel?.font = setFont

                return cell!
                
            } else if indexPath.row == 9 {
                
                  // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 8 {
                
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
                
            } else if indexPath.row == 7 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                                
                cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "if ", attributes: [.foregroundColor: KeyboardSyntax])
                              
                attr.append(NSAttributedString(string: "true ", attributes: [.foregroundColor: KeyboardSyntax]))
                attr.append(NSAttributedString(string: "|| ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                           
                 attr.append(NSAttributedString(string: "false ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                 attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                     
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"true\"", attributes: [.foregroundColor: StringSyntax]))
                           
                          
                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                
                 attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "else ", attributes: [.foregroundColor: KeyboardSyntax]))
                 attr.append(NSAttributedString(string: "{\n", attributes: [.foregroundColor: PlainSyntax]))
 
                attr.append(NSAttributedString(string: "print", attributes: [.foregroundColor: projectSyntax]))

                                     
                attr.append(NSAttributedString(string: "(", attributes: [.foregroundColor: PlainSyntax]))
                attr.append(NSAttributedString(string: "\"false\"", attributes: [.foregroundColor: StringSyntax]))
                           
                          
                attr.append(NSAttributedString(string: ")\n", attributes: [.foregroundColor: PlainSyntax]))
                                
                attr.append(NSAttributedString(string: "} ", attributes: [.foregroundColor: PlainSyntax]))
                
                cell?.textLabel?.attributedText = attr
                             
                              cell?.backgroundColor =  CodeBackground
                              cell?.textLabel!.numberOfLines = 0
                              cell?.textLabel!.lineBreakMode = .byWordWrapping
                              cell?.textLabel?.textAlignment = .left
                             
                              cell?.textLabel?.font = setFont

                              return cell!
                
            } else if indexPath.row == 6 {
                
                  // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
            } else if indexPath.row == 5 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                             
                                
                             cell?.textLabel?.text = sectionFooter[indexPath.row]
                             cell?.textLabel!.textColor = UIColor.white
                             cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                             cell?.textLabel?.textAlignment = .left
                             cell?.textLabel?.textColor = titleText
                             cell?.backgroundColor = titleBackground
                             cell?.textLabel!.numberOfLines = 0
                             cell?.textLabel!.lineBreakMode = .byWordWrapping
                                                          
                             return cell!
                
            } else if indexPath.row == 4 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                    attr.append(NSAttributedString(string: "\"Hello\"\n", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: projectSyntax]))
                attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                               
                attr.append(NSAttributedString(string: "\"World\"\n", attributes: [.foregroundColor: StringSyntax]))
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                attr.append(NSAttributedString(string: "number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "4\n", attributes: [.foregroundColor: NumberSyntax]))
                 attr.append(NSAttributedString(string: "number ", attributes: [.foregroundColor: projectSyntax]))
                    attr.append(NSAttributedString(string: "+= ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                
                     attr.append(NSAttributedString(string: "9", attributes: [.foregroundColor: NumberSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left
                
                 cell?.textLabel?.font = setFont

                 return cell!
                
            } else if indexPath.row == 3 {
                
                  // MARK: Header
                  let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                  cell?.textLabel?.text = seactionName[indexPath.row]
                  cell?.textLabel!.textColor = UIColor.white
                  cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                  cell?.textLabel?.textAlignment = .left
                  cell?.backgroundColor = titleBackground
                                             
                  return cell!
                
                
            } else if indexPath.row == 2 {
                
                // MARK: Footer
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                
                   
                cell?.textLabel?.text = sectionFooter[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
                cell?.textLabel?.textAlignment = .left
                cell?.textLabel?.textColor = titleText
                cell?.backgroundColor = titleBackground
                cell?.textLabel!.numberOfLines = 0
                cell?.textLabel!.lineBreakMode = .byWordWrapping
                                             
                return cell!
                
            } else if indexPath.row == 1 {
                
                let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
                 
                 cell?.textLabel?.font = setFont
                
                let attr = NSMutableAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax])
                
                    attr.append(NSAttributedString(string: "str ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                    attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                    attr.append(NSAttributedString(string: "\"Hello\" ", attributes: [.foregroundColor: StringSyntax]))
                 attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                  attr.append(NSAttributedString(string: "\"World\"\n", attributes: [.foregroundColor: StringSyntax]))
                
                attr.append(NSAttributedString(string: "var ", attributes: [.foregroundColor: KeyboardSyntax]))
                
                attr.append(NSAttributedString(string: "number ", attributes: [.foregroundColor: TypeDeclarationSyntax]))
                attr.append(NSAttributedString(string: "= ", attributes: [.foregroundColor: PlainSyntax]))
                
                attr.append(NSAttributedString(string: "4 ", attributes: [.foregroundColor: NumberSyntax]))
                
                    attr.append(NSAttributedString(string: "+ ", attributes: [.foregroundColor: OtherDecluarationSyntax]))
                
                     attr.append(NSAttributedString(string: "9", attributes: [.foregroundColor: NumberSyntax]))
                   
                
                 cell?.textLabel?.attributedText = attr
                
                 cell?.backgroundColor =  CodeBackground
                 cell?.textLabel!.numberOfLines = 0
                 cell?.textLabel!.lineBreakMode = .byWordWrapping
                 cell?.textLabel?.textAlignment = .left

                                              
                 return cell!
                  
                
            } else {
                
                 let cell = SwiftTableView.dequeueReusableCell(withIdentifier: "Cells")
  
     
                cell?.textLabel?.text = seactionName[indexPath.row]
                cell?.textLabel!.textColor = UIColor.white
                cell?.textLabel?.font = UIFont.systemFont(ofSize: 15.0)
                cell?.textLabel?.textAlignment = .left
                cell?.backgroundColor = titleBackground
                               
                 return cell!
                
            }
            
            
        }
    
    }

